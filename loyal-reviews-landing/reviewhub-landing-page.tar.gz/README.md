# Onlook Template

<p align="center">
  <img src="src/app/favicon.ico" />
</p>

This is an [Onlook](https://onlook.dev/) project set up with
[Next.js](https://nextjs.org/), and [TailwindCSS](https://tailwindcss.com/).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```
