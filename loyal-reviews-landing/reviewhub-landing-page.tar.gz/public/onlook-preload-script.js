var I4 = Object.create;
var {
  getPrototypeOf: k4,
  defineProperty: Ue,
  getOwnPropertyNames: U4
} = Object;
var J4 = Object.prototype.hasOwnProperty;
var qh = (r, t, i) => {
  i = r != null ? I4(k4(r)) : {};
  let o =
  t || !r || !r.__esModule ?
  Ue(i, "default", { value: r, enumerable: !0 }) :
  i;
  for (let n of U4(r))
  if (!J4.call(o, n)) Ue(o, n, { get: () => r[n], enumerable: !0 });
  return o;
};
var vr = (r, t) => () => (t || r((t = { exports: {} }).exports, t), t.exports);
var I = (r, t) => {
  for (var i in t)
  Ue(r, i, {
    get: t[i],
    enumerable: !0,
    configurable: !0,
    set: (o) => t[i] = () => o
  });
};
var Je = vr((sk, Wh) => {
  function P4(r) {
    var t = typeof r;
    return r != null && (t == "object" || t == "function");
  }
  Wh.exports = P4;
});
var Lh = vr((rU, Kh) => {
  var X4 =
  typeof global == "object" && global && global.Object === Object && global;
  Kh.exports = X4;
});
var Pe = vr((tU, Vh) => {
  var q4 = Lh(),
    W4 = typeof self == "object" && self && self.Object === Object && self,
    K4 = q4 || W4 || Function("return this")();
  Vh.exports = K4;
});
var Eh = vr((nU, Yh) => {
  var L4 = Pe(),
    V4 = function () {
      return L4.Date.now();
    };
  Yh.exports = V4;
});
var Fh = vr((iU, Qh) => {
  var Y4 = /\s/;
  function E4(r) {
    var t = r.length;
    while (t-- && Y4.test(r.charAt(t)));
    return t;
  }
  Qh.exports = E4;
});
var Gh = vr((oU, Sh) => {
  var Q4 = Fh(),
    F4 = /^\s+/;
  function S4(r) {
    return r ? r.slice(0, Q4(r) + 1).replace(F4, "") : r;
  }
  Sh.exports = S4;
});
var Xe = vr((eU, Nh) => {
  var G4 = Pe(),
    N4 = G4.Symbol;
  Nh.exports = N4;
});
var Hh = vr((lU, Ah) => {
  var Bh = Xe(),
    yh = Object.prototype,
    B4 = yh.hasOwnProperty,
    y4 = yh.toString,
    wn = Bh ? Bh.toStringTag : void 0;
  function A4(r) {
    var t = B4.call(r, wn),
      i = r[wn];
    try {
      r[wn] = void 0;
      var o = !0;
    } catch (e) {}
    var n = y4.call(r);
    if (o)
    if (t) r[wn] = i;else
    delete r[wn];
    return n;
  }
  Ah.exports = A4;
});
var Mh = vr((cU, Rh) => {
  var H4 = Object.prototype,
    R4 = H4.toString;
  function M4(r) {
    return R4.call(r);
  }
  Rh.exports = M4;
});
var dh = vr((uU, Th) => {
  var Zh = Xe(),
    Z4 = Hh(),
    C4 = Mh(),
    T4 = "[object Null]",
    d4 = "[object Undefined]",
    Ch = Zh ? Zh.toStringTag : void 0;
  function s4(r) {
    if (r == null) return r === void 0 ? d4 : T4;
    return Ch && Ch in Object(r) ? Z4(r) : C4(r);
  }
  Th.exports = s4;
});
var r$ = vr((gU, sh) => {
  function r6(r) {
    return r != null && typeof r == "object";
  }
  sh.exports = r6;
});
var n$ = vr((mU, t$) => {
  var t6 = dh(),
    n6 = r$(),
    i6 = "[object Symbol]";
  function o6(r) {
    return typeof r == "symbol" || n6(r) && t6(r) == i6;
  }
  t$.exports = o6;
});
var l$ = vr((bU, e$) => {
  var e6 = Gh(),
    i$ = Je(),
    l6 = n$(),
    o$ = NaN,
    c6 = /^[-+]0x[0-9a-f]+$/i,
    u6 = /^0b[01]+$/i,
    g6 = /^0o[0-7]+$/i,
    m6 = parseInt;
  function b6(r) {
    if (typeof r == "number") return r;
    if (l6(r)) return o$;
    if (i$(r)) {
      var t = typeof r.valueOf == "function" ? r.valueOf() : r;
      r = i$(t) ? t + "" : t;
    }
    if (typeof r != "string") return r === 0 ? r : +r;
    r = e6(r);
    var i = u6.test(r);
    return i || g6.test(r) ? m6(r.slice(2), i ? 2 : 8) : c6.test(r) ? o$ : +r;
  }
  e$.exports = b6;
});
var We = vr((vU, u$) => {
  var v6 = Je(),
    qe = Eh(),
    c$ = l$(),
    h6 = "Expected a function",
    $6 = Math.max,
    x6 = Math.min;
  function f6(r, t, i) {
    var o,
      n,
      e,
      l,
      u,
      g,
      c = 0,
      m = !1,
      v = !1,
      h = !0;
    if (typeof r != "function") throw new TypeError(h6);
    if (t = c$(t) || 0, v6(i))
    m = !!i.leading,
    v = "maxWait" in i,
    e = v ? $6(c$(i.maxWait) || 0, t) : e,
    h = "trailing" in i ? !!i.trailing : h;
    function b(Q) {
      var B = o,
        tr = n;
      return o = n = void 0, c = Q, l = r.apply(tr, B), l;
    }
    function f(Q) {
      return c = Q, u = setTimeout(_, t), m ? b(Q) : l;
    }
    function D(Q) {
      var B = Q - g,
        tr = Q - c,
        ke = t - B;
      return v ? x6(ke, e - tr) : ke;
    }
    function O(Q) {
      var B = Q - g,
        tr = Q - c;
      return g === void 0 || B >= t || B < 0 || v && tr >= e;
    }
    function _() {
      var Q = qe();
      if (O(Q)) return J(Q);
      u = setTimeout(_, D(Q));
    }
    function J(Q) {
      if (u = void 0, h && o) return b(Q);
      return o = n = void 0, l;
    }
    function V() {
      if (u !== void 0) clearTimeout(u);
      c = 0, o = g = n = u = void 0;
    }
    function X() {
      return u === void 0 ? l : J(qe());
    }
    function W() {
      var Q = qe(),
        B = O(Q);
      if (o = arguments, n = this, g = Q, B) {
        if (u === void 0) return f(g);
        if (v) return clearTimeout(u), u = setTimeout(_, t), b(g);
      }
      if (u === void 0) u = setTimeout(_, t);
      return l;
    }
    return W.cancel = V, W.flush = X, W;
  }
  u$.exports = f6;
});
var g0 = vr((hz) => {
  var u0 =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(
    ""
  );
  hz.encode = function (r) {
    if (0 <= r && r < u0.length) return u0[r];
    throw new TypeError("Must be between 0 and 63: " + r);
  };
  hz.decode = function (r) {
    var t = 65,
      i = 90,
      o = 97,
      n = 122,
      e = 48,
      l = 57,
      u = 43,
      g = 47,
      c = 26,
      m = 52;
    if (t <= r && r <= i) return r - t;
    if (o <= r && r <= n) return r - o + c;
    if (e <= r && r <= l) return r - e + m;
    if (r == u) return 62;
    if (r == g) return 63;
    return -1;
  };
});
var $0 = vr((zz) => {
  var m0 = g0(),
    Re = 5,
    b0 = 1 << Re,
    v0 = b0 - 1,
    h0 = b0;
  function fz(r) {
    return r < 0 ? (-r << 1) + 1 : (r << 1) + 0;
  }
  function wz(r) {
    var t = (r & 1) === 1,
      i = r >> 1;
    return t ? -i : i;
  }
  zz.encode = function r(t) {
    var i = "",
      o,
      n = fz(t);
    do {
      if (o = n & v0, n >>>= Re, n > 0) o |= h0;
      i += m0.encode(o);
    } while (n > 0);
    return i;
  };
  zz.decode = function r(t, i, o) {
    var n = t.length,
      e = 0,
      l = 0,
      u,
      g;
    do {
      if (i >= n) throw new Error("Expected more digits in base 64 VLQ value.");
      if (g = m0.decode(t.charCodeAt(i++)), g === -1)
      throw new Error("Invalid base64 digit: " + t.charAt(i - 1));
      u = !!(g & h0), g &= v0, e = e + (g << l), l += Re;
    } while (u);
    o.value = wz(e), o.rest = i;
  };
});
var Mi = vr((Vz) => {
  function _z(r, t, i) {
    if (t in r) return r[t];else
    if (arguments.length === 3) return i;else
    throw new Error('"' + t + '" is a required argument.');
  }
  Vz.getArg = _z;
  var x0 = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/,
    Dz = /^data:.+\,.+$/;
  function In(r) {
    var t = r.match(x0);
    if (!t) return null;
    return { scheme: t[1], auth: t[2], host: t[3], port: t[4], path: t[5] };
  }
  Vz.urlParse = In;
  function At(r) {
    var t = "";
    if (r.scheme) t += r.scheme + ":";
    if (t += "//", r.auth) t += r.auth + "@";
    if (r.host) t += r.host;
    if (r.port) t += ":" + r.port;
    if (r.path) t += r.path;
    return t;
  }
  Vz.urlGenerate = At;
  var jz = 32;
  function Oz(r) {
    var t = [];
    return function (i) {
      for (var o = 0; o < t.length; o++)
      if (t[o].input === i) {
        var n = t[0];
        return t[0] = t[o], t[o] = n, t[0].result;
      }
      var e = r(i);
      if (t.unshift({ input: i, result: e }), t.length > jz) t.pop();
      return e;
    };
  }
  var Me = Oz(function r(t) {
    var i = t,
      o = In(t);
    if (o) {
      if (!o.path) return t;
      i = o.path;
    }
    var n = Vz.isAbsolute(i),
      e = [],
      l = 0,
      u = 0;
    while (!0)
    if (l = u, u = i.indexOf("/", l), u === -1) {
      e.push(i.slice(l));
      break;
    } else {
      e.push(i.slice(l, u));
      while (u < i.length && i[u] === "/") u++;
    }
    for (var g, c = 0, u = e.length - 1; u >= 0; u--)
    if (g = e[u], g === ".") e.splice(u, 1);else
    if (g === "..") c++;else
    if (c > 0)
    if (g === "") e.splice(u + 1, c), c = 0;else
    e.splice(u, 2), c--;
    if (i = e.join("/"), i === "") i = n ? "/" : ".";
    if (o) return o.path = i, At(o);
    return i;
  });
  Vz.normalize = Me;
  function f0(r, t) {
    if (r === "") r = ".";
    if (t === "") t = ".";
    var i = In(t),
      o = In(r);
    if (o) r = o.path || "/";
    if (i && !i.scheme) {
      if (o) i.scheme = o.scheme;
      return At(i);
    }
    if (i || t.match(Dz)) return t;
    if (o && !o.host && !o.path) return o.host = t, At(o);
    var n = t.charAt(0) === "/" ? t : Me(r.replace(/\/+$/, "") + "/" + t);
    if (o) return o.path = n, At(o);
    return n;
  }
  Vz.join = f0;
  Vz.isAbsolute = function (r) {
    return r.charAt(0) === "/" || x0.test(r);
  };
  function Iz(r, t) {
    if (r === "") r = ".";
    r = r.replace(/\/$/, "");
    var i = 0;
    while (t.indexOf(r + "/") !== 0) {
      var o = r.lastIndexOf("/");
      if (o < 0) return t;
      if (r = r.slice(0, o), r.match(/^([^\/]+:\/)?\/*$/)) return t;
      ++i;
    }
    return Array(i + 1).join("../") + t.substr(r.length + 1);
  }
  Vz.relative = Iz;
  var w0 = (function () {
    var r = Object.create(null);
    return !("__proto__" in r);
  })();
  function z0(r) {
    return r;
  }
  function kz(r) {
    if (a0(r)) return "$" + r;
    return r;
  }
  Vz.toSetString = w0 ? z0 : kz;
  function Uz(r) {
    if (a0(r)) return r.slice(1);
    return r;
  }
  Vz.fromSetString = w0 ? z0 : Uz;
  function a0(r) {
    if (!r) return !1;
    var t = r.length;
    if (t < 9) return !1;
    if (
    r.charCodeAt(t - 1) !== 95 ||
    r.charCodeAt(t - 2) !== 95 ||
    r.charCodeAt(t - 3) !== 111 ||
    r.charCodeAt(t - 4) !== 116 ||
    r.charCodeAt(t - 5) !== 111 ||
    r.charCodeAt(t - 6) !== 114 ||
    r.charCodeAt(t - 7) !== 112 ||
    r.charCodeAt(t - 8) !== 95 ||
    r.charCodeAt(t - 9) !== 95)

    return !1;
    for (var i = t - 10; i >= 0; i--) if (r.charCodeAt(i) !== 36) return !1;
    return !0;
  }
  function Jz(r, t, i) {
    var o = tt(r.source, t.source);
    if (o !== 0) return o;
    if (o = r.originalLine - t.originalLine, o !== 0) return o;
    if (o = r.originalColumn - t.originalColumn, o !== 0 || i) return o;
    if (o = r.generatedColumn - t.generatedColumn, o !== 0) return o;
    if (o = r.generatedLine - t.generatedLine, o !== 0) return o;
    return tt(r.name, t.name);
  }
  Vz.compareByOriginalPositions = Jz;
  function Pz(r, t, i) {
    var o = r.originalLine - t.originalLine;
    if (o !== 0) return o;
    if (o = r.originalColumn - t.originalColumn, o !== 0 || i) return o;
    if (o = r.generatedColumn - t.generatedColumn, o !== 0) return o;
    if (o = r.generatedLine - t.generatedLine, o !== 0) return o;
    return tt(r.name, t.name);
  }
  Vz.compareByOriginalPositionsNoSource = Pz;
  function Xz(r, t, i) {
    var o = r.generatedLine - t.generatedLine;
    if (o !== 0) return o;
    if (o = r.generatedColumn - t.generatedColumn, o !== 0 || i) return o;
    if (o = tt(r.source, t.source), o !== 0) return o;
    if (o = r.originalLine - t.originalLine, o !== 0) return o;
    if (o = r.originalColumn - t.originalColumn, o !== 0) return o;
    return tt(r.name, t.name);
  }
  Vz.compareByGeneratedPositionsDeflated = Xz;
  function qz(r, t, i) {
    var o = r.generatedColumn - t.generatedColumn;
    if (o !== 0 || i) return o;
    if (o = tt(r.source, t.source), o !== 0) return o;
    if (o = r.originalLine - t.originalLine, o !== 0) return o;
    if (o = r.originalColumn - t.originalColumn, o !== 0) return o;
    return tt(r.name, t.name);
  }
  Vz.compareByGeneratedPositionsDeflatedNoLine = qz;
  function tt(r, t) {
    if (r === t) return 0;
    if (r === null) return 1;
    if (t === null) return -1;
    if (r > t) return 1;
    return -1;
  }
  function Wz(r, t) {
    var i = r.generatedLine - t.generatedLine;
    if (i !== 0) return i;
    if (i = r.generatedColumn - t.generatedColumn, i !== 0) return i;
    if (i = tt(r.source, t.source), i !== 0) return i;
    if (i = r.originalLine - t.originalLine, i !== 0) return i;
    if (i = r.originalColumn - t.originalColumn, i !== 0) return i;
    return tt(r.name, t.name);
  }
  Vz.compareByGeneratedPositionsInflated = Wz;
  function Kz(r) {
    return JSON.parse(r.replace(/^\)]}'[^\n]*\n/, ""));
  }
  Vz.parseSourceMapInput = Kz;
  function Lz(r, t, i) {
    if (t = t || "", r) {
      if (r[r.length - 1] !== "/" && t[0] !== "/") r += "/";
      t = r + t;
    }
    if (i) {
      var o = In(i);
      if (!o) throw new Error("sourceMapURL could not be parsed");
      if (o.path) {
        var n = o.path.lastIndexOf("/");
        if (n >= 0) o.path = o.path.substring(0, n + 1);
      }
      t = f0(At(o), t);
    }
    return Me(t);
  }
  Vz.computeSourceURL = Lz;
});
var p0 = vr((dz) => {
  var Ze = Mi(),
    Ce = Object.prototype.hasOwnProperty,
    kt = typeof Map !== "undefined";
  function nt() {
    this._array = [], this._set = kt ? new Map() : Object.create(null);
  }
  nt.fromArray = function r(t, i) {
    var o = new nt();
    for (var n = 0, e = t.length; n < e; n++) o.add(t[n], i);
    return o;
  };
  nt.prototype.size = function r() {
    return kt ? this._set.size : Object.getOwnPropertyNames(this._set).length;
  };
  nt.prototype.add = function r(t, i) {
    var o = kt ? t : Ze.toSetString(t),
      n = kt ? this.has(t) : Ce.call(this._set, o),
      e = this._array.length;
    if (!n || i) this._array.push(t);
    if (!n)
    if (kt) this._set.set(t, e);else
    this._set[o] = e;
  };
  nt.prototype.has = function r(t) {
    if (kt) return this._set.has(t);else
    {
      var i = Ze.toSetString(t);
      return Ce.call(this._set, i);
    }
  };
  nt.prototype.indexOf = function r(t) {
    if (kt) {
      var i = this._set.get(t);
      if (i >= 0) return i;
    } else {
      var o = Ze.toSetString(t);
      if (Ce.call(this._set, o)) return this._set[o];
    }
    throw new Error('"' + t + '" is not in the set.');
  };
  nt.prototype.at = function r(t) {
    if (t >= 0 && t < this._array.length) return this._array[t];
    throw new Error("No element indexed by " + t);
  };
  nt.prototype.toArray = function r() {
    return this._array.slice();
  };
  dz.ArraySet = nt;
});
var D0 = vr((ta) => {
  var _0 = Mi();
  function ra(r, t) {
    var i = r.generatedLine,
      o = t.generatedLine,
      n = r.generatedColumn,
      e = t.generatedColumn;
    return (
      o > i ||
      o == i && e >= n ||
      _0.compareByGeneratedPositionsInflated(r, t) <= 0);

  }
  function Zi() {
    this._array = [],
    this._sorted = !0,
    this._last = { generatedLine: -1, generatedColumn: 0 };
  }
  Zi.prototype.unsortedForEach = function r(t, i) {
    this._array.forEach(t, i);
  };
  Zi.prototype.add = function r(t) {
    if (ra(this._last, t)) this._last = t, this._array.push(t);else
    this._sorted = !1, this._array.push(t);
  };
  Zi.prototype.toArray = function r() {
    if (!this._sorted)
    this._array.sort(_0.compareByGeneratedPositionsInflated),
    this._sorted = !0;
    return this._array;
  };
  ta.MappingList = Zi;
});
var Vt = "PENPAL_CHILD";
var j4 = qh(We(), 1);
var w6 = class extends Error {
    code;
    constructor(r, t) {
      super(t);
      this.name = "PenpalError", this.code = r;
    }
  },
  pr = w6,
  z6 = (r) => ({
    name: r.name,
    message: r.message,
    stack: r.stack,
    penpalCode: r instanceof pr ? r.code : void 0
  }),
  a6 = ({ name: r, message: t, stack: i, penpalCode: o }) => {
    let n = o ? new pr(o, t) : new Error(t);
    return n.name = r, n.stack = i, n;
  },
  p6 = Symbol("Reply"),
  _6 = class {
    value;
    transferables;
    #r = p6;
    constructor(r, t) {
      this.value = r, this.transferables = t?.transferables;
    }
  },
  D6 = _6,
  Jr = "penpal",
  qi = (r) => {
    return typeof r === "object" && r !== null;
  },
  h$ = (r) => {
    return typeof r === "function";
  },
  j6 = (r) => {
    return qi(r) && r.namespace === Jr;
  },
  Yt = (r) => {
    return r.type === "SYN";
  },
  Wi = (r) => {
    return r.type === "ACK1";
  },
  zn = (r) => {
    return r.type === "ACK2";
  },
  $$ = (r) => {
    return r.type === "CALL";
  },
  x$ = (r) => {
    return r.type === "REPLY";
  },
  O6 = (r) => {
    return r.type === "DESTROY";
  },
  f$ = (r, t = []) => {
    let i = [];
    for (let o of Object.keys(r)) {
      let n = r[o];
      if (h$(n)) i.push([...t, o]);else
      if (qi(n)) i.push(...f$(n, [...t, o]));
    }
    return i;
  },
  I6 = (r, t) => {
    let i = r.reduce((o, n) => {
      return qi(o) ? o[n] : void 0;
    }, t);
    return h$(i) ? i : void 0;
  },
  mt = (r) => {
    return r.join(".");
  },
  g$ = (r, t, i) => ({
    namespace: Jr,
    channel: r,
    type: "REPLY",
    callId: t,
    isError: !0,
    ...(i instanceof Error ?
    { value: z6(i), isSerializedErrorInstance: !0 } :
    { value: i })
  }),
  k6 = (r, t, i, o) => {
    let n = !1,
      e = async (l) => {
        if (n) return;
        if (!$$(l)) return;
        o?.(`Received ${mt(l.methodPath)}() call`, l);
        let { methodPath: u, args: g, id: c } = l,
          m,
          v;
        try {
          let h = I6(u, t);
          if (!h)
          throw new pr(
            "METHOD_NOT_FOUND",
            `Method \`${mt(u)}\` is not found.`
          );
          let b = await h(...g);
          if (b instanceof D6) v = b.transferables, b = await b.value;
          m = { namespace: Jr, channel: i, type: "REPLY", callId: c, value: b };
        } catch (h) {
          m = g$(i, c, h);
        }
        if (n) return;
        try {
          o?.(`Sending ${mt(u)}() reply`, m), r.sendMessage(m, v);
        } catch (h) {
          if (h.name === "DataCloneError")
          m = g$(i, c, h),
          o?.(`Sending ${mt(u)}() reply`, m),
          r.sendMessage(m);
          throw h;
        }
      };
    return (
      r.addMessageHandler(e),
      () => {
        n = !0, r.removeMessageHandler(e);
      });

  },
  U6 = k6,
  w$ =
  crypto.randomUUID?.bind(crypto) ?? (
  () =>
  new Array(4).
  fill(0).
  map(() =>
  Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)
  ).
  join("-")),
  J6 = Symbol("CallOptions"),
  P6 = class {
    transferables;
    timeout;
    #r = J6;
    constructor(r) {
      this.transferables = r?.transferables, this.timeout = r?.timeout;
    }
  },
  X6 = P6,
  q6 = new Set(["apply", "call", "bind"]),
  z$ = (r, t, i = []) => {
    return new Proxy(i.length ? () => {} : Object.create(null), {
      get(o, n) {
        if (n === "then") return;
        if (i.length && q6.has(n)) return Reflect.get(o, n);
        return z$(r, t, [...i, n]);
      },
      apply(o, n, e) {
        return r(i, e);
      }
    });
  },
  m$ = (r) => {
    return new pr(
      "CONNECTION_DESTROYED",
      `Method call ${mt(r)}() failed due to destroyed connection`
    );
  },
  W6 = (r, t, i) => {
    let o = !1,
      n = new Map(),
      e = (g) => {
        if (!x$(g)) return;
        let {
            callId: c,
            value: m,
            isError: v,
            isSerializedErrorInstance: h
          } = g,
          b = n.get(c);
        if (!b) return;
        if (n.delete(c), i?.(`Received ${mt(b.methodPath)}() call`, g), v)
        b.reject(h ? a6(m) : m);else
        b.resolve(m);
      };
    return (
      r.addMessageHandler(e),
      {
        remoteProxy: z$((g, c) => {
          if (o) throw m$(g);
          let m = w$(),
            v = c[c.length - 1],
            h = v instanceof X6,
            { timeout: b, transferables: f } = h ? v : {},
            D = h ? c.slice(0, -1) : c;
          return new Promise((O, _) => {
            let J =
            b !== void 0 ?
            window.setTimeout(() => {
              n.delete(m),
              _(
                new pr(
                  "METHOD_CALL_TIMEOUT",
                  `Method call ${mt(g)}() timed out after ${b}ms`
                )
              );
            }, b) :
            void 0;
            n.set(m, { methodPath: g, resolve: O, reject: _, timeoutId: J });
            try {
              let V = {
                namespace: Jr,
                channel: t,
                type: "CALL",
                id: m,
                methodPath: g,
                args: D
              };
              i?.(`Sending ${mt(g)}() call`, V), r.sendMessage(V, f);
            } catch (V) {
              _(new pr("TRANSMISSION_FAILED", V.message));
            }
          });
        }, i),
        destroy: () => {
          o = !0, r.removeMessageHandler(e);
          for (let { methodPath: g, reject: c, timeoutId: m } of n.values())
          clearTimeout(m), c(m$(g));
          n.clear();
        }
      });

  },
  K6 = W6,
  L6 = () => {
    let r, t;
    return {
      promise: new Promise((o, n) => {
        r = o, t = n;
      }),
      resolve: r,
      reject: t
    };
  },
  V6 = L6,
  Y6 = class extends Error {
    constructor(r) {
      super(
        `You've hit a bug in Penpal. Please file an issue with the following information: ${r}`
      );
    }
  },
  Et = Y6,
  Ke = "deprecated-penpal",
  E6 = (r) => {
    return qi(r) && "penpal" in r;
  },
  Q6 = (r) => r.split("."),
  b$ = (r) => r.join("."),
  a$ = (r) => {
    return new Et(`Unexpected message to translate: ${JSON.stringify(r)}`);
  },
  F6 = (r) => {
    if (r.penpal === "syn")
    return { namespace: Jr, channel: void 0, type: "SYN", participantId: Ke };
    if (r.penpal === "ack")
    return { namespace: Jr, channel: void 0, type: "ACK2" };
    if (r.penpal === "call")
    return {
      namespace: Jr,
      channel: void 0,
      type: "CALL",
      id: r.id,
      methodPath: Q6(r.methodName),
      args: r.args
    };
    if (r.penpal === "reply")
    if (r.resolution === "fulfilled")
    return {
      namespace: Jr,
      channel: void 0,
      type: "REPLY",
      callId: r.id,
      value: r.returnValue
    };else

    return {
      namespace: Jr,
      channel: void 0,
      type: "REPLY",
      callId: r.id,
      isError: !0,
      ...(r.returnValueIsError ?
      { value: r.returnValue, isSerializedErrorInstance: !0 } :
      { value: r.returnValue })
    };
    throw a$(r);
  },
  S6 = (r) => {
    if (Wi(r)) return { penpal: "synAck", methodNames: r.methodPaths.map(b$) };
    if ($$(r))
    return {
      penpal: "call",
      id: r.id,
      methodName: b$(r.methodPath),
      args: r.args
    };
    if (x$(r))
    if (r.isError)
    return {
      penpal: "reply",
      id: r.callId,
      resolution: "rejected",
      ...(r.isSerializedErrorInstance ?
      { returnValue: r.value, returnValueIsError: !0 } :
      { returnValue: r.value })
    };else

    return {
      penpal: "reply",
      id: r.callId,
      resolution: "fulfilled",
      returnValue: r.value
    };
    throw a$(r);
  },
  G6 = ({ messenger: r, methods: t, timeout: i, channel: o, log: n }) => {
    let e = w$(),
      l,
      u = [],
      g = !1,
      c = f$(t),
      { promise: m, resolve: v, reject: h } = V6(),
      b =
      i !== void 0 ?
      setTimeout(() => {
        h(
          new pr(
            "CONNECTION_TIMEOUT",
            `Connection timed out after ${i}ms`
          )
        );
      }, i) :
      void 0,
      f = () => {
        for (let W of u) W();
      },
      D = () => {
        if (g) return;
        u.push(U6(r, t, o, n));
        let { remoteProxy: W, destroy: Q } = K6(r, o, n);
        u.push(Q),
        clearTimeout(b),
        g = !0,
        v({ remoteProxy: W, destroy: f });
      },
      O = () => {
        let W = { namespace: Jr, type: "SYN", channel: o, participantId: e };
        n?.("Sending handshake SYN", W);
        try {
          r.sendMessage(W);
        } catch (Q) {
          h(new pr("TRANSMISSION_FAILED", Q.message));
        }
      },
      _ = (W) => {
        if (
        n?.("Received handshake SYN", W), W.participantId === l && l !== Ke)

        return;
        if (l = W.participantId, O(), !(e > l || l === Ke)) return;
        let B = { namespace: Jr, channel: o, type: "ACK1", methodPaths: c };
        n?.("Sending handshake ACK1", B);
        try {
          r.sendMessage(B);
        } catch (tr) {
          h(new pr("TRANSMISSION_FAILED", tr.message));
          return;
        }
      },
      J = (W) => {
        n?.("Received handshake ACK1", W);
        let Q = { namespace: Jr, channel: o, type: "ACK2" };
        n?.("Sending handshake ACK2", Q);
        try {
          r.sendMessage(Q);
        } catch (B) {
          h(new pr("TRANSMISSION_FAILED", B.message));
          return;
        }
        D();
      },
      V = (W) => {
        n?.("Received handshake ACK2", W), D();
      },
      X = (W) => {
        if (Yt(W)) _(W);
        if (Wi(W)) J(W);
        if (zn(W)) V(W);
      };
    return (
      r.addMessageHandler(X),
      u.push(() => r.removeMessageHandler(X)),
      O(),
      m);

  },
  N6 = G6,
  B6 = (r) => {
    let t = !1,
      i;
    return (...o) => {
      if (!t) t = !0, i = r(...o);
      return i;
    };
  },
  y6 = B6,
  v$ = new WeakSet(),
  A6 = ({ messenger: r, methods: t = {}, timeout: i, channel: o, log: n }) => {
    if (!r) throw new pr("INVALID_ARGUMENT", "messenger must be defined");
    if (v$.has(r))
    throw new pr(
      "INVALID_ARGUMENT",
      "A messenger can only be used for a single connection"
    );
    v$.add(r);
    let e = [r.destroy],
      l = y6((c) => {
        if (c) {
          let m = { namespace: Jr, channel: o, type: "DESTROY" };
          try {
            r.sendMessage(m);
          } catch (v) {}
        }
        for (let m of e) m();
        n?.("Connection destroyed");
      }),
      u = (c) => {
        return j6(c) && c.channel === o;
      };
    return {
      promise: (async () => {
        try {
          r.initialize({ log: n, validateReceivedMessage: u }),
          r.addMessageHandler((v) => {
            if (O6(v)) l(!1);
          });
          let { remoteProxy: c, destroy: m } = await N6({
            messenger: r,
            methods: t,
            timeout: i,
            channel: o,
            log: n
          });
          return e.push(m), c;
        } catch (c) {
          throw l(!0), c;
        }
      })(),
      destroy: () => {
        l(!0);
      }
    };
  },
  p$ = A6,
  H6 = class {
    #r;
    #o;
    #n;
    #t;
    #l;
    #i = new Set();
    #e;
    #c = !1;
    constructor({ remoteWindow: r, allowedOrigins: t }) {
      if (!r) throw new pr("INVALID_ARGUMENT", "remoteWindow must be defined");
      this.#r = r, this.#o = t?.length ? t : [window.origin];
    }
    initialize = ({ log: r, validateReceivedMessage: t }) => {
      this.#n = r,
      this.#t = t,
      window.addEventListener("message", this.#b);
    };
    sendMessage = (r, t) => {
      if (Yt(r)) {
        let i = this.#u(r);
        this.#r.postMessage(r, { targetOrigin: i, transfer: t });
        return;
      }
      if (Wi(r) || this.#c) {
        let i = this.#c ? S6(r) : r,
          o = this.#u(r);
        this.#r.postMessage(i, { targetOrigin: o, transfer: t });
        return;
      }
      if (zn(r)) {
        let { port1: i, port2: o } = new MessageChannel();
        this.#e = i, i.addEventListener("message", this.#g), i.start();
        let n = [o, ...(t || [])],
          e = this.#u(r);
        this.#r.postMessage(r, { targetOrigin: e, transfer: n });
        return;
      }
      if (this.#e) {
        this.#e.postMessage(r, { transfer: t });
        return;
      }
      throw new Et("Port is undefined");
    };
    addMessageHandler = (r) => {
      this.#i.add(r);
    };
    removeMessageHandler = (r) => {
      this.#i.delete(r);
    };
    destroy = () => {
      window.removeEventListener("message", this.#b),
      this.#m(),
      this.#i.clear();
    };
    #v = (r) => {
      return this.#o.some((t) =>
      t instanceof RegExp ? t.test(r) : t === r || t === "*"
      );
    };
    #u = (r) => {
      if (Yt(r)) return "*";
      if (!this.#l) throw new Et("Concrete remote origin not set");
      return this.#l === "null" && this.#o.includes("*") ? "*" : this.#l;
    };
    #m = () => {
      this.#e?.removeEventListener("message", this.#g),
      this.#e?.close(),
      this.#e = void 0;
    };
    #b = ({ source: r, origin: t, ports: i, data: o }) => {
      if (r !== this.#r) return;
      if (E6(o))
      this.#n?.(
        "Please upgrade the child window to the latest version of Penpal."
      ),
      this.#c = !0,
      o = F6(o);
      if (!this.#t?.(o)) return;
      if (!this.#v(t)) {
        this.#n?.(
          `Received a message from origin \`${t}\` which did not match allowed origins \`[${this.#o.join(", ")}]\``
        );
        return;
      }
      if (Yt(o)) this.#m(), this.#l = t;
      if (zn(o) && !this.#c) {
        if (this.#e = i[0], !this.#e)
        throw new Et("No port received on ACK2");
        this.#e.addEventListener("message", this.#g), this.#e.start();
      }
      for (let n of this.#i) n(o);
    };
    #g = ({ data: r }) => {
      if (!this.#t?.(r)) return;
      for (let t of this.#i) t(r);
    };
  },
  _$ = H6,
  hU = class {
    #r;
    #o;
    #n = new Set();
    #t;
    constructor({ worker: r }) {
      if (!r) throw new pr("INVALID_ARGUMENT", "worker must be defined");
      this.#r = r;
    }
    initialize = ({ validateReceivedMessage: r }) => {
      this.#o = r, this.#r.addEventListener("message", this.#i);
    };
    sendMessage = (r, t) => {
      if (Yt(r) || Wi(r)) {
        this.#r.postMessage(r, { transfer: t });
        return;
      }
      if (zn(r)) {
        let { port1: i, port2: o } = new MessageChannel();
        this.#t = i,
        i.addEventListener("message", this.#i),
        i.start(),
        this.#r.postMessage(r, { transfer: [o, ...(t || [])] });
        return;
      }
      if (this.#t) {
        this.#t.postMessage(r, { transfer: t });
        return;
      }
      throw new Et("Port is undefined");
    };
    addMessageHandler = (r) => {
      this.#n.add(r);
    };
    removeMessageHandler = (r) => {
      this.#n.delete(r);
    };
    destroy = () => {
      this.#r.removeEventListener("message", this.#i),
      this.#l(),
      this.#n.clear();
    };
    #l = () => {
      this.#t?.removeEventListener("message", this.#i),
      this.#t?.close(),
      this.#t = void 0;
    };
    #i = ({ ports: r, data: t }) => {
      if (!this.#o?.(t)) return;
      if (Yt(t)) this.#l();
      if (zn(t)) {
        if (this.#t = r[0], !this.#t)
        throw new Et("No port received on ACK2");
        this.#t.addEventListener("message", this.#i), this.#t.start();
      }
      for (let i of this.#n) i(t);
    };
  };
var $U = class {
  #r;
  #o;
  #n = new Set();
  constructor({ port: r }) {
    if (!r) throw new pr("INVALID_ARGUMENT", "port must be defined");
    this.#r = r;
  }
  initialize = ({ validateReceivedMessage: r }) => {
    this.#o = r,
    this.#r.addEventListener("message", this.#t),
    this.#r.start();
  };
  sendMessage = (r, t) => {
    this.#r?.postMessage(r, { transfer: t });
  };
  addMessageHandler = (r) => {
    this.#n.add(r);
  };
  removeMessageHandler = (r) => {
    this.#n.delete(r);
  };
  destroy = () => {
    this.#r.removeEventListener("message", this.#t),
    this.#r.close(),
    this.#n.clear();
  };
  #t = ({ data: r }) => {
    if (!this.#o?.(r)) return;
    for (let t of this.#n) t(r);
  };
};
var D$ = ["SCRIPT", "STYLE", "LINK", "META", "NOSCRIPT"],
  j$ = new Set([
  "a",
  "abbr",
  "area",
  "audio",
  "b",
  "bdi",
  "bdo",
  "br",
  "button",
  "canvas",
  "cite",
  "code",
  "data",
  "datalist",
  "del",
  "dfn",
  "em",
  "embed",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "li",
  "map",
  "mark",
  "meter",
  "noscript",
  "object",
  "output",
  "p",
  "picture",
  "progress",
  "q",
  "ruby",
  "s",
  "samp",
  "script",
  "select",
  "slot",
  "small",
  "span",
  "strong",
  "sub",
  "sup",
  "svg",
  "template",
  "textarea",
  "time",
  "u",
  "var",
  "video",
  "wbr"]
  );
var Le = ".next-prod";
var qU = {
  SCALE: 0.7,
  PAN_POSITION: { x: 175, y: 100 },
  URL: "http://localhost:3000/",
  ASPECT_RATIO_LOCKED: !1,
  DEVICE: "Custom:Custom",
  THEME: "system",
  ORIENTATION: "Portrait",
  MIN_DIMENSIONS: { width: "280px", height: "360px" },
  COMMANDS: {
    run: "bun run dev",
    build: "bun run build",
    install: "bun install"
  },
  IMAGE_FOLDER: "public",
  IMAGE_DIMENSION: { width: "100px", height: "100px" },
  FONT_FOLDER: "fonts",
  FONT_CONFIG: "app/fonts.ts",
  TAILWIND_CONFIG: "tailwind.config.ts",
  CHAT_SETTINGS: {
    showSuggestions: !0,
    autoApplyCode: !0,
    expandCodeBlocks: !1,
    showMiniChat: !0,
    maxImages: 5
  },
  EDITOR_SETTINGS: {
    shouldWarnDelete: !1,
    enableBunReplace: !0,
    buildFlags: "--no-lint"
  }
};
var Ve = ["node_modules", "dist", "build", ".git", ".next"],
  LU = [...Ve, "static", "out", Le],
  VU = [...Ve, Le],
  YU = [...Ve, "coverage"],
  R6 = [".jsx", ".tsx"],
  M6 = [".js", ".ts", ".mjs", ".cjs"],
  EU = [...R6, ...M6];
var SU = {
  ["en"]: "English",
  ["ja"]: "日本語",
  ["zh"]: "中文",
  ["ko"]: "한국어"
};
var U$ = qh(We(), 1);
function G(r) {
  return document.querySelector(`[${"data-odid"}="${r}"]`);
}
function Ye(r, t = !1) {
  let i = `[${"data-odid"}="${r}"]`;
  if (!t) return i;
  return Z6(i);
}
function Z6(r) {
  return CSS.escape(r);
}
function Dt(r) {
  return (
    r &&
    r instanceof Node &&
    r.nodeType === Node.ELEMENT_NODE &&
    !D$.includes(r.tagName) &&
    !r.hasAttribute("data-onlook-ignore") &&
    r.style.display !== "none");

}
var C6 = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
var O$ = (r = 21) => {
  let t = "",
    i = r | 0;
  while (i--) t += C6[Math.random() * 64 | 0];
  return t;
};
function Pr(r) {
  let t = r.getAttribute("data-odid");
  if (!t) t = `odid-${O$()}`, r.setAttribute("data-odid", t);
  return t;
}
function Gr(r) {
  return r.getAttribute("data-oid");
}
function Nr(r) {
  return r.getAttribute("data-oiid");
}
function I$(r, t) {
  if (!_r) return;
  _r.onDomProcessed({ layerMap: Object.fromEntries(r), rootNode: t }).catch(
    (i) => {
      console.error("Failed to send DOM processed event:", i);
    }
  );
}
function Ee(r) {
  window._onlookFrameId = r;
}
function Qt() {
  let r = window._onlookFrameId;
  if (!r)
  return (
    console.warn("Frame id not found"),
    _r?.getFrameId().then((t) => {
      Ee(t);
    }),
    "");

  return r;
}
function T6(r = document.body) {
  if (!Qt())
  return (
    console.warn("frameView id not found, skipping dom processing"),
    null);

  let i = zr(r);
  if (!i)
  return (
    console.warn("Error building layer tree, root element is null"),
    null);

  let o = r.getAttribute("data-odid");
  if (!o) return console.warn("Root dom id not found"), null;
  let n = i.get(o);
  if (!n) return console.warn("Root node not found"), null;
  return I$(i, n), { rootDomId: o, layerMap: Array.from(i.entries()) };
}
var Ki = U$.default(T6, 500),
  d6 = [
  (r) => {
    let t = r.parentElement;
    return t && t.tagName.toLowerCase() === "svg";
  },
  (r) => {
    return r.tagName.toLowerCase() === "next-route-announcer";
  },
  (r) => {
    return r.tagName.toLowerCase() === "nextjs-portal";
  }];

function zr(r) {
  if (!Dt(r)) return null;
  let t = new Map(),
    i = document.createTreeWalker(r, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (e) => {
        let l = e;
        if (d6.some((u) => u(l))) return NodeFilter.FILTER_REJECT;
        return Dt(l) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    }),
    o = k$(r);
  o.children = [], t.set(o.domId, o);
  let n = i.nextNode();
  while (n) {
    let e = k$(n);
    e.children = [];
    let l = n.parentElement;
    if (l) {
      let u = l.getAttribute("data-odid");
      if (u) {
        e.parent = u;
        let g = t.get(u);
        if (g && g.children) g.children.push(e.domId);
      }
    }
    t.set(e.domId, e), n = i.nextNode();
  }
  return t;
}
function k$(r) {
  let t = Pr(r),
    i = Gr(r),
    o = Nr(r),
    n = Array.from(r.childNodes).
    map((g) => g.nodeType === Node.TEXT_NODE ? g.textContent : "").
    join(" ").
    trim().
    slice(0, 500),
    e = window.getComputedStyle(r),
    l = r.getAttribute("data-ocname");
  return {
    domId: t,
    oid: i || null,
    instanceId: o || null,
    textContent: n || "",
    tagName: r.tagName.toLowerCase(),
    isVisible: e.visibility !== "hidden",
    component: l || null,
    frameId: Qt(),
    children: null,
    parent: null,
    dynamicType: null,
    coreElementType: null
  };
}
function Qe(r) {
  throw new Error(`Expected \`never\`, found: ${JSON.stringify(r)}`);
}
var J$ = (r) => JSON.parse(JSON.stringify(r));
function P$(r) {
  let t = q$(r),
    i = s6(r),
    o = rz(r);
  return {
    defined: { width: "auto", height: "auto", ...i, ...o },
    computed: t
  };
}
function X$(r) {
  let t = G(r);
  if (!t) return {};
  return q$(t);
}
function q$(r) {
  return J$(window.getComputedStyle(r));
}
function s6(r) {
  let t = {},
    i = W$(r.style.cssText);
  return (
    Object.entries(i).forEach(([o, n]) => {
      t[o] = n;
    }),
    t);

}
function rz(r) {
  let t = {},
    i = document.styleSheets;
  for (let o = 0; o < i.length; o++) {
    let n,
      e = i[o];
    try {
      if (!e) {
        console.warn("Sheet is undefined");
        continue;
      }
      n = Array.from(e.cssRules) || e.rules;
    } catch (l) {
      console.warn("Can't read the css rules of: " + e?.href, l);
      continue;
    }
    for (let l = 0; l < n.length; l++)
    try {
      let u = n[l];
      if (u && r.matches(u.selectorText)) {
        let g = W$(u.style.cssText);
        Object.entries(g).forEach(([c, m]) => t[c] = m);
      }
    } catch (u) {
      console.warn("Error", u);
    }
  }
  return t;
}
function W$(r) {
  let t = {};
  return (
    r.split(";").forEach((i) => {
      if (i = i.trim(), !i) return;
      let [o, ...n] = i.split(":");
      t[o?.trim() ?? ""] = n.join(":").trim();
    }),
    t);

}
var K$ = (r, t) => {
    let i = document.elementFromPoint(r, t);
    if (!i) return;
    let o = (e) => {
      if (e?.shadowRoot) {
        let l = e.shadowRoot.elementFromPoint(r, t);
        if (l == e) return e;else
        if (l?.shadowRoot) return o(l);else
        return l || e;
      } else return e;
    };
    return o(i) || i;
  },
  lr = (r, t) => {
    let i = r.parentElement,
      o = i ?
      {
        domId: i.getAttribute("data-odid"),
        frameId: Qt(),
        oid: i.getAttribute("data-oid"),
        instanceId: i.getAttribute("data-oiid"),
        rect: i.getBoundingClientRect()
      } :
      null,
      n = r.getBoundingClientRect(),
      e = t ? P$(r) : null;
    return {
      domId: r.getAttribute("data-odid"),
      oid: r.getAttribute("data-oid"),
      frameId: Qt(),
      instanceId: r.getAttribute("data-oiid"),
      rect: n,
      tagName: r.tagName,
      parent: o,
      styles: e
    };
  };
function Li(r) {
  try {
    let t = r.getAttribute("data-onlook-drag-saved-style");
    if (t) {
      let i = JSON.parse(t);
      for (let o in i) r.style[o] = i[o];
    }
  } catch (t) {
    console.warn("Error restoring style", t);
  }
}
function L$(r) {
  let t = r.parentElement;
  if (!t) return;
  return {
    type: "index",
    targetDomId: t.getAttribute("data-odid"),
    targetOid: Nr(t) || Gr(t) || null,
    index: Array.from(r.parentElement?.children || []).indexOf(r),
    originalIndex: Array.from(r.parentElement?.children || []).indexOf(r)
  };
}
var V$ = (r) => {
  let t = Array.from(r.childNodes).
  filter((i) => i.nodeType === Node.TEXT_NODE).
  map((i) => i.textContent);
  if (t.length === 0) return;
  return t.join("");
};
var Vi = (r, t) => {
    let i = G(r) || document.body;
    return lr(i, t);
  },
  Y$ = (r, t, i) => {
    let o = tz(r, t) || document.body;
    return lr(o, i);
  },
  tz = (r, t) => {
    let i = document.elementFromPoint(r, t);
    if (!i) return;
    let o = (e) => {
      if (e?.shadowRoot) {
        let l = e.shadowRoot.elementFromPoint(r, t);
        if (l == e) return e;else
        if (l?.shadowRoot) return o(l);else
        return l || e;
      } else return e;
    };
    return o(i) || i;
  },
  E$ = (r, t, i) => {
    let o = G(r);
    if (!o) {
      console.warn("Failed to updateElementInstanceId: Element not found");
      return;
    }
    o.setAttribute("data-oiid", t), o.setAttribute("data-ocname", i);
  },
  Q$ = (r) => {
    let t = G(r);
    if (!t?.parentElement) return null;
    return lr(t.parentElement, !1);
  },
  F$ = (r) => {
    let t = G(r);
    if (!t) return 0;
    return t.children.length;
  },
  S$ = (r) => {
    let t = G(r);
    if (!t) return null;
    return lr(t.offsetParent, !1);
  };
function G$(r, t, i) {
  let o = G(r.domId);
  if (!o) return console.warn("Failed to find parent element", r.domId), null;
  let n = nz(t),
    e = new Set(i.map((c) => c.domId)),
    l = Array.from(o.children).
    map((c, m) => ({ element: c, index: m, domId: Pr(c) })).
    filter(({ domId: c }) => e.has(c));
  if (l.length === 0)
  return console.warn("No valid children found to group"), null;
  let u = Math.min(...l.map((c) => c.index));
  return (
    o.insertBefore(n, o.children[u] ?? null),
    l.forEach(({ element: c }) => {
      let m = c.cloneNode(!0);
      m.setAttribute("data-onlook-inserted", "true"),
      n.appendChild(m),
      c.style.display = "none",
      B$(c);
    }),
    { domEl: lr(n, !0), newMap: zr(n) });

}
function N$(r, t) {
  let i = G(r.domId);
  if (!i) return console.warn(`Parent element not found: ${r.domId}`), null;
  let o;
  if (t.domId) o = G(t.domId);else

  return console.warn("Container domId is required for ungrouping"), null;
  if (!o)
  return console.warn("Container element not found for ungrouping"), null;
  return (
    Array.from(o.children).forEach((l) => {
      i.appendChild(l);
    }),
    o.remove(),
    { domEl: lr(i, !0), newMap: zr(i) });

}
function nz(r) {
  let t = document.createElement(r.tagName);
  return (
    Object.entries(r.attributes).forEach(([i, o]) => {
      t.setAttribute(i, o);
    }),
    t.setAttribute("data-onlook-inserted", "true"),
    t.setAttribute("data-odid", r.domId),
    t.setAttribute("data-oid", r.oid),
    t);

}
function B$(r) {
  r.removeAttribute("data-odid"),
  r.removeAttribute("data-oid"),
  r.removeAttribute("data-onlook-inserted");
  let t = Array.from(r.children);
  if (t.length === 0) return;
  t.forEach((i) => {
    B$(i);
  });
}
function Yi(r) {
  let t = G(r);
  if (!t) return console.warn("Element not found for domId:", r), null;
  return y$(t);
}
function y$(r) {
  let t = Array.from(r.attributes).reduce((o, n) => {
      return o[n.name] = n.value, o;
    }, {}),
    i = Nr(r) || Gr(r) || null;
  if (!i) return console.warn("Element has no oid"), null;
  return {
    oid: i,
    domId: Pr(r),
    tagName: r.tagName.toLowerCase(),
    children: Array.from(r.children).
    map((o) => y$(o)).
    filter(Boolean),
    attributes: t,
    textContent: V$(r) || null,
    styles: {}
  };
}
function A$(r) {
  let t = G(r);
  if (!t) throw new Error("Element not found for domId: " + r);
  let i = t.parentElement;
  if (!i) throw new Error("Inserted element has no parent");
  let o = Nr(i) || Gr(i);
  if (!o) return console.warn("Parent element has no oid"), null;
  let n = Pr(i),
    e = Array.from(i.children).indexOf(t);
  if (e === -1) return { type: "append", targetDomId: n, targetOid: o };
  return {
    type: "index",
    targetDomId: n,
    targetOid: o,
    index: e,
    originalIndex: e
  };
}
function H$(r) {
  let t = document.querySelector(`[${"data-odid"}="${r}"]`);
  if (!t)
  return (
    console.warn("No element found", { domId: r }),
    { dynamicType: null, coreType: null });

  let i = t.getAttribute("data-onlook-dynamic-type") || null,
    o = t.getAttribute("data-onlook-core-element-type") || null;
  return { dynamicType: i, coreType: o };
}
function R$(r, t, i) {
  let o = document.querySelector(`[${"data-odid"}="${r}"]`);
  if (o) {
    if (t) o.setAttribute("data-onlook-dynamic-type", t);
    if (i) o.setAttribute("data-onlook-core-element-type", i);
  }
}
function M$() {
  let t = document.body.querySelector(`[${"data-oid"}]`);
  if (t) return lr(t, !0);
  return null;
}
var Qr = 0,
  w = 1,
  k = 2,
  R = 3,
  S = 4,
  gr = 5,
  Ft = 6,
  er = 7,
  fr = 8,
  P = 9,
  U = 10,
  y = 11,
  q = 12,
  Y = 13,
  dr = 14,
  hr = 15,
  d = 16,
  nr = 17,
  ir = 18,
  mr = 19,
  wr = 20,
  K = 21,
  j = 22,
  Z = 23,
  xr = 24,
  A = 25;
function cr(r) {
  return r >= 48 && r <= 57;
}
function Or(r) {
  return cr(r) || r >= 65 && r <= 70 || r >= 97 && r <= 102;
}
function Fi(r) {
  return r >= 65 && r <= 90;
}
function iz(r) {
  return r >= 97 && r <= 122;
}
function oz(r) {
  return Fi(r) || iz(r);
}
function ez(r) {
  return r >= 128;
}
function Qi(r) {
  return oz(r) || ez(r) || r === 95;
}
function an(r) {
  return Qi(r) || cr(r) || r === 45;
}
function lz(r) {
  return r >= 0 && r <= 8 || r === 11 || r >= 14 && r <= 31 || r === 127;
}
function pn(r) {
  return r === 10 || r === 13 || r === 12;
}
function Br(r) {
  return pn(r) || r === 32 || r === 9;
}
function Dr(r, t) {
  if (r !== 92) return !1;
  if (pn(t) || t === 0) return !1;
  return !0;
}
function St(r, t, i) {
  if (r === 45) return Qi(t) || t === 45 || Dr(t, i);
  if (Qi(r)) return !0;
  if (r === 92) return Dr(r, t);
  return !1;
}
function Si(r, t, i) {
  if (r === 43 || r === 45) {
    if (cr(t)) return 2;
    return t === 46 && cr(i) ? 3 : 0;
  }
  if (r === 46) return cr(t) ? 2 : 0;
  if (cr(r)) return 1;
  return 0;
}
function Gi(r) {
  if (r === 65279) return 1;
  if (r === 65534) return 1;
  return 0;
}
var Fe = new Array(128),
  cz = 128,
  _n = 130,
  Se = 131,
  Ni = 132,
  Ge = 133;
for (let r = 0; r < Fe.length; r++)
Fe[r] =
Br(r) && _n || cr(r) && Se || Qi(r) && Ni || lz(r) && Ge || r || cz;
function Bi(r) {
  return r < 128 ? Fe[r] : Ni;
}
function Gt(r, t) {
  return t < r.length ? r.charCodeAt(t) : 0;
}
function yi(r, t, i) {
  if (i === 13 && Gt(r, t + 1) === 10) return 2;
  return 1;
}
function sr(r, t, i) {
  let o = r.charCodeAt(t);
  if (Fi(o)) o = o | 32;
  return o === i;
}
function rt(r, t, i, o) {
  if (i - t !== o.length) return !1;
  if (t < 0 || i > r.length) return !1;
  for (let n = t; n < i; n++) {
    let e = o.charCodeAt(n - t),
      l = r.charCodeAt(n);
    if (Fi(l)) l = l | 32;
    if (l !== e) return !1;
  }
  return !0;
}
function Z$(r, t) {
  for (; t >= 0; t--) if (!Br(r.charCodeAt(t))) break;
  return t + 1;
}
function Dn(r, t) {
  for (; t < r.length; t++) if (!Br(r.charCodeAt(t))) break;
  return t;
}
function Ne(r, t) {
  for (; t < r.length; t++) if (!cr(r.charCodeAt(t))) break;
  return t;
}
function yr(r, t) {
  if (t += 2, Or(Gt(r, t - 1))) {
    for (let o = Math.min(r.length, t + 5); t < o; t++)
    if (!Or(Gt(r, t))) break;
    let i = Gt(r, t);
    if (Br(i)) t += yi(r, t, i);
  }
  return t;
}
function jn(r, t) {
  for (; t < r.length; t++) {
    let i = r.charCodeAt(t);
    if (an(i)) continue;
    if (Dr(i, Gt(r, t + 1))) {
      t = yr(r, t) - 1;
      continue;
    }
    break;
  }
  return t;
}
function jt(r, t) {
  let i = r.charCodeAt(t);
  if (i === 43 || i === 45) i = r.charCodeAt(t += 1);
  if (cr(i)) t = Ne(r, t + 1), i = r.charCodeAt(t);
  if (i === 46 && cr(r.charCodeAt(t + 1))) t += 2, t = Ne(r, t);
  if (sr(r, t, 101)) {
    let o = 0;
    if (i = r.charCodeAt(t + 1), i === 45 || i === 43)
    o = 1, i = r.charCodeAt(t + 2);
    if (cr(i)) t = Ne(r, t + 1 + o + 1);
  }
  return t;
}
function Ai(r, t) {
  for (; t < r.length; t++) {
    let i = r.charCodeAt(t);
    if (i === 41) {
      t++;
      break;
    }
    if (Dr(i, Gt(r, t + 1))) t = yr(r, t);
  }
  return t;
}
function On(r) {
  if (r.length === 1 && !Or(r.charCodeAt(0))) return r[0];
  let t = parseInt(r, 16);
  if (t === 0 || t >= 55296 && t <= 57343 || t > 1114111) t = 65533;
  return String.fromCodePoint(t);
}
var Nt = [
"EOF-token",
"ident-token",
"function-token",
"at-keyword-token",
"hash-token",
"string-token",
"bad-string-token",
"url-token",
"bad-url-token",
"delim-token",
"number-token",
"percentage-token",
"dimension-token",
"whitespace-token",
"CDO-token",
"CDC-token",
"colon-token",
"semicolon-token",
"comma-token",
"[-token",
"]-token",
"(-token",
")-token",
"{-token",
"}-token",
"comment-token"];

function Bt(r = null, t) {
  if (r === null || r.length < t)
  return new Uint32Array(Math.max(t + 1024, 16384));
  return r;
}
var C$ = 10,
  uz = 12,
  T$ = 13;
function d$(r) {
  let t = r.source,
    i = t.length,
    o = t.length > 0 ? Gi(t.charCodeAt(0)) : 0,
    n = Bt(r.lines, i),
    e = Bt(r.columns, i),
    l = r.startLine,
    u = r.startColumn;
  for (let g = o; g < i; g++) {
    let c = t.charCodeAt(g);
    if (n[g] = l, e[g] = u++, c === C$ || c === T$ || c === uz) {
      if (c === T$ && g + 1 < i && t.charCodeAt(g + 1) === C$)
      g++, n[g] = l, e[g] = u;
      l++, u = 1;
    }
  }
  n[i] = l, e[i] = u, r.lines = n, r.columns = e, r.computed = !0;
}
class Hi {
  constructor(r, t, i, o) {
    this.setSource(r, t, i, o), this.lines = null, this.columns = null;
  }
  setSource(r = "", t = 0, i = 1, o = 1) {
    this.source = r,
    this.startOffset = t,
    this.startLine = i,
    this.startColumn = o,
    this.computed = !1;
  }
  getLocation(r, t) {
    if (!this.computed) d$(this);
    return {
      source: t,
      offset: this.startOffset + r,
      line: this.lines[r],
      column: this.columns[r]
    };
  }
  getLocationRange(r, t, i) {
    if (!this.computed) d$(this);
    return {
      source: i,
      start: {
        offset: this.startOffset + r,
        line: this.lines[r],
        column: this.columns[r]
      },
      end: {
        offset: this.startOffset + t,
        line: this.lines[t],
        column: this.columns[t]
      }
    };
  }
}
var Ar = 16777215,
  Hr = 24,
  Ot = new Uint8Array(32);
Ot[k] = j;
Ot[K] = j;
Ot[mr] = wr;
Ot[Z] = xr;
function s$(r) {
  return Ot[r] !== 0;
}
class Ri {
  constructor(r, t) {
    this.setSource(r, t);
  }
  reset() {
    this.eof = !1,
    this.tokenIndex = -1,
    this.tokenType = 0,
    this.tokenStart = this.firstCharOffset,
    this.tokenEnd = this.firstCharOffset;
  }
  setSource(r = "", t = () => {}) {
    r = String(r || "");
    let i = r.length,
      o = Bt(this.offsetAndType, r.length + 1),
      n = Bt(this.balance, r.length + 1),
      e = 0,
      l = -1,
      u = 0,
      g = r.length;
    this.offsetAndType = null,
    this.balance = null,
    n.fill(0),
    t(r, (c, m, v) => {
      let h = e++;
      if (o[h] = c << Hr | v, l === -1) l = m;
      if (n[h] = g, c === u) {
        let b = n[g];
        n[g] = h, g = b, u = Ot[o[b] >> Hr];
      } else if (s$(c)) g = h, u = Ot[c];
    }),
    o[e] = Qr << Hr | i,
    n[e] = e;
    for (let c = 0; c < e; c++) {
      let m = n[c];
      if (m <= c) {
        let v = n[m];
        if (v !== c) n[c] = v;
      } else if (m > e) n[c] = e;
    }
    this.source = r,
    this.firstCharOffset = l === -1 ? 0 : l,
    this.tokenCount = e,
    this.offsetAndType = o,
    this.balance = n,
    this.reset(),
    this.next();
  }
  lookupType(r) {
    if (r += this.tokenIndex, r < this.tokenCount)
    return this.offsetAndType[r] >> Hr;
    return Qr;
  }
  lookupTypeNonSC(r) {
    for (let t = this.tokenIndex; t < this.tokenCount; t++) {
      let i = this.offsetAndType[t] >> Hr;
      if (i !== Y && i !== A) {
        if (r-- === 0) return i;
      }
    }
    return Qr;
  }
  lookupOffset(r) {
    if (r += this.tokenIndex, r < this.tokenCount)
    return this.offsetAndType[r - 1] & Ar;
    return this.source.length;
  }
  lookupOffsetNonSC(r) {
    for (let t = this.tokenIndex; t < this.tokenCount; t++) {
      let i = this.offsetAndType[t] >> Hr;
      if (i !== Y && i !== A) {
        if (r-- === 0) return t - this.tokenIndex;
      }
    }
    return Qr;
  }
  lookupValue(r, t) {
    if (r += this.tokenIndex, r < this.tokenCount)
    return rt(
      this.source,
      this.offsetAndType[r - 1] & Ar,
      this.offsetAndType[r] & Ar,
      t
    );
    return !1;
  }
  getTokenStart(r) {
    if (r === this.tokenIndex) return this.tokenStart;
    if (r > 0)
    return r < this.tokenCount ?
    this.offsetAndType[r - 1] & Ar :
    this.offsetAndType[this.tokenCount] & Ar;
    return this.firstCharOffset;
  }
  substrToCursor(r) {
    return this.source.substring(r, this.tokenStart);
  }
  isBalanceEdge(r) {
    return this.balance[this.tokenIndex] < r;
  }
  isDelim(r, t) {
    if (t)
    return (
      this.lookupType(t) === P &&
      this.source.charCodeAt(this.lookupOffset(t)) === r);

    return (
      this.tokenType === P && this.source.charCodeAt(this.tokenStart) === r);

  }
  skip(r) {
    let t = this.tokenIndex + r;
    if (t < this.tokenCount)
    this.tokenIndex = t,
    this.tokenStart = this.offsetAndType[t - 1] & Ar,
    t = this.offsetAndType[t],
    this.tokenType = t >> Hr,
    this.tokenEnd = t & Ar;else
    this.tokenIndex = this.tokenCount, this.next();
  }
  next() {
    let r = this.tokenIndex + 1;
    if (r < this.tokenCount)
    this.tokenIndex = r,
    this.tokenStart = this.tokenEnd,
    r = this.offsetAndType[r],
    this.tokenType = r >> Hr,
    this.tokenEnd = r & Ar;else

    this.eof = !0,
    this.tokenIndex = this.tokenCount,
    this.tokenType = Qr,
    this.tokenStart = this.tokenEnd = this.source.length;
  }
  skipSC() {
    while (this.tokenType === Y || this.tokenType === A) this.next();
  }
  skipUntilBalanced(r, t) {
    let i = r,
      o = 0,
      n = 0;
    r: for (; i < this.tokenCount; i++) {
      if (o = this.balance[i], o < r) break r;
      switch (
      n = i > 0 ? this.offsetAndType[i - 1] & Ar : this.firstCharOffset,
      t(this.source.charCodeAt(n))) {

        case 1:
          break r;
        case 2:
          i++;
          break r;
        default:
          if (s$(this.offsetAndType[i] >> Hr)) i = o;
      }
    }
    this.skip(i - this.tokenIndex);
  }
  forEachToken(r) {
    for (let t = 0, i = this.firstCharOffset; t < this.tokenCount; t++) {
      let o = i,
        n = this.offsetAndType[t],
        e = n & Ar,
        l = n >> Hr;
      i = e, r(l, o, e, t);
    }
  }
  dump() {
    let r = new Array(this.tokenCount);
    return (
      this.forEachToken((t, i, o, n) => {
        r[n] = {
          idx: n,
          type: Nt[t],
          chunk: this.source.substring(i, o),
          balance: this.balance[n]
        };
      }),
      r);

  }
}
function bt(r, t) {
  function i(v) {
    return v < u ? r.charCodeAt(v) : 0;
  }
  function o() {
    if (c = jt(r, c), St(i(c), i(c + 1), i(c + 2))) {
      m = q, c = jn(r, c);
      return;
    }
    if (i(c) === 37) {
      m = y, c++;
      return;
    }
    m = U;
  }
  function n() {
    let v = c;
    if (c = jn(r, c), rt(r, v, c, "url") && i(c) === 40) {
      if (c = Dn(r, c + 1), i(c) === 34 || i(c) === 39) {
        m = k, c = v + 4;
        return;
      }
      l();
      return;
    }
    if (i(c) === 40) {
      m = k, c++;
      return;
    }
    m = w;
  }
  function e(v) {
    if (!v) v = i(c++);
    m = gr;
    for (; c < r.length; c++) {
      let h = r.charCodeAt(c);
      switch (Bi(h)) {
        case v:
          c++;
          return;
        case _n:
          if (pn(h)) {
            c += yi(r, c, h), m = Ft;
            return;
          }
          break;
        case 92:
          if (c === r.length - 1) break;
          let b = i(c + 1);
          if (pn(b)) c += yi(r, c + 1, b);else
          if (Dr(h, b)) c = yr(r, c) - 1;
          break;
      }
    }
  }
  function l() {
    m = er, c = Dn(r, c);
    for (; c < r.length; c++) {
      let v = r.charCodeAt(c);
      switch (Bi(v)) {
        case 41:
          c++;
          return;
        case _n:
          if (c = Dn(r, c), i(c) === 41 || c >= r.length) {
            if (c < r.length) c++;
            return;
          }
          c = Ai(r, c), m = fr;
          return;
        case 34:
        case 39:
        case 40:
        case Ge:
          c = Ai(r, c), m = fr;
          return;
        case 92:
          if (Dr(v, i(c + 1))) {
            c = yr(r, c) - 1;
            break;
          }
          c = Ai(r, c), m = fr;
          return;
      }
    }
  }
  r = String(r || "");
  let u = r.length,
    g = Gi(i(0)),
    c = g,
    m;
  while (c < u) {
    let v = r.charCodeAt(c);
    switch (Bi(v)) {
      case _n:
        m = Y, c = Dn(r, c + 1);
        break;
      case 34:
        e();
        break;
      case 35:
        if (an(i(c + 1)) || Dr(i(c + 1), i(c + 2)))
        m = S, c = jn(r, c + 1);else
        m = P, c++;
        break;
      case 39:
        e();
        break;
      case 40:
        m = K, c++;
        break;
      case 41:
        m = j, c++;
        break;
      case 43:
        if (Si(v, i(c + 1), i(c + 2))) o();else
        m = P, c++;
        break;
      case 44:
        m = ir, c++;
        break;
      case 45:
        if (Si(v, i(c + 1), i(c + 2))) o();else
        if (i(c + 1) === 45 && i(c + 2) === 62) m = hr, c = c + 3;else
        if (St(v, i(c + 1), i(c + 2))) n();else
        m = P, c++;
        break;
      case 46:
        if (Si(v, i(c + 1), i(c + 2))) o();else
        m = P, c++;
        break;
      case 47:
        if (i(c + 1) === 42)
        m = A,
        c = r.indexOf("*/", c + 2),
        c = c === -1 ? r.length : c + 2;else
        m = P, c++;
        break;
      case 58:
        m = d, c++;
        break;
      case 59:
        m = nr, c++;
        break;
      case 60:
        if (i(c + 1) === 33 && i(c + 2) === 45 && i(c + 3) === 45)
        m = dr, c = c + 4;else
        m = P, c++;
        break;
      case 64:
        if (St(i(c + 1), i(c + 2), i(c + 3))) m = R, c = jn(r, c + 1);else
        m = P, c++;
        break;
      case 91:
        m = mr, c++;
        break;
      case 92:
        if (Dr(v, i(c + 1))) n();else
        m = P, c++;
        break;
      case 93:
        m = wr, c++;
        break;
      case 123:
        m = Z, c++;
        break;
      case 125:
        m = xr, c++;
        break;
      case Se:
        o();
        break;
      case Ni:
        n();
        break;
      default:
        m = P, c++;
    }
    t(m, g, g = c);
  }
}
var yt = null;
class or {
  static createItem(r) {
    return { prev: null, next: null, data: r };
  }
  constructor() {
    this.head = null, this.tail = null, this.cursor = null;
  }
  createItem(r) {
    return or.createItem(r);
  }
  allocateCursor(r, t) {
    let i;
    if (yt !== null)
    i = yt,
    yt = yt.cursor,
    i.prev = r,
    i.next = t,
    i.cursor = this.cursor;else
    i = { prev: r, next: t, cursor: this.cursor };
    return this.cursor = i, i;
  }
  releaseCursor() {
    let { cursor: r } = this;
    this.cursor = r.cursor,
    r.prev = null,
    r.next = null,
    r.cursor = yt,
    yt = r;
  }
  updateCursors(r, t, i, o) {
    let { cursor: n } = this;
    while (n !== null) {
      if (n.prev === r) n.prev = t;
      if (n.next === i) n.next = o;
      n = n.cursor;
    }
  }
  *[Symbol.iterator]() {
    for (let r = this.head; r !== null; r = r.next) yield r.data;
  }
  get size() {
    let r = 0;
    for (let t = this.head; t !== null; t = t.next) r++;
    return r;
  }
  get isEmpty() {
    return this.head === null;
  }
  get first() {
    return this.head && this.head.data;
  }
  get last() {
    return this.tail && this.tail.data;
  }
  fromArray(r) {
    let t = null;
    this.head = null;
    for (let i of r) {
      let o = or.createItem(i);
      if (t !== null) t.next = o;else
      this.head = o;
      o.prev = t, t = o;
    }
    return this.tail = t, this;
  }
  toArray() {
    return [...this];
  }
  toJSON() {
    return [...this];
  }
  forEach(r, t = this) {
    let i = this.allocateCursor(null, this.head);
    while (i.next !== null) {
      let o = i.next;
      i.next = o.next, r.call(t, o.data, o, this);
    }
    this.releaseCursor();
  }
  forEachRight(r, t = this) {
    let i = this.allocateCursor(this.tail, null);
    while (i.prev !== null) {
      let o = i.prev;
      i.prev = o.prev, r.call(t, o.data, o, this);
    }
    this.releaseCursor();
  }
  reduce(r, t, i = this) {
    let o = this.allocateCursor(null, this.head),
      n = t,
      e;
    while (o.next !== null)
    e = o.next, o.next = e.next, n = r.call(i, n, e.data, e, this);
    return this.releaseCursor(), n;
  }
  reduceRight(r, t, i = this) {
    let o = this.allocateCursor(this.tail, null),
      n = t,
      e;
    while (o.prev !== null)
    e = o.prev, o.prev = e.prev, n = r.call(i, n, e.data, e, this);
    return this.releaseCursor(), n;
  }
  some(r, t = this) {
    for (let i = this.head; i !== null; i = i.next)
    if (r.call(t, i.data, i, this)) return !0;
    return !1;
  }
  map(r, t = this) {
    let i = new or();
    for (let o = this.head; o !== null; o = o.next)
    i.appendData(r.call(t, o.data, o, this));
    return i;
  }
  filter(r, t = this) {
    let i = new or();
    for (let o = this.head; o !== null; o = o.next)
    if (r.call(t, o.data, o, this)) i.appendData(o.data);
    return i;
  }
  nextUntil(r, t, i = this) {
    if (r === null) return;
    let o = this.allocateCursor(null, r);
    while (o.next !== null) {
      let n = o.next;
      if (o.next = n.next, t.call(i, n.data, n, this)) break;
    }
    this.releaseCursor();
  }
  prevUntil(r, t, i = this) {
    if (r === null) return;
    let o = this.allocateCursor(r, null);
    while (o.prev !== null) {
      let n = o.prev;
      if (o.prev = n.prev, t.call(i, n.data, n, this)) break;
    }
    this.releaseCursor();
  }
  clear() {
    this.head = null, this.tail = null;
  }
  copy() {
    let r = new or();
    for (let t of this) r.appendData(t);
    return r;
  }
  prepend(r) {
    if (this.updateCursors(null, r, this.head, r), this.head !== null)
    this.head.prev = r, r.next = this.head;else
    this.tail = r;
    return this.head = r, this;
  }
  prependData(r) {
    return this.prepend(or.createItem(r));
  }
  append(r) {
    return this.insert(r);
  }
  appendData(r) {
    return this.insert(or.createItem(r));
  }
  insert(r, t = null) {
    if (t !== null) {
      if (this.updateCursors(t.prev, r, t, r), t.prev === null) {
        if (this.head !== t) throw new Error("before doesn't belong to list");
        this.head = r,
        t.prev = r,
        r.next = t,
        this.updateCursors(null, r);
      } else t.prev.next = r, r.prev = t.prev, t.prev = r, r.next = t;
    } else {
      if (this.updateCursors(this.tail, r, null, r), this.tail !== null)
      this.tail.next = r, r.prev = this.tail;else
      this.head = r;
      this.tail = r;
    }
    return this;
  }
  insertData(r, t) {
    return this.insert(or.createItem(r), t);
  }
  remove(r) {
    if (this.updateCursors(r, r.prev, r, r.next), r.prev !== null)
    r.prev.next = r.next;else
    {
      if (this.head !== r) throw new Error("item doesn't belong to list");
      this.head = r.next;
    }
    if (r.next !== null) r.next.prev = r.prev;else
    {
      if (this.tail !== r) throw new Error("item doesn't belong to list");
      this.tail = r.prev;
    }
    return r.prev = null, r.next = null, r;
  }
  push(r) {
    this.insert(or.createItem(r));
  }
  pop() {
    return this.tail !== null ? this.remove(this.tail) : null;
  }
  unshift(r) {
    this.prepend(or.createItem(r));
  }
  shift() {
    return this.head !== null ? this.remove(this.head) : null;
  }
  prependList(r) {
    return this.insertList(r, this.head);
  }
  appendList(r) {
    return this.insertList(r);
  }
  insertList(r, t) {
    if (r.head === null) return this;
    if (t !== void 0 && t !== null) {
      if (this.updateCursors(t.prev, r.tail, t, r.head), t.prev !== null)
      t.prev.next = r.head, r.head.prev = t.prev;else
      this.head = r.head;
      t.prev = r.tail, r.tail.next = t;
    } else {
      if (
      this.updateCursors(this.tail, r.tail, null, r.head),
      this.tail !== null)

      this.tail.next = r.head, r.head.prev = this.tail;else
      this.head = r.head;
      this.tail = r.tail;
    }
    return r.head = null, r.tail = null, this;
  }
  replace(r, t) {
    if ("head" in t) this.insertList(t, r);else
    this.insert(t, r);
    this.remove(r);
  }
}
function It(r, t) {
  let i = Object.create(SyntaxError.prototype),
    o = new Error();
  return Object.assign(i, {
    name: r,
    message: t,
    get stack() {
      return (o.stack || "").replace(
        /^(.+\n){1,3}/,
        `${r}: ${t}
`
      );
    }
  });
}
var Be = 100,
  r0 = 60,
  t0 = "    ";
function n0({ source: r, line: t, column: i, baseLine: o, baseColumn: n }, e) {
  function l(f, D) {
    return c.slice(f, D).map((O, _) => String(f + _ + 1).padStart(h) + " |" + O).
    join(`
`);
  }
  let u = `
`.repeat(Math.max(o - 1, 0)),
    g = " ".repeat(Math.max(n - 1, 0)),
    c = (u + g + r).split(/\r\n?|\n|\f/),
    m = Math.max(1, t - e) - 1,
    v = Math.min(t + e, c.length + 1),
    h = Math.max(4, String(v).length) + 1,
    b = 0;
  if (
  i +=
  (t0.length - 1) * (c[t - 1].substr(0, i - 1).match(/\t/g) || []).length,
  i > Be)

  b = i - r0 + 3, i = r0 - 2;
  for (let f = m; f <= v; f++)
  if (f >= 0 && f < c.length)
  c[f] = c[f].replace(/\t/g, t0),
  c[f] =
  (b > 0 && c[f].length > b ? "…" : "") +
  c[f].substr(b, Be - 2) + (
  c[f].length > b + Be - 1 ? "…" : "");
  return [l(m, t), new Array(i + h + 2).join("-") + "^", l(t, v)].
  filter(Boolean).
  join(
    `
`
  ).
  replace(/^(\s+\d+\s+\|\n)+/, "").
  replace(/\n(\s+\d+\s+\|)+$/, "");
}
function ye(r, t, i, o, n, e = 1, l = 1) {
  return Object.assign(It("SyntaxError", r), {
    source: t,
    offset: i,
    line: o,
    column: n,
    sourceFragment(g) {
      return n0(
        { source: t, line: o, column: n, baseLine: e, baseColumn: l },
        isNaN(g) ? 0 : g
      );
    },
    get formattedMessage() {
      return (
        `Parse error: ${r}
` + n0({ source: t, line: o, column: n, baseLine: e, baseColumn: l }, 2));

    }
  });
}
function i0(r) {
  let t = this.createList(),
    i = !1,
    o = { recognizer: r };
  while (!this.eof) {
    switch (this.tokenType) {
      case A:
        this.next();
        continue;
      case Y:
        i = !0, this.next();
        continue;
    }
    let n = r.getNode.call(this, o);
    if (n === void 0) break;
    if (i) {
      if (r.onWhiteSpace) r.onWhiteSpace.call(this, n, t, o);
      i = !1;
    }
    t.push(n);
  }
  if (i && r.onWhiteSpace) r.onWhiteSpace.call(this, null, t, o);
  return t;
}
var o0 = () => {},
  gz = 33,
  mz = 35,
  Ae = 59,
  e0 = 123,
  l0 = 0;
function bz(r) {
  return function () {
    return this[r]();
  };
}
function He(r) {
  let t = Object.create(null);
  for (let i of Object.keys(r)) {
    let o = r[i],
      n = o.parse || o;
    if (n) t[i] = n;
  }
  return t;
}
function vz(r) {
  let t = {
    context: Object.create(null),
    features: Object.assign(Object.create(null), r.features),
    scope: Object.assign(Object.create(null), r.scope),
    atrule: He(r.atrule),
    pseudo: He(r.pseudo),
    node: He(r.node)
  };
  for (let [i, o] of Object.entries(r.parseContext))
  switch (typeof o) {
    case "function":
      t.context[i] = o;
      break;
    case "string":
      t.context[i] = bz(o);
      break;
  }
  return { config: t, ...t, ...t.node };
}
function c0(r) {
  let t = "",
    i = "<unknown>",
    o = !1,
    n = o0,
    e = !1,
    l = new Hi(),
    u = Object.assign(new Ri(), vz(r || {}), {
      parseAtrulePrelude: !0,
      parseRulePrelude: !0,
      parseValue: !0,
      parseCustomProperty: !1,
      readSequence: i0,
      consumeUntilBalanceEnd: () => 0,
      consumeUntilLeftCurlyBracket(c) {
        return c === e0 ? 1 : 0;
      },
      consumeUntilLeftCurlyBracketOrSemicolon(c) {
        return c === e0 || c === Ae ? 1 : 0;
      },
      consumeUntilExclamationMarkOrSemicolon(c) {
        return c === gz || c === Ae ? 1 : 0;
      },
      consumeUntilSemicolonIncluded(c) {
        return c === Ae ? 2 : 0;
      },
      createList() {
        return new or();
      },
      createSingleNodeList(c) {
        return new or().appendData(c);
      },
      getFirstListNode(c) {
        return c && c.first;
      },
      getLastListNode(c) {
        return c && c.last;
      },
      parseWithFallback(c, m) {
        let v = this.tokenIndex;
        try {
          return c.call(this);
        } catch (h) {
          if (e) throw h;
          this.skip(v - this.tokenIndex);
          let b = m.call(this);
          return e = !0, n(h, b), e = !1, b;
        }
      },
      lookupNonWSType(c) {
        let m;
        do if (m = this.lookupType(c++), m !== Y && m !== A) return m; while (
        m !== l0);
        return l0;
      },
      charCodeAt(c) {
        return c >= 0 && c < t.length ? t.charCodeAt(c) : 0;
      },
      substring(c, m) {
        return t.substring(c, m);
      },
      substrToCursor(c) {
        return this.source.substring(c, this.tokenStart);
      },
      cmpChar(c, m) {
        return sr(t, c, m);
      },
      cmpStr(c, m, v) {
        return rt(t, c, m, v);
      },
      consume(c) {
        let m = this.tokenStart;
        return this.eat(c), this.substrToCursor(m);
      },
      consumeFunctionName() {
        let c = t.substring(this.tokenStart, this.tokenEnd - 1);
        return this.eat(k), c;
      },
      consumeNumber(c) {
        let m = t.substring(this.tokenStart, jt(t, this.tokenStart));
        return this.eat(c), m;
      },
      eat(c) {
        if (this.tokenType !== c) {
          let m = Nt[c].
            slice(0, -6).
            replace(/-/g, " ").
            replace(/^./, (b) => b.toUpperCase()),
            v = `${/[[\](){}]/.test(m) ? `"${m}"` : m} is expected`,
            h = this.tokenStart;
          switch (c) {
            case w:
              if (this.tokenType === k || this.tokenType === er)
              h = this.tokenEnd - 1,
              v = "Identifier is expected but function found";else
              v = "Identifier is expected";
              break;
            case S:
              if (this.isDelim(mz))
              this.next(), h++, v = "Name is expected";
              break;
            case y:
              if (this.tokenType === U)
              h = this.tokenEnd, v = "Percent sign is expected";
              break;
          }
          this.error(v, h);
        }
        this.next();
      },
      eatIdent(c) {
        if (this.tokenType !== w || this.lookupValue(0, c) === !1)
        this.error(`Identifier "${c}" is expected`);
        this.next();
      },
      eatDelim(c) {
        if (!this.isDelim(c))
        this.error(`Delim "${String.fromCharCode(c)}" is expected`);
        this.next();
      },
      getLocation(c, m) {
        if (o) return l.getLocationRange(c, m, i);
        return null;
      },
      getLocationFromList(c) {
        if (o) {
          let m = this.getFirstListNode(c),
            v = this.getLastListNode(c);
          return l.getLocationRange(
            m !== null ? m.loc.start.offset - l.startOffset : this.tokenStart,
            v !== null ? v.loc.end.offset - l.startOffset : this.tokenStart,
            i
          );
        }
        return null;
      },
      error(c, m) {
        let v =
        typeof m !== "undefined" && m < t.length ?
        l.getLocation(m) :
        this.eof ?
        l.getLocation(Z$(t, t.length - 1)) :
        l.getLocation(this.tokenStart);
        throw new ye(
          c || "Unexpected input",
          t,
          v.offset,
          v.line,
          v.column,
          l.startLine,
          l.startColumn
        );
      }
    });
  return Object.assign(
    function (c, m) {
      t = c,
      m = m || {},
      u.setSource(t, bt),
      l.setSource(t, m.offset, m.line, m.column),
      i = m.filename || "<unknown>",
      o = Boolean(m.positions),
      n = typeof m.onParseError === "function" ? m.onParseError : o0,
      e = !1,
      u.parseAtrulePrelude =
      "parseAtrulePrelude" in m ? Boolean(m.parseAtrulePrelude) : !0,
      u.parseRulePrelude =
      "parseRulePrelude" in m ? Boolean(m.parseRulePrelude) : !0,
      u.parseValue = "parseValue" in m ? Boolean(m.parseValue) : !0,
      u.parseCustomProperty =
      "parseCustomProperty" in m ? Boolean(m.parseCustomProperty) : !1;
      let { context: v = "default", onComment: h } = m;
      if (v in u.context === !1) throw new Error("Unknown context `" + v + "`");
      if (typeof h === "function")
      u.forEachToken((f, D, O) => {
        if (f === A) {
          let _ = u.getLocation(D, O),
            J = rt(t, O - 2, O, "*/") ?
            t.slice(D + 2, O - 2) :
            t.slice(D + 2, O);
          h(J, _);
        }
      });
      let b = u.context[v].call(u, m);
      if (!u.eof) u.error();
      return b;
    },
    { SyntaxError: ye, config: u.config }
  );
}
var kn = $0(),
  ur = Mi(),
  Ci = p0().ArraySet,
  ia = D0().MappingList;
function Lr(r) {
  if (!r) r = {};
  this._file = ur.getArg(r, "file", null),
  this._sourceRoot = ur.getArg(r, "sourceRoot", null),
  this._skipValidation = ur.getArg(r, "skipValidation", !1),
  this._ignoreInvalidMapping = ur.getArg(r, "ignoreInvalidMapping", !1),
  this._sources = new Ci(),
  this._names = new Ci(),
  this._mappings = new ia(),
  this._sourcesContents = null;
}
Lr.prototype._version = 3;
Lr.fromSourceMap = function r(t, i) {
  var o = t.sourceRoot,
    n = new Lr(Object.assign(i || {}, { file: t.file, sourceRoot: o }));
  return (
    t.eachMapping(function (e) {
      var l = {
        generated: { line: e.generatedLine, column: e.generatedColumn }
      };
      if (e.source != null) {
        if (l.source = e.source, o != null)
        l.source = ur.relative(o, l.source);
        if (
        l.original = { line: e.originalLine, column: e.originalColumn },
        e.name != null)

        l.name = e.name;
      }
      n.addMapping(l);
    }),
    t.sources.forEach(function (e) {
      var l = e;
      if (o !== null) l = ur.relative(o, e);
      if (!n._sources.has(l)) n._sources.add(l);
      var u = t.sourceContentFor(e);
      if (u != null) n.setSourceContent(e, u);
    }),
    n);

};
Lr.prototype.addMapping = function r(t) {
  var i = ur.getArg(t, "generated"),
    o = ur.getArg(t, "original", null),
    n = ur.getArg(t, "source", null),
    e = ur.getArg(t, "name", null);
  if (!this._skipValidation) {
    if (this._validateMapping(i, o, n, e) === !1) return;
  }
  if (n != null) {
    if (n = String(n), !this._sources.has(n)) this._sources.add(n);
  }
  if (e != null) {
    if (e = String(e), !this._names.has(e)) this._names.add(e);
  }
  this._mappings.add({
    generatedLine: i.line,
    generatedColumn: i.column,
    originalLine: o != null && o.line,
    originalColumn: o != null && o.column,
    source: n,
    name: e
  });
};
Lr.prototype.setSourceContent = function r(t, i) {
  var o = t;
  if (this._sourceRoot != null) o = ur.relative(this._sourceRoot, o);
  if (i != null) {
    if (!this._sourcesContents) this._sourcesContents = Object.create(null);
    this._sourcesContents[ur.toSetString(o)] = i;
  } else if (this._sourcesContents) {
    if (
    delete this._sourcesContents[ur.toSetString(o)],
    Object.keys(this._sourcesContents).length === 0)

    this._sourcesContents = null;
  }
};
Lr.prototype.applySourceMap = function r(t, i, o) {
  var n = i;
  if (i == null) {
    if (t.file == null)
    throw new Error(
      `SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map's "file" property. Both were omitted.`
    );
    n = t.file;
  }
  var e = this._sourceRoot;
  if (e != null) n = ur.relative(e, n);
  var l = new Ci(),
    u = new Ci();
  this._mappings.unsortedForEach(function (g) {
    if (g.source === n && g.originalLine != null) {
      var c = t.originalPositionFor({
        line: g.originalLine,
        column: g.originalColumn
      });
      if (c.source != null) {
        if (g.source = c.source, o != null) g.source = ur.join(o, g.source);
        if (e != null) g.source = ur.relative(e, g.source);
        if (
        g.originalLine = c.line,
        g.originalColumn = c.column,
        c.name != null)

        g.name = c.name;
      }
    }
    var m = g.source;
    if (m != null && !l.has(m)) l.add(m);
    var v = g.name;
    if (v != null && !u.has(v)) u.add(v);
  }, this),
  this._sources = l,
  this._names = u,
  t.sources.forEach(function (g) {
    var c = t.sourceContentFor(g);
    if (c != null) {
      if (o != null) g = ur.join(o, g);
      if (e != null) g = ur.relative(e, g);
      this.setSourceContent(g, c);
    }
  }, this);
};
Lr.prototype._validateMapping = function r(t, i, o, n) {
  if (i && typeof i.line !== "number" && typeof i.column !== "number") {
    var e =
    "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.";
    if (this._ignoreInvalidMapping) {
      if (typeof console !== "undefined" && console.warn) console.warn(e);
      return !1;
    } else throw new Error(e);
  }
  if (
  t &&
  "line" in t &&
  "column" in t &&
  t.line > 0 &&
  t.column >= 0 &&
  !i &&
  !o &&
  !n)

  return;else
  if (
  t &&
  "line" in t &&
  "column" in t &&
  i &&
  "line" in i &&
  "column" in i &&
  t.line > 0 &&
  t.column >= 0 &&
  i.line > 0 &&
  i.column >= 0 &&
  o)

  return;else
  {
    var e =
    "Invalid mapping: " +
    JSON.stringify({ generated: t, source: o, original: i, name: n });
    if (this._ignoreInvalidMapping) {
      if (typeof console !== "undefined" && console.warn) console.warn(e);
      return !1;
    } else throw new Error(e);
  }
};
Lr.prototype._serializeMappings = function r() {
  var t = 0,
    i = 1,
    o = 0,
    n = 0,
    e = 0,
    l = 0,
    u = "",
    g,
    c,
    m,
    v,
    h = this._mappings.toArray();
  for (var b = 0, f = h.length; b < f; b++) {
    if (c = h[b], g = "", c.generatedLine !== i) {
      t = 0;
      while (c.generatedLine !== i) g += ";", i++;
    } else if (b > 0) {
      if (!ur.compareByGeneratedPositionsInflated(c, h[b - 1])) continue;
      g += ",";
    }
    if (
    g += kn.encode(c.generatedColumn - t),
    t = c.generatedColumn,
    c.source != null)
    {
      if (
      v = this._sources.indexOf(c.source),
      g += kn.encode(v - l),
      l = v,
      g += kn.encode(c.originalLine - 1 - n),
      n = c.originalLine - 1,
      g += kn.encode(c.originalColumn - o),
      o = c.originalColumn,
      c.name != null)

      m = this._names.indexOf(c.name), g += kn.encode(m - e), e = m;
    }
    u += g;
  }
  return u;
};
Lr.prototype._generateSourcesContent = function r(t, i) {
  return t.map(function (o) {
    if (!this._sourcesContents) return null;
    if (i != null) o = ur.relative(i, o);
    var n = ur.toSetString(o);
    return Object.prototype.hasOwnProperty.call(this._sourcesContents, n) ?
    this._sourcesContents[n] :
    null;
  }, this);
};
Lr.prototype.toJSON = function r() {
  var t = {
    version: this._version,
    sources: this._sources.toArray(),
    names: this._names.toArray(),
    mappings: this._serializeMappings()
  };
  if (this._file != null) t.file = this._file;
  if (this._sourceRoot != null) t.sourceRoot = this._sourceRoot;
  if (this._sourcesContents)
  t.sourcesContent = this._generateSourcesContent(t.sources, t.sourceRoot);
  return t;
};
Lr.prototype.toString = function r() {
  return JSON.stringify(this.toJSON());
};
var Te = Lr;
var j0 = new Set(["Atrule", "Selector", "Declaration"]);
function O0(r) {
  let t = new Te(),
    i = { line: 1, column: 0 },
    o = { line: 0, column: 0 },
    n = { line: 1, column: 0 },
    e = { generated: n },
    l = 1,
    u = 0,
    g = !1,
    c = r.node;
  r.node = function (h) {
    if (h.loc && h.loc.start && j0.has(h.type)) {
      let b = h.loc.start.line,
        f = h.loc.start.column - 1;
      if (o.line !== b || o.column !== f) {
        if (o.line = b, o.column = f, i.line = l, i.column = u, g) {
          if (g = !1, i.line !== n.line || i.column !== n.column)
          t.addMapping(e);
        }
        g = !0,
        t.addMapping({ source: h.loc.source, original: o, generated: i });
      }
    }
    if (c.call(this, h), g && j0.has(h.type)) n.line = l, n.column = u;
  };
  let m = r.emit;
  r.emit = function (h, b, f) {
    for (let D = 0; D < h.length; D++)
    if (h.charCodeAt(D) === 10) l++, u = 0;else
    u++;
    m(h, b, f);
  };
  let v = r.result;
  return (
    r.result = function () {
      if (g) t.addMapping(e);
      return { css: v(), map: t };
    },
    r);

}
var Ti = {};
I(Ti, { spec: () => ca, safe: () => se });
var oa = 43,
  ea = 45,
  de = (r, t) => {
    if (r === P) r = t;
    if (typeof r === "string") {
      let i = r.charCodeAt(0);
      return i > 127 ? 32768 : i << 8;
    }
    return r;
  },
  I0 = [
  [w, w],
  [w, k],
  [w, er],
  [w, fr],
  [w, "-"],
  [w, U],
  [w, y],
  [w, q],
  [w, hr],
  [w, K],
  [R, w],
  [R, k],
  [R, er],
  [R, fr],
  [R, "-"],
  [R, U],
  [R, y],
  [R, q],
  [R, hr],
  [S, w],
  [S, k],
  [S, er],
  [S, fr],
  [S, "-"],
  [S, U],
  [S, y],
  [S, q],
  [S, hr],
  [q, w],
  [q, k],
  [q, er],
  [q, fr],
  [q, "-"],
  [q, U],
  [q, y],
  [q, q],
  [q, hr],
  ["#", w],
  ["#", k],
  ["#", er],
  ["#", fr],
  ["#", "-"],
  ["#", U],
  ["#", y],
  ["#", q],
  ["#", hr],
  ["-", w],
  ["-", k],
  ["-", er],
  ["-", fr],
  ["-", "-"],
  ["-", U],
  ["-", y],
  ["-", q],
  ["-", hr],
  [U, w],
  [U, k],
  [U, er],
  [U, fr],
  [U, U],
  [U, y],
  [U, q],
  [U, "%"],
  [U, hr],
  ["@", w],
  ["@", k],
  ["@", er],
  ["@", fr],
  ["@", "-"],
  ["@", hr],
  [".", U],
  [".", y],
  [".", q],
  ["+", U],
  ["+", y],
  ["+", q],
  ["/", "*"]],

  la = I0.concat([
  [w, S],
  [q, S],
  [S, S],
  [R, K],
  [R, gr],
  [R, d],
  [y, y],
  [y, q],
  [y, k],
  [y, "-"],
  [j, w],
  [j, k],
  [j, y],
  [j, q],
  [j, S],
  [j, "-"]]
  );
function k0(r) {
  let t = new Set(r.map(([i, o]) => de(i) << 16 | de(o)));
  return function (i, o, n) {
    let e = de(o, n),
      l = n.charCodeAt(0);
    if (
    l === ea && o !== w && o !== k && o !== hr || l === oa ?
    t.has(i << 16 | l << 8) :
    t.has(i << 16 | e))

    this.emit(" ", Y, !0);
    return e;
  };
}
var ca = k0(I0),
  se = k0(la);
var ua = 92;
function ga(r, t) {
  if (typeof t === "function") {
    let i = null;
    r.children.forEach((o) => {
      if (i !== null) t.call(this, i);
      this.node(o), i = o;
    });
    return;
  }
  r.children.forEach(this.node, this);
}
function ma(r) {
  bt(r, (t, i, o) => {
    this.token(t, r.slice(i, o));
  });
}
function U0(r) {
  let t = new Map();
  for (let [i, o] of Object.entries(r.node))
  if (typeof (o.generate || o) === "function") t.set(i, o.generate || o);
  return function (i, o) {
    let n = "",
      e = 0,
      l = {
        node(g) {
          if (t.has(g.type)) t.get(g.type).call(u, g);else
          throw new Error("Unknown node type: " + g.type);
        },
        tokenBefore: se,
        token(g, c) {
          if (
          e = this.tokenBefore(e, g, c),
          this.emit(c, g, !1),
          g === P && c.charCodeAt(0) === ua)

          this.emit(
            `
`,
            Y,
            !0
          );
        },
        emit(g) {
          n += g;
        },
        result() {
          return n;
        }
      };
    if (o) {
      if (typeof o.decorator === "function") l = o.decorator(l);
      if (o.sourceMap) l = O0(l);
      if (o.mode in Ti) l.tokenBefore = Ti[o.mode];
    }
    let u = {
      node: (g) => l.node(g),
      children: ga,
      token: (g, c) => l.token(g, c),
      tokenize: ma
    };
    return l.node(i), l.result();
  };
}
function J0(r) {
  return {
    fromPlainObject(t) {
      return (
        r(t, {
          enter(i) {
            if (i.children && i.children instanceof or === !1)
            i.children = new or().fromArray(i.children);
          }
        }),
        t);

    },
    toPlainObject(t) {
      return (
        r(t, {
          leave(i) {
            if (i.children && i.children instanceof or)
            i.children = i.children.toArray();
          }
        }),
        t);

    }
  };
}
var { hasOwnProperty: rl } = Object.prototype,
  Un = function () {};
function P0(r) {
  return typeof r === "function" ? r : Un;
}
function X0(r, t) {
  return function (i, o, n) {
    if (i.type === t) r.call(this, i, o, n);
  };
}
function ba(r, t) {
  let i = t.structure,
    o = [];
  for (let n in i) {
    if (rl.call(i, n) === !1) continue;
    let e = i[n],
      l = { name: n, type: !1, nullable: !1 };
    if (!Array.isArray(e)) e = [e];
    for (let u of e)
    if (u === null) l.nullable = !0;else
    if (typeof u === "string") l.type = "node";else
    if (Array.isArray(u)) l.type = "list";
    if (l.type) o.push(l);
  }
  if (o.length) return { context: t.walkContext, fields: o };
  return null;
}
function va(r) {
  let t = {};
  for (let i in r.node)
  if (rl.call(r.node, i)) {
    let o = r.node[i];
    if (!o.structure)
    throw new Error(
      "Missed `structure` field in `" + i + "` node type definition"
    );
    t[i] = ba(i, o);
  }
  return t;
}
function q0(r, t) {
  let i = r.fields.slice(),
    o = r.context,
    n = typeof o === "string";
  if (t) i.reverse();
  return function (e, l, u, g) {
    let c;
    if (n) c = l[o], l[o] = e;
    for (let m of i) {
      let v = e[m.name];
      if (!m.nullable || v) {
        if (m.type === "list") {
          if (t ? v.reduceRight(g, !1) : v.reduce(g, !1)) return !0;
        } else if (u(v)) return !0;
      }
    }
    if (n) l[o] = c;
  };
}
function W0({
  StyleSheet: r,
  Atrule: t,
  Rule: i,
  Block: o,
  DeclarationList: n
}) {
  return {
    Atrule: { StyleSheet: r, Atrule: t, Rule: i, Block: o },
    Rule: { StyleSheet: r, Atrule: t, Rule: i, Block: o },
    Declaration: {
      StyleSheet: r,
      Atrule: t,
      Rule: i,
      Block: o,
      DeclarationList: n
    }
  };
}
function K0(r) {
  let t = va(r),
    i = {},
    o = {},
    n = Symbol("break-walk"),
    e = Symbol("skip-node");
  for (let c in t)
  if (rl.call(t, c) && t[c] !== null)
  i[c] = q0(t[c], !1), o[c] = q0(t[c], !0);
  let l = W0(i),
    u = W0(o),
    g = function (c, m) {
      function v(_, J, V) {
        let X = h.call(O, _, J, V);
        if (X === n) return !0;
        if (X === e) return !1;
        if (f.hasOwnProperty(_.type)) {
          if (f[_.type](_, O, v, D)) return !0;
        }
        if (b.call(O, _, J, V) === n) return !0;
        return !1;
      }
      let h = Un,
        b = Un,
        f = i,
        D = (_, J, V, X) => _ || v(J, V, X),
        O = {
          break: n,
          skip: e,
          root: c,
          stylesheet: null,
          atrule: null,
          atrulePrelude: null,
          rule: null,
          selector: null,
          block: null,
          declaration: null,
          function: null
        };
      if (typeof m === "function") h = m;else
      if (m) {
        if (h = P0(m.enter), b = P0(m.leave), m.reverse) f = o;
        if (m.visit) {
          if (l.hasOwnProperty(m.visit))
          f = m.reverse ? u[m.visit] : l[m.visit];else
          if (!t.hasOwnProperty(m.visit))
          throw new Error(
            "Bad value `" +
            m.visit +
            "` for `visit` option (should be: " +
            Object.keys(t).sort().join(", ") +
            ")"
          );
          h = X0(h, m.visit), b = X0(b, m.visit);
        }
      }
      if (h === Un && b === Un)
      throw new Error(
        "Neither `enter` nor `leave` walker handler is set or both aren't a function"
      );
      v(c);
    };
  return (
    g.break = n,
    g.skip = e,
    g.find = function (c, m) {
      let v = null;
      return (
        g(c, function (h, b, f) {
          if (m.call(this, h, b, f)) return v = h, n;
        }),
        v);

    },
    g.findLast = function (c, m) {
      let v = null;
      return (
        g(c, {
          reverse: !0,
          enter(h, b, f) {
            if (m.call(this, h, b, f)) return v = h, n;
          }
        }),
        v);

    },
    g.findAll = function (c, m) {
      let v = [];
      return (
        g(c, function (h, b, f) {
          if (m.call(this, h, b, f)) v.push(h);
        }),
        v);

    },
    g);

}
function ha(r) {
  return r;
}
function $a(r) {
  let { min: t, max: i, comma: o } = r;
  if (t === 0 && i === 0) return o ? "#?" : "*";
  if (t === 0 && i === 1) return "?";
  if (t === 1 && i === 0) return o ? "#" : "+";
  if (t === 1 && i === 1) return "";
  return (
    (o ? "#" : "") + (
    t === i ? "{" + t + "}" : "{" + t + "," + (i !== 0 ? i : "") + "}"));

}
function xa(r) {
  switch (r.type) {
    case "Range":
      return (
        " [" + (
        r.min === null ? "-∞" : r.min) +
        "," + (
        r.max === null ? "∞" : r.max) +
        "]");

    default:
      throw new Error("Unknown node type `" + r.type + "`");
  }
}
function fa(r, t, i, o) {
  let n = r.combinator === " " || o ? r.combinator : " " + r.combinator + " ",
    e = r.terms.map((l) => di(l, t, i, o)).join(n);
  if (r.explicit || i)
  return (o || e[0] === "," ? "[" : "[ ") + e + (o ? "]" : " ]");
  return e;
}
function di(r, t, i, o) {
  let n;
  switch (r.type) {
    case "Group":
      n = fa(r, t, i, o) + (r.disallowEmpty ? "!" : "");
      break;
    case "Multiplier":
      return di(r.term, t, i, o) + t($a(r), r);
    case "Boolean":
      n = "<boolean-expr[" + di(r.term, t, i, o) + "]>";
      break;
    case "Type":
      n = "<" + r.name + (r.opts ? t(xa(r.opts), r.opts) : "") + ">";
      break;
    case "Property":
      n = "<'" + r.name + "'>";
      break;
    case "Keyword":
      n = r.name;
      break;
    case "AtKeyword":
      n = "@" + r.name;
      break;
    case "Function":
      n = r.name + "(";
      break;
    case "String":
    case "Token":
      n = r.value;
      break;
    case "Comma":
      n = ",";
      break;
    default:
      throw new Error("Unknown node type `" + r.type + "`");
  }
  return t(n, r);
}
function Ht(r, t) {
  let i = ha,
    o = !1,
    n = !1;
  if (typeof t === "function") i = t;else
  if (t) {
    if (
    o = Boolean(t.forceBraces),
    n = Boolean(t.compact),
    typeof t.decorate === "function")

    i = t.decorate;
  }
  return di(r, i, o, n);
}
var L0 = { offset: 0, line: 1, column: 1 };
function wa(r, t) {
  let { tokens: i, longestMatch: o } = r,
    n = o < i.length ? i[o].node || null : null,
    e = n !== t ? n : null,
    l = 0,
    u = 0,
    g = 0,
    c = "",
    m,
    v;
  for (let h = 0; h < i.length; h++) {
    let b = i[h].value;
    if (h === o) u = b.length, l = c.length;
    if (e !== null && i[h].node === e)
    if (h <= o) g++;else
    g = 0;
    c += b;
  }
  if (o === i.length || g > 1)
  m = si(e || t, "end") || Jn(L0, c), v = Jn(m);else

  m = si(e, "start") || Jn(si(t, "start") || L0, c.slice(0, l)),
  v = si(e, "end") || Jn(m, c.substr(l, u));
  return { css: c, mismatchOffset: l, mismatchLength: u, start: m, end: v };
}
function si(r, t) {
  let i = r && r.loc && r.loc[t];
  if (i) return "line" in i ? Jn(i) : i;
  return null;
}
function Jn({ offset: r, line: t, column: i }, o) {
  let n = { offset: r, line: t, column: i };
  if (o) {
    let e = o.split(/\n|\r\n?|\f/);
    n.offset += o.length,
    n.line += e.length - 1,
    n.column = e.length === 1 ? n.column + o.length : e.pop().length + 1;
  }
  return n;
}
var Rt = function (r, t) {
    let i = It("SyntaxReferenceError", r + (t ? " `" + t + "`" : ""));
    return i.reference = t, i;
  },
  V0 = function (r, t, i, o) {
    let n = It("SyntaxMatchError", r),
      {
        css: e,
        mismatchOffset: l,
        mismatchLength: u,
        start: g,
        end: c
      } = wa(o, i);
    return (
      n.rawMessage = r,
      n.syntax = t ? Ht(t) : "<generic>",
      n.css = e,
      n.mismatchOffset = l,
      n.mismatchLength = u,
      n.message =
      r +
      `
  syntax: ` +
      n.syntax +
      `
   value: ` + (
      e || "<empty string>") +
      `
  --------` +
      new Array(n.mismatchOffset + 1).join("-") +
      "^",
      Object.assign(n, g),
      n.loc = {
        source: i && i.loc && i.loc.source || "<unknown>",
        start: g,
        end: c
      },
      n);

  };
var ro = new Map(),
  Mt = new Map();
var to = za,
  tl = aa;
function no(r, t) {
  return (
    t = t || 0,
    r.length - t >= 2 && r.charCodeAt(t) === 45 && r.charCodeAt(t + 1) === 45);

}
function Y0(r, t) {
  if (t = t || 0, r.length - t >= 3) {
    if (r.charCodeAt(t) === 45 && r.charCodeAt(t + 1) !== 45) {
      let i = r.indexOf("-", t + 2);
      if (i !== -1) return r.substring(t, i + 1);
    }
  }
  return "";
}
function za(r) {
  if (ro.has(r)) return ro.get(r);
  let t = r.toLowerCase(),
    i = ro.get(t);
  if (i === void 0) {
    let o = no(t, 0),
      n = !o ? Y0(t, 0) : "";
    i = Object.freeze({
      basename: t.substr(n.length),
      name: t,
      prefix: n,
      vendor: n,
      custom: o
    });
  }
  return ro.set(r, i), i;
}
function aa(r) {
  if (Mt.has(r)) return Mt.get(r);
  let t = r,
    i = r[0];
  if (i === "/") i = r[1] === "/" ? "//" : "/";else
  if (
  i !== "_" &&
  i !== "*" &&
  i !== "$" &&
  i !== "#" &&
  i !== "+" &&
  i !== "&")

  i = "";
  let o = no(t, i.length);
  if (!o) {
    if (t = t.toLowerCase(), Mt.has(t)) {
      let u = Mt.get(t);
      return Mt.set(r, u), u;
    }
  }
  let n = !o ? Y0(t, i.length) : "",
    e = t.substr(0, i.length + n.length),
    l = Object.freeze({
      basename: t.substr(e.length),
      name: t.substr(i.length),
      hack: i,
      vendor: n,
      prefix: e,
      custom: o
    });
  return Mt.set(r, l), l;
}
var Zt = ["initial", "inherit", "unset", "revert", "revert-layer"];
var Xn = 43,
  Rr = 45,
  nl = 110,
  Ct = !0,
  _a = !1;
function ol(r, t) {
  return r !== null && r.type === P && r.value.charCodeAt(0) === t;
}
function Pn(r, t, i) {
  while (r !== null && (r.type === Y || r.type === A)) r = i(++t);
  return t;
}
function vt(r, t, i, o) {
  if (!r) return 0;
  let n = r.value.charCodeAt(t);
  if (n === Xn || n === Rr) {
    if (i) return 0;
    t++;
  }
  for (; t < r.value.length; t++) if (!cr(r.value.charCodeAt(t))) return 0;
  return o + 1;
}
function il(r, t, i) {
  let o = !1,
    n = Pn(r, t, i);
  if (r = i(n), r === null) return t;
  if (r.type !== U)
  if (ol(r, Xn) || ol(r, Rr)) {
    if (
    o = !0,
    n = Pn(i(++n), n, i),
    r = i(n),
    r === null || r.type !== U)

    return 0;
  } else return t;
  if (!o) {
    let e = r.value.charCodeAt(0);
    if (e !== Xn && e !== Rr) return 0;
  }
  return vt(r, o ? 0 : 1, o, n);
}
function el(r, t) {
  let i = 0;
  if (!r) return 0;
  if (r.type === U) return vt(r, 0, _a, i);else
  if (r.type === w && r.value.charCodeAt(0) === Rr) {
    if (!sr(r.value, 1, nl)) return 0;
    switch (r.value.length) {
      case 2:
        return il(t(++i), i, t);
      case 3:
        if (r.value.charCodeAt(2) !== Rr) return 0;
        return i = Pn(t(++i), i, t), r = t(i), vt(r, 0, Ct, i);
      default:
        if (r.value.charCodeAt(2) !== Rr) return 0;
        return vt(r, 3, Ct, i);
    }
  } else if (r.type === w || ol(r, Xn) && t(i + 1).type === w) {
    if (r.type !== w) r = t(++i);
    if (r === null || !sr(r.value, 0, nl)) return 0;
    switch (r.value.length) {
      case 1:
        return il(t(++i), i, t);
      case 2:
        if (r.value.charCodeAt(1) !== Rr) return 0;
        return i = Pn(t(++i), i, t), r = t(i), vt(r, 0, Ct, i);
      default:
        if (r.value.charCodeAt(1) !== Rr) return 0;
        return vt(r, 2, Ct, i);
    }
  } else if (r.type === q) {
    let o = r.value.charCodeAt(0),
      n = o === Xn || o === Rr ? 1 : 0,
      e = n;
    for (; e < r.value.length; e++) if (!cr(r.value.charCodeAt(e))) break;
    if (e === n) return 0;
    if (!sr(r.value, e, nl)) return 0;
    if (e + 1 === r.value.length) return il(t(++i), i, t);else
    {
      if (r.value.charCodeAt(e + 1) !== Rr) return 0;
      if (e + 2 === r.value.length)
      return i = Pn(t(++i), i, t), r = t(i), vt(r, 0, Ct, i);else
      return vt(r, e + 2, Ct, i);
    }
  }
  return 0;
}
var Da = 43,
  E0 = 45,
  Q0 = 63,
  ja = 117;
function ll(r, t) {
  return r !== null && r.type === P && r.value.charCodeAt(0) === t;
}
function Oa(r, t) {
  return r.value.charCodeAt(0) === t;
}
function qn(r, t, i) {
  let o = 0;
  for (let n = t; n < r.value.length; n++) {
    let e = r.value.charCodeAt(n);
    if (e === E0 && i && o !== 0) return qn(r, t + o + 1, !1), 6;
    if (!Or(e)) return 0;
    if (++o > 6) return 0;
  }
  return o;
}
function io(r, t, i) {
  if (!r) return 0;
  while (ll(i(t), Q0)) {
    if (++r > 6) return 0;
    t++;
  }
  return t;
}
function cl(r, t) {
  let i = 0;
  if (r === null || r.type !== w || !sr(r.value, 0, ja)) return 0;
  if (r = t(++i), r === null) return 0;
  if (ll(r, Da)) {
    if (r = t(++i), r === null) return 0;
    if (r.type === w) return io(qn(r, 0, !0), ++i, t);
    if (ll(r, Q0)) return io(1, ++i, t);
    return 0;
  }
  if (r.type === U) {
    let o = qn(r, 1, !0);
    if (o === 0) return 0;
    if (r = t(++i), r === null) return i;
    if (r.type === q || r.type === U) {
      if (!Oa(r, E0) || !qn(r, 1, !1)) return 0;
      return i + 1;
    }
    return io(o, i, t);
  }
  if (r.type === q) return io(qn(r, 1, !0), ++i, t);
  return 0;
}
var Ia = ["calc(", "-moz-calc(", "-webkit-calc("],
  ul = new Map([
  [k, j],
  [K, j],
  [mr, wr],
  [Z, xr]]
  );
function Fr(r, t) {
  return t < r.length ? r.charCodeAt(t) : 0;
}
function F0(r, t) {
  return rt(r, 0, r.length, t);
}
function S0(r, t) {
  for (let i = 0; i < t.length; i++) if (F0(r, t[i])) return !0;
  return !1;
}
function G0(r, t) {
  if (t !== r.length - 2) return !1;
  return Fr(r, t) === 92 && cr(Fr(r, t + 1));
}
function oo(r, t, i) {
  if (r && r.type === "Range") {
    let o = Number(i !== void 0 && i !== t.length ? t.substr(0, i) : t);
    if (isNaN(o)) return !0;
    if (r.min !== null && o < r.min && typeof r.min !== "string") return !0;
    if (r.max !== null && o > r.max && typeof r.max !== "string") return !0;
  }
  return !1;
}
function ka(r, t) {
  let i = 0,
    o = [],
    n = 0;
  r: do {
    switch (r.type) {
      case xr:
      case j:
      case wr:
        if (r.type !== i) break r;
        if (i = o.pop(), o.length === 0) {
          n++;
          break r;
        }
        break;
      case k:
      case K:
      case mr:
      case Z:
        o.push(i), i = ul.get(r.type);
        break;
    }
    n++;
  } while (r = t(n));
  return n;
}
function Vr(r) {
  return function (t, i, o) {
    if (t === null) return 0;
    if (t.type === k && S0(t.value, Ia)) return ka(t, i);
    return r(t, i, o);
  };
}
function C(r) {
  return function (t) {
    if (t === null || t.type !== r) return 0;
    return 1;
  };
}
function Ua(r) {
  if (r === null || r.type !== w) return 0;
  let t = r.value.toLowerCase();
  if (S0(t, Zt)) return 0;
  if (F0(t, "default")) return 0;
  return 1;
}
function N0(r) {
  if (r === null || r.type !== w) return 0;
  if (Fr(r.value, 0) !== 45 || Fr(r.value, 1) !== 45) return 0;
  return 1;
}
function Ja(r) {
  if (!N0(r)) return 0;
  if (r.value === "--") return 0;
  return 1;
}
function Pa(r) {
  if (r === null || r.type !== S) return 0;
  let t = r.value.length;
  if (t !== 4 && t !== 5 && t !== 7 && t !== 9) return 0;
  for (let i = 1; i < t; i++) if (!Or(Fr(r.value, i))) return 0;
  return 1;
}
function Xa(r) {
  if (r === null || r.type !== S) return 0;
  if (!St(Fr(r.value, 1), Fr(r.value, 2), Fr(r.value, 3))) return 0;
  return 1;
}
function qa(r, t) {
  if (!r) return 0;
  let i = 0,
    o = [],
    n = 0;
  r: do {
    switch (r.type) {
      case Ft:
      case fr:
        break r;
      case xr:
      case j:
      case wr:
        if (r.type !== i) break r;
        i = o.pop();
        break;
      case nr:
        if (i === 0) break r;
        break;
      case P:
        if (i === 0 && r.value === "!") break r;
        break;
      case k:
      case K:
      case mr:
      case Z:
        o.push(i), i = ul.get(r.type);
        break;
    }
    n++;
  } while (r = t(n));
  return n;
}
function Wa(r, t) {
  if (!r) return 0;
  let i = 0,
    o = [],
    n = 0;
  r: do {
    switch (r.type) {
      case Ft:
      case fr:
        break r;
      case xr:
      case j:
      case wr:
        if (r.type !== i) break r;
        i = o.pop();
        break;
      case k:
      case K:
      case mr:
      case Z:
        o.push(i), i = ul.get(r.type);
        break;
    }
    n++;
  } while (r = t(n));
  return n;
}
function it(r) {
  if (r) r = new Set(r);
  return function (t, i, o) {
    if (t === null || t.type !== q) return 0;
    let n = jt(t.value, 0);
    if (r !== null) {
      let e = t.value.indexOf("\\", n),
        l =
        e === -1 || !G0(t.value, e) ?
        t.value.substr(n) :
        t.value.substring(n, e);
      if (r.has(l.toLowerCase()) === !1) return 0;
    }
    if (oo(o, t.value, n)) return 0;
    return 1;
  };
}
function Ka(r, t, i) {
  if (r === null || r.type !== y) return 0;
  if (oo(i, r.value, r.value.length - 1)) return 0;
  return 1;
}
function B0(r) {
  if (typeof r !== "function")
  r = function () {
    return 0;
  };
  return function (t, i, o) {
    if (t !== null && t.type === U) {
      if (Number(t.value) === 0) return 1;
    }
    return r(t, i, o);
  };
}
function La(r, t, i) {
  if (r === null) return 0;
  let o = jt(r.value, 0);
  if (o !== r.value.length && !G0(r.value, o)) return 0;
  if (oo(i, r.value, o)) return 0;
  return 1;
}
function Va(r, t, i) {
  if (r === null || r.type !== U) return 0;
  let o = Fr(r.value, 0) === 43 || Fr(r.value, 0) === 45 ? 1 : 0;
  for (; o < r.value.length; o++) if (!cr(Fr(r.value, o))) return 0;
  if (oo(i, r.value, o)) return 0;
  return 1;
}
var Ya = {
    "ident-token": C(w),
    "function-token": C(k),
    "at-keyword-token": C(R),
    "hash-token": C(S),
    "string-token": C(gr),
    "bad-string-token": C(Ft),
    "url-token": C(er),
    "bad-url-token": C(fr),
    "delim-token": C(P),
    "number-token": C(U),
    "percentage-token": C(y),
    "dimension-token": C(q),
    "whitespace-token": C(Y),
    "CDO-token": C(dr),
    "CDC-token": C(hr),
    "colon-token": C(d),
    "semicolon-token": C(nr),
    "comma-token": C(ir),
    "[-token": C(mr),
    "]-token": C(wr),
    "(-token": C(K),
    ")-token": C(j),
    "{-token": C(Z),
    "}-token": C(xr)
  },
  Ea = {
    string: C(gr),
    ident: C(w),
    percentage: Vr(Ka),
    zero: B0(),
    number: Vr(La),
    integer: Vr(Va),
    "custom-ident": Ua,
    "dashed-ident": N0,
    "custom-property-name": Ja,
    "hex-color": Pa,
    "id-selector": Xa,
    "an-plus-b": el,
    urange: cl,
    "declaration-value": qa,
    "any-value": Wa
  };
function Qa(r) {
  let {
    angle: t,
    decibel: i,
    frequency: o,
    flex: n,
    length: e,
    resolution: l,
    semitones: u,
    time: g
  } = r || {};
  return {
    dimension: Vr(it(null)),
    angle: Vr(it(t)),
    decibel: Vr(it(i)),
    frequency: Vr(it(o)),
    flex: Vr(it(n)),
    length: Vr(B0(it(e))),
    resolution: Vr(it(l)),
    semitones: Vr(it(u)),
    time: Vr(it(g))
  };
}
function y0(r) {
  return { ...Ya, ...Ea, ...Qa(r) };
}
var eo = {};
I(eo, {
  time: () => Ga,
  semitones: () => Ha,
  resolution: () => Ba,
  length: () => Fa,
  frequency: () => Na,
  flex: () => ya,
  decibel: () => Aa,
  angle: () => Sa
});
var Fa = [
  "cm",
  "mm",
  "q",
  "in",
  "pt",
  "pc",
  "px",
  "em",
  "rem",
  "ex",
  "rex",
  "cap",
  "rcap",
  "ch",
  "rch",
  "ic",
  "ric",
  "lh",
  "rlh",
  "vw",
  "svw",
  "lvw",
  "dvw",
  "vh",
  "svh",
  "lvh",
  "dvh",
  "vi",
  "svi",
  "lvi",
  "dvi",
  "vb",
  "svb",
  "lvb",
  "dvb",
  "vmin",
  "svmin",
  "lvmin",
  "dvmin",
  "vmax",
  "svmax",
  "lvmax",
  "dvmax",
  "cqw",
  "cqh",
  "cqi",
  "cqb",
  "cqmin",
  "cqmax"],

  Sa = ["deg", "grad", "rad", "turn"],
  Ga = ["s", "ms"],
  Na = ["hz", "khz"],
  Ba = ["dpi", "dpcm", "dppx", "x"],
  ya = ["fr"],
  Aa = ["db"],
  Ha = ["st"];
function gl(r, t, i) {
  return Object.assign(It("SyntaxError", r), {
    input: t,
    offset: i,
    rawMessage: r,
    message:
    r +
    `
  ` +
    t +
    `
--` +
    new Array((i || t.length) + 1).join("-") +
    "^"
  });
}
var Ra = 9,
  Ma = 10,
  Za = 12,
  Ca = 13,
  Ta = 32,
  A0 = new Uint8Array(128).map((r, t) =>
  /[a-zA-Z0-9\-]/.test(String.fromCharCode(t)) ? 1 : 0
  );
class ml {
  constructor(r) {
    this.str = r, this.pos = 0;
  }
  charCodeAt(r) {
    return r < this.str.length ? this.str.charCodeAt(r) : 0;
  }
  charCode() {
    return this.charCodeAt(this.pos);
  }
  isNameCharCode(r = this.charCode()) {
    return r < 128 && A0[r] === 1;
  }
  nextCharCode() {
    return this.charCodeAt(this.pos + 1);
  }
  nextNonWsCode(r) {
    return this.charCodeAt(this.findWsEnd(r));
  }
  skipWs() {
    this.pos = this.findWsEnd(this.pos);
  }
  findWsEnd(r) {
    for (; r < this.str.length; r++) {
      let t = this.str.charCodeAt(r);
      if (t !== Ca && t !== Ma && t !== Za && t !== Ta && t !== Ra) break;
    }
    return r;
  }
  substringToPos(r) {
    return this.str.substring(this.pos, this.pos = r);
  }
  eat(r) {
    if (this.charCode() !== r)
    this.error("Expect `" + String.fromCharCode(r) + "`");
    this.pos++;
  }
  peek() {
    return this.pos < this.str.length ? this.str.charAt(this.pos++) : "";
  }
  error(r) {
    throw new gl(r, this.str, this.pos);
  }
  scanSpaces() {
    return this.substringToPos(this.findWsEnd(this.pos));
  }
  scanWord() {
    let r = this.pos;
    for (; r < this.str.length; r++) {
      let t = this.str.charCodeAt(r);
      if (t >= 128 || A0[t] === 0) break;
    }
    if (this.pos === r) this.error("Expect a keyword");
    return this.substringToPos(r);
  }
  scanNumber() {
    let r = this.pos;
    for (; r < this.str.length; r++) {
      let t = this.str.charCodeAt(r);
      if (t < 48 || t > 57) break;
    }
    if (this.pos === r) this.error("Expect a number");
    return this.substringToPos(r);
  }
  scanString() {
    let r = this.str.indexOf("'", this.pos + 1);
    if (r === -1)
    this.pos = this.str.length, this.error("Expect an apostrophe");
    return this.substringToPos(r + 1);
  }
}
var da = 9,
  sa = 10,
  r1 = 12,
  t1 = 13,
  n1 = 32,
  s0 = 33,
  $l = 35,
  H0 = 38,
  lo = 39,
  rx = 40,
  i1 = 41,
  tx = 42,
  xl = 43,
  fl = 44,
  R0 = 45,
  wl = 60,
  vl = 62,
  hl = 63,
  o1 = 64,
  Wn = 91,
  Kn = 93,
  co = 123,
  M0 = 124,
  Z0 = 125,
  C0 = 8734,
  T0 = { " ": 1, "&&": 2, "||": 3, "|": 4 };
function d0(r) {
  let t = null,
    i = null;
  if (
  r.eat(co),
  r.skipWs(),
  t = r.scanNumber(r),
  r.skipWs(),
  r.charCode() === fl)
  {
    if (r.pos++, r.skipWs(), r.charCode() !== Z0)
    i = r.scanNumber(r), r.skipWs();
  } else i = t;
  return r.eat(Z0), { min: Number(t), max: i ? Number(i) : 0 };
}
function e1(r) {
  let t = null,
    i = !1;
  switch (r.charCode()) {
    case tx:
      r.pos++, t = { min: 0, max: 0 };
      break;
    case xl:
      r.pos++, t = { min: 1, max: 0 };
      break;
    case hl:
      r.pos++, t = { min: 0, max: 1 };
      break;
    case $l:
      if (r.pos++, i = !0, r.charCode() === co) t = d0(r);else
      if (r.charCode() === hl) r.pos++, t = { min: 0, max: 0 };else
      t = { min: 1, max: 0 };
      break;
    case co:
      t = d0(r);
      break;
    default:
      return null;
  }
  return { type: "Multiplier", comma: i, min: t.min, max: t.max, term: null };
}
function ht(r, t) {
  let i = e1(r);
  if (i !== null) {
    if (i.term = t, r.charCode() === $l && r.charCodeAt(r.pos - 1) === xl)
    return ht(r, i);
    return i;
  }
  return t;
}
function bl(r) {
  let t = r.peek();
  if (t === "") return null;
  return ht(r, { type: "Token", value: t });
}
function l1(r) {
  let t;
  return (
    r.eat(wl),
    r.eat(lo),
    t = r.scanWord(),
    r.eat(lo),
    r.eat(vl),
    ht(r, { type: "Property", name: t }));

}
function c1(r) {
  let t = null,
    i = null,
    o = 1;
  if (r.eat(Wn), r.charCode() === R0) r.peek(), o = -1;
  if (o == -1 && r.charCode() === C0) r.peek();else
  if (t = o * Number(r.scanNumber(r)), r.isNameCharCode())
  t += r.scanWord();
  if (r.skipWs(), r.eat(fl), r.skipWs(), r.charCode() === C0) r.peek();else
  {
    if (o = 1, r.charCode() === R0) r.peek(), o = -1;
    if (i = o * Number(r.scanNumber(r)), r.isNameCharCode())
    i += r.scanWord();
  }
  return r.eat(Kn), { type: "Range", min: t, max: i };
}
function u1(r) {
  let t,
    i = null;
  if (r.eat(wl), t = r.scanWord(), t === "boolean-expr") {
    r.eat(Wn);
    let o = zl(r, Kn);
    return (
      r.eat(Kn),
      r.eat(vl),
      ht(r, { type: "Boolean", term: o.terms.length === 1 ? o.terms[0] : o }));

  }
  if (r.charCode() === rx && r.nextCharCode() === i1)
  r.pos += 2, t += "()";
  if (r.charCodeAt(r.findWsEnd(r.pos)) === Wn) r.skipWs(), i = c1(r);
  return r.eat(vl), ht(r, { type: "Type", name: t, opts: i });
}
function g1(r) {
  let t = r.scanWord();
  if (r.charCode() === rx) return r.pos++, { type: "Function", name: t };
  return ht(r, { type: "Keyword", name: t });
}
function m1(r, t) {
  function i(n, e) {
    return {
      type: "Group",
      terms: n,
      combinator: e,
      disallowEmpty: !1,
      explicit: !1
    };
  }
  let o;
  t = Object.keys(t).sort((n, e) => T0[n] - T0[e]);
  while (t.length > 0) {
    o = t.shift();
    let n = 0,
      e = 0;
    for (; n < r.length; n++) {
      let l = r[n];
      if (l.type === "Combinator")
      if (l.value === o) {
        if (e === -1) e = n - 1;
        r.splice(n, 1), n--;
      } else {
        if (e !== -1 && n - e > 1)
        r.splice(e, n - e, i(r.slice(e, n), o)), n = e + 1;
        e = -1;
      }
    }
    if (e !== -1 && t.length) r.splice(e, n - e, i(r.slice(e, n), o));
  }
  return o;
}
function zl(r, t) {
  let i = Object.create(null),
    o = [],
    n,
    e = null,
    l = r.pos;
  while (r.charCode() !== t && (n = v1(r, t)))
  if (n.type !== "Spaces") {
    if (n.type === "Combinator") {
      if (e === null || e.type === "Combinator")
      r.pos = l, r.error("Unexpected combinator");
      i[n.value] = !0;
    } else if (e !== null && e.type !== "Combinator")
    i[" "] = !0, o.push({ type: "Combinator", value: " " });
    o.push(n), e = n, l = r.pos;
  }
  if (e !== null && e.type === "Combinator")
  r.pos -= l, r.error("Unexpected combinator");
  return {
    type: "Group",
    terms: o,
    combinator: m1(o, i) || " ",
    disallowEmpty: !1,
    explicit: !1
  };
}
function b1(r, t) {
  let i;
  if (
  r.eat(Wn),
  i = zl(r, t),
  r.eat(Kn),
  i.explicit = !0,
  r.charCode() === s0)

  r.pos++, i.disallowEmpty = !0;
  return i;
}
function v1(r, t) {
  let i = r.charCode();
  switch (i) {
    case Kn:
      break;
    case Wn:
      return ht(r, b1(r, t));
    case wl:
      return r.nextCharCode() === lo ? l1(r) : u1(r);
    case M0:
      return {
        type: "Combinator",
        value: r.substringToPos(r.pos + (r.nextCharCode() === M0 ? 2 : 1))
      };
    case H0:
      return r.pos++, r.eat(H0), { type: "Combinator", value: "&&" };
    case fl:
      return r.pos++, { type: "Comma" };
    case lo:
      return ht(r, { type: "String", value: r.scanString() });
    case n1:
    case da:
    case sa:
    case t1:
    case r1:
      return { type: "Spaces", value: r.scanSpaces() };
    case o1:
      if (i = r.nextCharCode(), r.isNameCharCode(i))
      return r.pos++, { type: "AtKeyword", name: r.scanWord() };
      return bl(r);
    case tx:
    case xl:
    case hl:
    case $l:
    case s0:
      break;
    case co:
      if (i = r.nextCharCode(), i < 48 || i > 57) return bl(r);
      break;
    default:
      if (r.isNameCharCode(i)) return g1(r);
      return bl(r);
  }
}
function Ln(r) {
  let t = new ml(r),
    i = zl(t);
  if (t.pos !== r.length) t.error("Unexpected input");
  if (i.terms.length === 1 && i.terms[0].type === "Group") return i.terms[0];
  return i;
}
var Vn = function () {};
function nx(r) {
  return typeof r === "function" ? r : Vn;
}
function al(r, t, i) {
  function o(l) {
    switch (n.call(i, l), l.type) {
      case "Group":
        l.terms.forEach(o);
        break;
      case "Multiplier":
      case "Boolean":
        o(l.term);
        break;
      case "Type":
      case "Property":
      case "Keyword":
      case "AtKeyword":
      case "Function":
      case "String":
      case "Token":
      case "Comma":
        break;
      default:
        throw new Error("Unknown type: " + l.type);
    }
    e.call(i, l);
  }
  let n = Vn,
    e = Vn;
  if (typeof t === "function") n = t;else
  if (t) n = nx(t.enter), e = nx(t.leave);
  if (n === Vn && e === Vn)
  throw new Error(
    "Neither `enter` nor `leave` walker handler is set or both aren't a function"
  );
  o(r, i);
}
var $1 = {
  decorator(r) {
    let t = [],
      i = null;
    return {
      ...r,
      node(o) {
        let n = i;
        i = o, r.node.call(this, o), i = n;
      },
      emit(o, n, e) {
        t.push({ type: n, value: o, node: e ? null : i });
      },
      result() {
        return t;
      }
    };
  }
};
function x1(r) {
  let t = [];
  return (
    bt(r, (i, o, n) => t.push({ type: i, value: r.slice(o, n), node: null })),
    t);

}
function pl(r, t) {
  if (typeof r === "string") return x1(r);
  return t.generate(r, $1);
}
var N = { type: "Match" },
  H = { type: "Mismatch" },
  uo = { type: "DisallowEmpty" },
  f1 = 40,
  w1 = 41;
function ar(r, t, i) {
  if (t === N && i === H) return r;
  if (r === N && t === N && i === N) return r;
  if (r.type === "If" && r.else === H && t === N) t = r.then, r = r.match;
  return { type: "If", match: r, then: t, else: i };
}
function ox(r) {
  return (
    r.length > 2 &&
    r.charCodeAt(r.length - 2) === f1 &&
    r.charCodeAt(r.length - 1) === w1);

}
function ix(r) {
  return (
    r.type === "Keyword" ||
    r.type === "AtKeyword" ||
    r.type === "Function" ||
    r.type === "Type" && ox(r.name));

}
function $t(r, t = " ", i = !1) {
  return {
    type: "Group",
    terms: r,
    combinator: t,
    disallowEmpty: !1,
    explicit: i
  };
}
function Yn(r, t, i = new Set()) {
  if (!i.has(r))
  switch (i.add(r), r.type) {
    case "If":
      r.match = Yn(r.match, t, i),
      r.then = Yn(r.then, t, i),
      r.else = Yn(r.else, t, i);
      break;
    case "Type":
      return t[r.name] || r;
  }
  return r;
}
function _l(r, t, i) {
  switch (r) {
    case " ":{
        let o = N;
        for (let n = t.length - 1; n >= 0; n--) {
          let e = t[n];
          o = ar(e, o, H);
        }
        return o;
      }
    case "|":{
        let o = H,
          n = null;
        for (let e = t.length - 1; e >= 0; e--) {
          let l = t[e];
          if (ix(l)) {
            if (n === null && e > 0 && ix(t[e - 1]))
            n = Object.create(null),
            o = ar({ type: "Enum", map: n }, N, o);
            if (n !== null) {
              let u = (ox(l.name) ? l.name.slice(0, -1) : l.name).toLowerCase();
              if (u in n === !1) {
                n[u] = l;
                continue;
              }
            }
          }
          n = null, o = ar(l, N, o);
        }
        return o;
      }
    case "&&":{
        if (t.length > 5) return { type: "MatchOnce", terms: t, all: !0 };
        let o = H;
        for (let n = t.length - 1; n >= 0; n--) {
          let e = t[n],
            l;
          if (t.length > 1)
          l = _l(
            r,
            t.filter(function (u) {
              return u !== e;
            }),
            !1
          );else
          l = N;
          o = ar(e, l, o);
        }
        return o;
      }
    case "||":{
        if (t.length > 5) return { type: "MatchOnce", terms: t, all: !1 };
        let o = i ? N : H;
        for (let n = t.length - 1; n >= 0; n--) {
          let e = t[n],
            l;
          if (t.length > 1)
          l = _l(
            r,
            t.filter(function (u) {
              return u !== e;
            }),
            !0
          );else
          l = N;
          o = ar(e, l, o);
        }
        return o;
      }
  }
}
function z1(r) {
  let t = N,
    i = Tt(r.term);
  if (r.max === 0) {
    if (
    i = ar(i, uo, H),
    t = ar(i, null, H),
    t.then = ar(N, N, t),
    r.comma)

    t.then.else = ar({ type: "Comma", syntax: r }, t, H);
  } else
  for (let o = r.min || 1; o <= r.max; o++) {
    if (r.comma && t !== N) t = ar({ type: "Comma", syntax: r }, t, H);
    t = ar(i, ar(N, N, t), H);
  }
  if (r.min === 0) t = ar(N, N, t);else

  for (let o = 0; o < r.min - 1; o++) {
    if (r.comma && t !== N) t = ar({ type: "Comma", syntax: r }, t, H);
    t = ar(i, t, H);
  }
  return t;
}
function Tt(r) {
  if (typeof r === "function") return { type: "Generic", fn: r };
  switch (r.type) {
    case "Group":{
        let t = _l(r.combinator, r.terms.map(Tt), !1);
        if (r.disallowEmpty) t = ar(t, uo, H);
        return t;
      }
    case "Multiplier":
      return z1(r);
    case "Boolean":{
        let t = Tt(r.term),
          i = Tt(
            $t(
              [
              $t([
              { type: "Keyword", name: "not" },
              { type: "Type", name: "!boolean-group" }]
              ),
              $t([
              { type: "Type", name: "!boolean-group" },
              $t(
                [
                {
                  type: "Multiplier",
                  comma: !1,
                  min: 0,
                  max: 0,
                  term: $t([
                  { type: "Keyword", name: "and" },
                  { type: "Type", name: "!boolean-group" }]
                  )
                },
                {
                  type: "Multiplier",
                  comma: !1,
                  min: 0,
                  max: 0,
                  term: $t([
                  { type: "Keyword", name: "or" },
                  { type: "Type", name: "!boolean-group" }]
                  )
                }],

                "|"
              )]
              )],

              "|"
            )
          ),
          o = Tt(
            $t(
              [
              { type: "Type", name: "!term" },
              $t([
              { type: "Token", value: "(" },
              { type: "Type", name: "!self" },
              { type: "Token", value: ")" }]
              ),
              { type: "Type", name: "general-enclosed" }],

              "|"
            )
          );
        return (
          Yn(o, { "!term": t, "!self": i }),
          Yn(i, { "!boolean-group": o }),
          i);

      }
    case "Type":
    case "Property":
      return { type: r.type, name: r.name, syntax: r };
    case "Keyword":
      return { type: r.type, name: r.name.toLowerCase(), syntax: r };
    case "AtKeyword":
      return { type: r.type, name: "@" + r.name.toLowerCase(), syntax: r };
    case "Function":
      return { type: r.type, name: r.name.toLowerCase() + "(", syntax: r };
    case "String":
      if (r.value.length === 3)
      return { type: "Token", value: r.value.charAt(1), syntax: r };
      return {
        type: r.type,
        value: r.value.substr(1, r.value.length - 2).replace(/\\'/g, "'"),
        syntax: r
      };
    case "Token":
      return { type: r.type, value: r.value, syntax: r };
    case "Comma":
      return { type: r.type, syntax: r };
    default:
      throw new Error("Unknown node type:", r.type);
  }
}
function En(r, t) {
  if (typeof r === "string") r = Ln(r);
  return { type: "MatchGraph", match: Tt(r), syntax: t || null, source: r };
}
var { hasOwnProperty: ex } = Object.prototype,
  a1 = 0,
  p1 = 1,
  jl = 2,
  mx = 3,
  lx = "Match",
  _1 = "Mismatch",
  D1 =
  "Maximum iteration number exceeded (please fill an issue on https://github.com/csstree/csstree/issues)",
  cx = 15000,
  j1 = 0;
function O1(r) {
  let t = null,
    i = null,
    o = r;
  while (o !== null) i = o.prev, o.prev = t, t = o, o = i;
  return t;
}
function Dl(r, t) {
  if (r.length !== t.length) return !1;
  for (let i = 0; i < r.length; i++) {
    let o = t.charCodeAt(i),
      n = r.charCodeAt(i);
    if (n >= 65 && n <= 90) n = n | 32;
    if (n !== o) return !1;
  }
  return !0;
}
function I1(r) {
  if (r.type !== P) return !1;
  return r.value !== "?";
}
function ux(r) {
  if (r === null) return !0;
  return (
    r.type === ir ||
    r.type === k ||
    r.type === K ||
    r.type === mr ||
    r.type === Z ||
    I1(r));

}
function gx(r) {
  if (r === null) return !0;
  return (
    r.type === j ||
    r.type === wr ||
    r.type === xr ||
    r.type === P && r.value === "/");

}
function k1(r, t, i) {
  function o() {
    do J++, _ = J < r.length ? r[J] : null; while (
    _ !== null && (_.type === Y || _.type === A));
  }
  function n(W) {
    let Q = J + W;
    return Q < r.length ? r[Q] : null;
  }
  function e(W, Q) {
    return {
      nextState: W,
      matchStack: X,
      syntaxStack: v,
      thenStack: h,
      tokenIndex: J,
      prev: Q
    };
  }
  function l(W) {
    h = { nextState: W, matchStack: X, syntaxStack: v, prev: h };
  }
  function u(W) {
    b = e(W, b);
  }
  function g() {
    if (
    X = { type: p1, syntax: t.syntax, token: _, prev: X },
    o(),
    f = null,
    J > V)

    V = J;
  }
  function c() {
    v = {
      syntax: t.syntax,
      opts: t.syntax.opts || v !== null && v.opts || null,
      prev: v
    },
    X = { type: jl, syntax: t.syntax, token: X.token, prev: X };
  }
  function m() {
    if (X.type === jl) X = X.prev;else
    X = { type: mx, syntax: v.syntax, token: X.token, prev: X };
    v = v.prev;
  }
  let v = null,
    h = null,
    b = null,
    f = null,
    D = 0,
    O = null,
    _ = null,
    J = -1,
    V = 0,
    X = { type: a1, syntax: null, token: null, prev: null };
  o();
  while (O === null && ++D < cx)
  switch (t.type) {
    case "Match":
      if (h === null) {
        if (_ !== null) {
          if (
          J !== r.length - 1 ||
          _.value !== "\\0" && _.value !== "\\9")
          {
            t = H;
            break;
          }
        }
        O = lx;
        break;
      }
      if (t = h.nextState, t === uo)
      if (h.matchStack === X) {
        t = H;
        break;
      } else t = N;
      while (h.syntaxStack !== v) m();
      h = h.prev;
      break;
    case "Mismatch":
      if (f !== null && f !== !1) {
        if (b === null || J > b.tokenIndex) b = f, f = !1;
      } else if (b === null) {
        O = _1;
        break;
      }
      t = b.nextState,
      h = b.thenStack,
      v = b.syntaxStack,
      X = b.matchStack,
      J = b.tokenIndex,
      _ = J < r.length ? r[J] : null,
      b = b.prev;
      break;
    case "MatchGraph":
      t = t.match;
      break;
    case "If":
      if (t.else !== H) u(t.else);
      if (t.then !== N) l(t.then);
      t = t.match;
      break;
    case "MatchOnce":
      t = { type: "MatchOnceBuffer", syntax: t, index: 0, mask: 0 };
      break;
    case "MatchOnceBuffer":{
        let B = t.syntax.terms;
        if (t.index === B.length) {
          if (t.mask === 0 || t.syntax.all) {
            t = H;
            break;
          }
          t = N;
          break;
        }
        if (t.mask === (1 << B.length) - 1) {
          t = N;
          break;
        }
        for (; t.index < B.length; t.index++) {
          let tr = 1 << t.index;
          if ((t.mask & tr) === 0) {
            u(t),
            l({ type: "AddMatchOnce", syntax: t.syntax, mask: t.mask | tr }),
            t = B[t.index++];
            break;
          }
        }
        break;
      }
    case "AddMatchOnce":
      t = {
        type: "MatchOnceBuffer",
        syntax: t.syntax,
        index: 0,
        mask: t.mask
      };
      break;
    case "Enum":
      if (_ !== null) {
        let B = _.value.toLowerCase();
        if (B.indexOf("\\") !== -1) B = B.replace(/\\[09].*$/, "");
        if (ex.call(t.map, B)) {
          t = t.map[B];
          break;
        }
      }
      t = H;
      break;
    case "Generic":{
        let B = v !== null ? v.opts : null,
          tr = J + Math.floor(t.fn(_, n, B));
        if (!isNaN(tr) && tr > J) {
          while (J < tr) g();
          t = N;
        } else t = H;
        break;
      }
    case "Type":
    case "Property":{
        let B = t.type === "Type" ? "types" : "properties",
          tr = ex.call(i, B) ? i[B][t.name] : null;
        if (!tr || !tr.match)
        throw new Error(
          "Bad syntax reference: " + (
          t.type === "Type" ? "<" + t.name + ">" : "<'" + t.name + "'>")
        );
        if (f !== !1 && _ !== null && t.type === "Type") {
          if (
          t.name === "custom-ident" && _.type === w ||
          t.name === "length" && _.value === "0")
          {
            if (f === null) f = e(t, b);
            t = H;
            break;
          }
        }
        c(), t = tr.matchRef || tr.match;
        break;
      }
    case "Keyword":{
        let B = t.name;
        if (_ !== null) {
          let tr = _.value;
          if (tr.indexOf("\\") !== -1) tr = tr.replace(/\\[09].*$/, "");
          if (Dl(tr, B)) {
            g(), t = N;
            break;
          }
        }
        t = H;
        break;
      }
    case "AtKeyword":
    case "Function":
      if (_ !== null && Dl(_.value, t.name)) {
        g(), t = N;
        break;
      }
      t = H;
      break;
    case "Token":
      if (_ !== null && _.value === t.value) {
        g(), t = N;
        break;
      }
      t = H;
      break;
    case "Comma":
      if (_ !== null && _.type === ir) {
        if (ux(X.token)) t = H;else
        g(), t = gx(_) ? H : N;
      } else t = ux(X.token) || gx(_) ? N : H;
      break;
    case "String":
      let W = "",
        Q = J;
      for (; Q < r.length && W.length < t.value.length; Q++) W += r[Q].value;
      if (Dl(W, t.value)) {
        while (J < Q) g();
        t = N;
      } else t = H;
      break;
    default:
      throw new Error("Unknown node type: " + t.type);
  }
  switch (j1 += D, O) {
    case null:
      console.warn("[csstree-match] BREAK after " + cx + " iterations"),
      O = D1,
      X = null;
      break;
    case lx:
      while (v !== null) m();
      break;
    default:
      X = null;
  }
  return { tokens: r, reason: O, iterations: D, match: X, longestMatch: V };
}
function Ol(r, t, i) {
  let o = k1(r, t, i || {});
  if (o.match === null) return o;
  let n = o.match,
    e = o.match = { syntax: t.syntax || null, match: [] },
    l = [e];
  n = O1(n).prev;
  while (n !== null) {
    switch (n.type) {
      case jl:
        e.match.push(e = { syntax: n.syntax, match: [] }), l.push(e);
        break;
      case mx:
        l.pop(), e = l[l.length - 1];
        break;
      default:
        e.match.push({
          syntax: n.syntax || null,
          token: n.token.value,
          node: n.token.node
        });
    }
    n = n.prev;
  }
  return o;
}
var kl = {};
I(kl, {
  isType: () => U1,
  isProperty: () => J1,
  isKeyword: () => P1,
  getTrace: () => bx
});
function bx(r) {
  function t(n) {
    if (n === null) return !1;
    return n.type === "Type" || n.type === "Property" || n.type === "Keyword";
  }
  function i(n) {
    if (Array.isArray(n.match)) {
      for (let e = 0; e < n.match.length; e++)
      if (i(n.match[e])) {
        if (t(n.syntax)) o.unshift(n.syntax);
        return !0;
      }
    } else if (n.node === r) return o = t(n.syntax) ? [n.syntax] : [], !0;
    return !1;
  }
  let o = null;
  if (this.matched !== null) i(this.matched);
  return o;
}
function U1(r, t) {
  return Il(this, r, (i) => i.type === "Type" && i.name === t);
}
function J1(r, t) {
  return Il(this, r, (i) => i.type === "Property" && i.name === t);
}
function P1(r) {
  return Il(this, r, (t) => t.type === "Keyword");
}
function Il(r, t, i) {
  let o = bx.call(r, t);
  if (o === null) return !1;
  return o.some(i);
}
function vx(r) {
  if ("node" in r) return r.node;
  return vx(r.match[0]);
}
function hx(r) {
  if ("node" in r) return r.node;
  return hx(r.match[r.match.length - 1]);
}
function Ul(r, t, i, o, n) {
  function e(u) {
    if (u.syntax !== null && u.syntax.type === o && u.syntax.name === n) {
      let g = vx(u),
        c = hx(u);
      r.syntax.walk(t, function (m, v, h) {
        if (m === g) {
          let b = new or();
          do {
            if (b.appendData(v.data), v.data === c) break;
            v = v.next;
          } while (v !== null);
          l.push({ parent: h, nodes: b });
        }
      });
    }
    if (Array.isArray(u.match)) u.match.forEach(e);
  }
  let l = [];
  if (i.matched !== null) e(i.matched);
  return l;
}
var { hasOwnProperty: Qn } = Object.prototype;
function Jl(r) {
  return typeof r === "number" && isFinite(r) && Math.floor(r) === r && r >= 0;
}
function $x(r) {
  return Boolean(r) && Jl(r.offset) && Jl(r.line) && Jl(r.column);
}
function X1(r, t) {
  return function i(o, n) {
    if (!o || o.constructor !== Object)
    return n(o, "Type of node should be an Object");
    for (let e in o) {
      let l = !0;
      if (Qn.call(o, e) === !1) continue;
      if (e === "type") {
        if (o.type !== r)
        n(o, "Wrong node type `" + o.type + "`, expected `" + r + "`");
      } else if (e === "loc") {
        if (o.loc === null) continue;else
        if (o.loc && o.loc.constructor === Object)
        if (typeof o.loc.source !== "string") e += ".source";else
        if (!$x(o.loc.start)) e += ".start";else
        if (!$x(o.loc.end)) e += ".end";else
        continue;
        l = !1;
      } else if (t.hasOwnProperty(e)) {
        l = !1;
        for (let u = 0; !l && u < t[e].length; u++) {
          let g = t[e][u];
          switch (g) {
            case String:
              l = typeof o[e] === "string";
              break;
            case Boolean:
              l = typeof o[e] === "boolean";
              break;
            case null:
              l = o[e] === null;
              break;
            default:
              if (typeof g === "string") l = o[e] && o[e].type === g;else
              if (Array.isArray(g)) l = o[e] instanceof or;
          }
        }
      } else n(o, "Unknown field `" + e + "` for " + r + " node type");
      if (!l) n(o, "Bad value for `" + r + "." + e + "`");
    }
    for (let e in t)
    if (Qn.call(t, e) && Qn.call(o, e) === !1)
    n(o, "Field `" + r + "." + e + "` is missed");
  };
}
function xx(r, t) {
  let i = [];
  for (let o = 0; o < r.length; o++) {
    let n = r[o];
    if (n === String || n === Boolean) i.push(n.name.toLowerCase());else
    if (n === null) i.push("null");else
    if (typeof n === "string") i.push(n);else
    if (Array.isArray(n)) i.push("List<" + (xx(n, t) || "any") + ">");else

    throw new Error(
      "Wrong value `" + n + "` in `" + t + "` structure definition"
    );
  }
  return i.join(" | ");
}
function q1(r, t) {
  let i = t.structure,
    o = { type: String, loc: !0 },
    n = { type: '"' + r + '"' };
  for (let e in i) {
    if (Qn.call(i, e) === !1) continue;
    let l = o[e] = Array.isArray(i[e]) ? i[e].slice() : [i[e]];
    n[e] = xx(l, r + "." + e);
  }
  return { docs: n, check: X1(r, o) };
}
function fx(r) {
  let t = {};
  if (r.node) {
    for (let i in r.node)
    if (Qn.call(r.node, i)) {
      let o = r.node[i];
      if (o.structure) t[i] = q1(i, o);else

      throw new Error(
        "Missed `structure` field in `" + i + "` node type definition"
      );
    }
  }
  return t;
}
function Pl(r, t, i) {
  let o = {};
  for (let n in r)
  if (r[n].syntax) o[n] = i ? r[n].syntax : Ht(r[n].syntax, { compact: t });
  return o;
}
function W1(r, t, i) {
  let o = {};
  for (let [n, e] of Object.entries(r))
  o[n] = {
    prelude:
    e.prelude && (
    i ? e.prelude.syntax : Ht(e.prelude.syntax, { compact: t })),
    descriptors: e.descriptors && Pl(e.descriptors, t, i)
  };
  return o;
}
function K1(r) {
  for (let t = 0; t < r.length; t++)
  if (r[t].value.toLowerCase() === "var(") return !0;
  return !1;
}
function L1(r) {
  let t = r.terms[0];
  return (
    r.explicit === !1 &&
    r.terms.length === 1 &&
    t.type === "Multiplier" &&
    t.comma === !0);

}
function Sr(r, t, i) {
  return { matched: r, iterations: i, error: t, ...kl };
}
function dt(r, t, i, o) {
  let n = pl(i, r.syntax),
    e;
  if (K1(n))
  return Sr(
    null,
    new Error("Matching for a tree with var() is not supported")
  );
  if (o) e = Ol(n, r.cssWideKeywordsSyntax, r);
  if (!o || !e.match) {
    if (e = Ol(n, t.match, r), !e.match)
    return Sr(null, new V0(e.reason, t.syntax, i, e), e.iterations);
  }
  return Sr(e.match, null, e.iterations);
}
class Fn {
  constructor(r, t, i) {
    if (
    this.cssWideKeywords = Zt,
    this.syntax = t,
    this.generic = !1,
    this.units = { ...eo },
    this.atrules = Object.create(null),
    this.properties = Object.create(null),
    this.types = Object.create(null),
    this.structure = i || fx(r),
    r)
    {
      if (r.cssWideKeywords) this.cssWideKeywords = r.cssWideKeywords;
      if (r.units) {
        for (let o of Object.keys(eo))
        if (Array.isArray(r.units[o])) this.units[o] = r.units[o];
      }
      if (r.types)
      for (let [o, n] of Object.entries(r.types)) this.addType_(o, n);
      if (r.generic) {
        this.generic = !0;
        for (let [o, n] of Object.entries(y0(this.units))) this.addType_(o, n);
      }
      if (r.atrules)
      for (let [o, n] of Object.entries(r.atrules)) this.addAtrule_(o, n);
      if (r.properties)
      for (let [o, n] of Object.entries(r.properties))
      this.addProperty_(o, n);
    }
    this.cssWideKeywordsSyntax = En(this.cssWideKeywords.join(" |  "));
  }
  checkStructure(r) {
    function t(n, e) {
      o.push({ node: n, message: e });
    }
    let i = this.structure,
      o = [];
    return (
      this.syntax.walk(r, function (n) {
        if (i.hasOwnProperty(n.type)) i[n.type].check(n, t);else
        t(n, "Unknown node type `" + n.type + "`");
      }),
      o.length ? o : !1);

  }
  createDescriptor(r, t, i, o = null) {
    let n = { type: t, name: i },
      e = {
        type: t,
        name: i,
        parent: o,
        serializable:
        typeof r === "string" || r && typeof r.type === "string",
        syntax: null,
        match: null,
        matchRef: null
      };
    if (typeof r === "function") e.match = En(r, n);else
    {
      if (typeof r === "string")
      Object.defineProperty(e, "syntax", {
        get() {
          return (
            Object.defineProperty(e, "syntax", { value: Ln(r) }),
            e.syntax);

        }
      });else
      e.syntax = r;
      if (
      Object.defineProperty(e, "match", {
        get() {
          return (
            Object.defineProperty(e, "match", { value: En(e.syntax, n) }),
            e.match);

        }
      }),
      t === "Property")

      Object.defineProperty(e, "matchRef", {
        get() {
          let l = e.syntax,
            u = L1(l) ? En({ ...l, terms: [l.terms[0].term] }, n) : null;
          return Object.defineProperty(e, "matchRef", { value: u }), u;
        }
      });
    }
    return e;
  }
  addAtrule_(r, t) {
    if (!t) return;
    this.atrules[r] = {
      type: "Atrule",
      name: r,
      prelude: t.prelude ?
      this.createDescriptor(t.prelude, "AtrulePrelude", r) :
      null,
      descriptors: t.descriptors ?
      Object.keys(t.descriptors).reduce((i, o) => {
        return (
          i[o] = this.createDescriptor(
            t.descriptors[o],
            "AtruleDescriptor",
            o,
            r
          ),
          i);

      }, Object.create(null)) :
      null
    };
  }
  addProperty_(r, t) {
    if (!t) return;
    this.properties[r] = this.createDescriptor(t, "Property", r);
  }
  addType_(r, t) {
    if (!t) return;
    this.types[r] = this.createDescriptor(t, "Type", r);
  }
  checkAtruleName(r) {
    if (!this.getAtrule(r)) return new Rt("Unknown at-rule", "@" + r);
  }
  checkAtrulePrelude(r, t) {
    let i = this.checkAtruleName(r);
    if (i) return i;
    let o = this.getAtrule(r);
    if (!o.prelude && t)
    return new SyntaxError(
      "At-rule `@" + r + "` should not contain a prelude"
    );
    if (o.prelude && !t) {
      if (!dt(this, o.prelude, "", !1).matched)
      return new SyntaxError("At-rule `@" + r + "` should contain a prelude");
    }
  }
  checkAtruleDescriptorName(r, t) {
    let i = this.checkAtruleName(r);
    if (i) return i;
    let o = this.getAtrule(r),
      n = to(t);
    if (!o.descriptors)
    return new SyntaxError("At-rule `@" + r + "` has no known descriptors");
    if (!o.descriptors[n.name] && !o.descriptors[n.basename])
    return new Rt("Unknown at-rule descriptor", t);
  }
  checkPropertyName(r) {
    if (!this.getProperty(r)) return new Rt("Unknown property", r);
  }
  matchAtrulePrelude(r, t) {
    let i = this.checkAtrulePrelude(r, t);
    if (i) return Sr(null, i);
    let o = this.getAtrule(r);
    if (!o.prelude) return Sr(null, null);
    return dt(this, o.prelude, t || "", !1);
  }
  matchAtruleDescriptor(r, t, i) {
    let o = this.checkAtruleDescriptorName(r, t);
    if (o) return Sr(null, o);
    let n = this.getAtrule(r),
      e = to(t);
    return dt(this, n.descriptors[e.name] || n.descriptors[e.basename], i, !1);
  }
  matchDeclaration(r) {
    if (r.type !== "Declaration")
    return Sr(null, new Error("Not a Declaration node"));
    return this.matchProperty(r.property, r.value);
  }
  matchProperty(r, t) {
    if (tl(r).custom)
    return Sr(
      null,
      new Error("Lexer matching doesn't applicable for custom properties")
    );
    let i = this.checkPropertyName(r);
    if (i) return Sr(null, i);
    return dt(this, this.getProperty(r), t, !0);
  }
  matchType(r, t) {
    let i = this.getType(r);
    if (!i) return Sr(null, new Rt("Unknown type", r));
    return dt(this, i, t, !1);
  }
  match(r, t) {
    if (typeof r !== "string" && (!r || !r.type))
    return Sr(null, new Rt("Bad syntax"));
    if (typeof r === "string" || !r.match)
    r = this.createDescriptor(r, "Type", "anonymous");
    return dt(this, r, t, !1);
  }
  findValueFragments(r, t, i, o) {
    return Ul(this, t, this.matchProperty(r, t), i, o);
  }
  findDeclarationValueFragments(r, t, i) {
    return Ul(this, r.value, this.matchDeclaration(r), t, i);
  }
  findAllFragments(r, t, i) {
    let o = [];
    return (
      this.syntax.walk(r, {
        visit: "Declaration",
        enter: (n) => {
          o.push.apply(o, this.findDeclarationValueFragments(n, t, i));
        }
      }),
      o);

  }
  getAtrule(r, t = !0) {
    let i = to(r);
    return (
      (i.vendor && t ?
      this.atrules[i.name] || this.atrules[i.basename] :
      this.atrules[i.name]) || null);

  }
  getAtrulePrelude(r, t = !0) {
    let i = this.getAtrule(r, t);
    return i && i.prelude || null;
  }
  getAtruleDescriptor(r, t) {
    return this.atrules.hasOwnProperty(r) && this.atrules.declarators ?
    this.atrules[r].declarators[t] || null :
    null;
  }
  getProperty(r, t = !0) {
    let i = tl(r);
    return (
      (i.vendor && t ?
      this.properties[i.name] || this.properties[i.basename] :
      this.properties[i.name]) || null);

  }
  getType(r) {
    return hasOwnProperty.call(this.types, r) ? this.types[r] : null;
  }
  validate() {
    function r(u, g) {
      return g ? `<${u}>` : `<'${u}'>`;
    }
    function t(u, g, c, m) {
      if (c.has(g)) return c.get(g);
      if (c.set(g, !1), m.syntax !== null)
      al(
        m.syntax,
        function (v) {
          if (v.type !== "Type" && v.type !== "Property") return;
          let h = v.type === "Type" ? u.types : u.properties,
            b = v.type === "Type" ? o : n;
          if (!hasOwnProperty.call(h, v.name))
          i.push(
            `${r(g, c === o)} used missed syntax definition ${r(v.name, v.type === "Type")}`
          ),
          c.set(g, !0);else
          if (t(u, v.name, b, h[v.name]))
          i.push(
            `${r(g, c === o)} used broken syntax definition ${r(v.name, v.type === "Type")}`
          ),
          c.set(g, !0);
        },
        this
      );
    }
    let i = [],
      o = new Map(),
      n = new Map();
    for (let u in this.types) t(this, u, o, this.types[u]);
    for (let u in this.properties) t(this, u, n, this.properties[u]);
    let e = [...o.keys()].filter((u) => o.get(u)),
      l = [...n.keys()].filter((u) => n.get(u));
    if (e.length || l.length) return { errors: i, types: e, properties: l };
    return null;
  }
  dump(r, t) {
    return {
      generic: this.generic,
      cssWideKeywords: this.cssWideKeywords,
      units: this.units,
      types: Pl(this.types, !t, r),
      properties: Pl(this.properties, !t, r),
      atrules: W1(this.atrules, !t, r)
    };
  }
  toString() {
    return JSON.stringify(this.dump());
  }
}
function Xl(r, t) {
  if (typeof t === "string" && /^\s*\|/.test(t))
  return typeof r === "string" ? r + t : t.replace(/^\s*\|\s*/, "");
  return t || null;
}
function wx(r, t) {
  let i = Object.create(null);
  for (let [o, n] of Object.entries(r))
  if (n) {
    i[o] = {};
    for (let e of Object.keys(n)) if (t.includes(e)) i[o][e] = n[e];
  }
  return i;
}
function Sn(r, t) {
  let i = { ...r };
  for (let [o, n] of Object.entries(t))
  switch (o) {
    case "generic":
      i[o] = Boolean(n);
      break;
    case "cssWideKeywords":
      i[o] = r[o] ? [...r[o], ...n] : n || [];
      break;
    case "units":
      i[o] = { ...r[o] };
      for (let [e, l] of Object.entries(n))
      i[o][e] = Array.isArray(l) ? l : [];
      break;
    case "atrules":
      i[o] = { ...r[o] };
      for (let [e, l] of Object.entries(n)) {
        let u = i[o][e] || {},
          g = i[o][e] = {
            prelude: u.prelude || null,
            descriptors: { ...u.descriptors }
          };
        if (!l) continue;
        g.prelude = l.prelude ? Xl(g.prelude, l.prelude) : g.prelude || null;
        for (let [c, m] of Object.entries(l.descriptors || {}))
        g.descriptors[c] = m ? Xl(g.descriptors[c], m) : null;
        if (!Object.keys(g.descriptors).length) g.descriptors = null;
      }
      break;
    case "types":
    case "properties":
      i[o] = { ...r[o] };
      for (let [e, l] of Object.entries(n)) i[o][e] = Xl(i[o][e], l);
      break;
    case "scope":
    case "features":
      i[o] = { ...r[o] };
      for (let [e, l] of Object.entries(n)) i[o][e] = { ...i[o][e], ...l };
      break;
    case "parseContext":
      i[o] = { ...r[o], ...n };
      break;
    case "atrule":
    case "pseudo":
      i[o] = { ...r[o], ...wx(n, ["parse"]) };
      break;
    case "node":
      i[o] = {
        ...r[o],
        ...wx(n, ["name", "structure", "parse", "generate", "walkContext"])
      };
      break;
  }
  return i;
}
function zx(r) {
  let t = c0(r),
    i = K0(r),
    o = U0(r),
    { fromPlainObject: n, toPlainObject: e } = J0(i),
    l = {
      lexer: null,
      createLexer: (u) => new Fn(u, l, l.lexer.structure),
      tokenize: bt,
      parse: t,
      generate: o,
      walk: i,
      find: i.find,
      findLast: i.findLast,
      findAll: i.findAll,
      fromPlainObject: n,
      toPlainObject: e,
      fork(u) {
        let g = Sn({}, r);
        return zx(typeof u === "function" ? u(g) : Sn(g, u));
      }
    };
  return (
    l.lexer = new Fn(
      {
        generic: r.generic,
        cssWideKeywords: r.cssWideKeywords,
        units: r.units,
        types: r.types,
        atrules: r.atrules,
        properties: r.properties,
        node: r.node
      },
      l
    ),
    l);

}
var ql = (r) => zx(Sn({}, r));
var ax = {
  generic: !0,
  cssWideKeywords: ["initial", "inherit", "unset", "revert", "revert-layer"],
  units: {
    angle: ["deg", "grad", "rad", "turn"],
    decibel: ["db"],
    flex: ["fr"],
    frequency: ["hz", "khz"],
    length: [
    "cm",
    "mm",
    "q",
    "in",
    "pt",
    "pc",
    "px",
    "em",
    "rem",
    "ex",
    "rex",
    "cap",
    "rcap",
    "ch",
    "rch",
    "ic",
    "ric",
    "lh",
    "rlh",
    "vw",
    "svw",
    "lvw",
    "dvw",
    "vh",
    "svh",
    "lvh",
    "dvh",
    "vi",
    "svi",
    "lvi",
    "dvi",
    "vb",
    "svb",
    "lvb",
    "dvb",
    "vmin",
    "svmin",
    "lvmin",
    "dvmin",
    "vmax",
    "svmax",
    "lvmax",
    "dvmax",
    "cqw",
    "cqh",
    "cqi",
    "cqb",
    "cqmin",
    "cqmax"],

    resolution: ["dpi", "dpcm", "dppx", "x"],
    semitones: ["st"],
    time: ["s", "ms"]
  },
  types: {
    "abs()": "abs( <calc-sum> )",
    "absolute-size":
    "xx-small|x-small|small|medium|large|x-large|xx-large|xxx-large",
    "acos()": "acos( <calc-sum> )",
    "alpha-value": "<number>|<percentage>",
    "angle-percentage": "<angle>|<percentage>",
    "angular-color-hint": "<angle-percentage>",
    "angular-color-stop": "<color>&&<color-stop-angle>?",
    "angular-color-stop-list":
    "[<angular-color-stop> [, <angular-color-hint>]?]# , <angular-color-stop>",
    "animateable-feature": "scroll-position|contents|<custom-ident>",
    "asin()": "asin( <calc-sum> )",
    "atan()": "atan( <calc-sum> )",
    "atan2()": "atan2( <calc-sum> , <calc-sum> )",
    attachment: "scroll|fixed|local",
    "attr()": "attr( <attr-name> <type-or-unit>? [, <attr-fallback>]? )",
    "attr-matcher": "['~'|'|'|'^'|'$'|'*']? '='",
    "attr-modifier": "i|s",
    "attribute-selector":
    "'[' <wq-name> ']'|'[' <wq-name> <attr-matcher> [<string-token>|<ident-token>] <attr-modifier>? ']'",
    "auto-repeat":
    "repeat( [auto-fill|auto-fit] , [<line-names>? <fixed-size>]+ <line-names>? )",
    "auto-track-list":
    "[<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>? <auto-repeat> [<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>?",
    axis: "block|inline|x|y",
    "baseline-position": "[first|last]? baseline",
    "basic-shape":
    "<inset()>|<xywh()>|<rect()>|<circle()>|<ellipse()>|<polygon()>|<path()>",
    "bg-image": "none|<image>",
    "bg-layer":
    "<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
    "bg-position":
    "[[left|center|right|top|bottom|<length-percentage>]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]|[center|[left|right] <length-percentage>?]&&[center|[top|bottom] <length-percentage>?]]",
    "bg-size": "[<length-percentage>|auto]{1,2}|cover|contain",
    "blur()": "blur( <length> )",
    "blend-mode":
    "normal|multiply|screen|overlay|darken|lighten|color-dodge|color-burn|hard-light|soft-light|difference|exclusion|hue|saturation|color|luminosity",
    box: "border-box|padding-box|content-box",
    "brightness()": "brightness( <number-percentage> )",
    "calc()": "calc( <calc-sum> )",
    "calc-sum": "<calc-product> [['+'|'-'] <calc-product>]*",
    "calc-product": "<calc-value> ['*' <calc-value>|'/' <number>]*",
    "calc-value":
    "<number>|<dimension>|<percentage>|<calc-constant>|( <calc-sum> )",
    "calc-constant": "e|pi|infinity|-infinity|NaN",
    "cf-final-image": "<image>|<color>",
    "cf-mixing-image": "<percentage>?&&<image>",
    "circle()": "circle( [<shape-radius>]? [at <position>]? )",
    "clamp()": "clamp( <calc-sum>#{3} )",
    "class-selector": "'.' <ident-token>",
    "clip-source": "<url>",
    color:
    "<color-base>|currentColor|<system-color>|<device-cmyk()>|<light-dark()>|<-non-standard-color>",
    "color-stop": "<color-stop-length>|<color-stop-angle>",
    "color-stop-angle": "<angle-percentage>{1,2}",
    "color-stop-length": "<length-percentage>{1,2}",
    "color-stop-list":
    "[<linear-color-stop> [, <linear-color-hint>]?]# , <linear-color-stop>",
    "color-interpolation-method":
    "in [<rectangular-color-space>|<polar-color-space> <hue-interpolation-method>?|<custom-color-space>]",
    combinator: "'>'|'+'|'~'|['|' '|']",
    "common-lig-values": "[common-ligatures|no-common-ligatures]",
    "compat-auto":
    "searchfield|textarea|push-button|slider-horizontal|checkbox|radio|square-button|menulist|listbox|meter|progress-bar|button",
    "composite-style":
    "clear|copy|source-over|source-in|source-out|source-atop|destination-over|destination-in|destination-out|destination-atop|xor",
    "compositing-operator": "add|subtract|intersect|exclude",
    "compound-selector": "[<type-selector>? <subclass-selector>*]!",
    "compound-selector-list": "<compound-selector>#",
    "complex-selector":
    "<complex-selector-unit> [<combinator>? <complex-selector-unit>]*",
    "complex-selector-list": "<complex-selector>#",
    "conic-gradient()":
    "conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
    "contextual-alt-values": "[contextual|no-contextual]",
    "content-distribution": "space-between|space-around|space-evenly|stretch",
    "content-list":
    "[<string>|contents|<image>|<counter>|<quote>|<target>|<leader()>|<attr()>]+",
    "content-position": "center|start|end|flex-start|flex-end",
    "content-replacement": "<image>",
    "contrast()": "contrast( [<number-percentage>] )",
    "cos()": "cos( <calc-sum> )",
    counter: "<counter()>|<counters()>",
    "counter()": "counter( <counter-name> , <counter-style>? )",
    "counter-name": "<custom-ident>",
    "counter-style": "<counter-style-name>|symbols( )",
    "counter-style-name": "<custom-ident>",
    "counters()": "counters( <counter-name> , <string> , <counter-style>? )",
    "cross-fade()": "cross-fade( <cf-mixing-image> , <cf-final-image>? )",
    "cubic-bezier-timing-function":
    "ease|ease-in|ease-out|ease-in-out|cubic-bezier( <number [0,1]> , <number> , <number [0,1]> , <number> )",
    "deprecated-system-color":
    "ActiveBorder|ActiveCaption|AppWorkspace|Background|ButtonFace|ButtonHighlight|ButtonShadow|ButtonText|CaptionText|GrayText|Highlight|HighlightText|InactiveBorder|InactiveCaption|InactiveCaptionText|InfoBackground|InfoText|Menu|MenuText|Scrollbar|ThreeDDarkShadow|ThreeDFace|ThreeDHighlight|ThreeDLightShadow|ThreeDShadow|Window|WindowFrame|WindowText",
    "discretionary-lig-values":
    "[discretionary-ligatures|no-discretionary-ligatures]",
    "display-box": "contents|none",
    "display-inside": "flow|flow-root|table|flex|grid|ruby",
    "display-internal":
    "table-row-group|table-header-group|table-footer-group|table-row|table-cell|table-column-group|table-column|table-caption|ruby-base|ruby-text|ruby-base-container|ruby-text-container",
    "display-legacy":
    "inline-block|inline-list-item|inline-table|inline-flex|inline-grid",
    "display-listitem": "<display-outside>?&&[flow|flow-root]?&&list-item",
    "display-outside": "block|inline|run-in",
    "drop-shadow()": "drop-shadow( <length>{2,3} <color>? )",
    "east-asian-variant-values":
    "[jis78|jis83|jis90|jis04|simplified|traditional]",
    "east-asian-width-values": "[full-width|proportional-width]",
    "element()":
    "element( <custom-ident> , [first|start|last|first-except]? )|element( <id-selector> )",
    "ellipse()": "ellipse( [<shape-radius>{2}]? [at <position>]? )",
    "ending-shape": "circle|ellipse",
    "env()": "env( <custom-ident> , <declaration-value>? )",
    "exp()": "exp( <calc-sum> )",
    "explicit-track-list": "[<line-names>? <track-size>]+ <line-names>?",
    "family-name": "<string>|<custom-ident>+",
    "feature-tag-value": "<string> [<integer>|on|off]?",
    "feature-type":
    "@stylistic|@historical-forms|@styleset|@character-variant|@swash|@ornaments|@annotation",
    "feature-value-block":
    "<feature-type> '{' <feature-value-declaration-list> '}'",
    "feature-value-block-list": "<feature-value-block>+",
    "feature-value-declaration": "<custom-ident> : <integer>+ ;",
    "feature-value-declaration-list": "<feature-value-declaration>",
    "feature-value-name": "<custom-ident>",
    "fill-rule": "nonzero|evenodd",
    "filter-function":
    "<blur()>|<brightness()>|<contrast()>|<drop-shadow()>|<grayscale()>|<hue-rotate()>|<invert()>|<opacity()>|<saturate()>|<sepia()>",
    "filter-function-list": "[<filter-function>|<url>]+",
    "final-bg-layer":
    "<'background-color'>||<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
    "fixed-breadth": "<length-percentage>",
    "fixed-repeat":
    "repeat( [<integer [1,∞]>] , [<line-names>? <fixed-size>]+ <line-names>? )",
    "fixed-size":
    "<fixed-breadth>|minmax( <fixed-breadth> , <track-breadth> )|minmax( <inflexible-breadth> , <fixed-breadth> )",
    "font-stretch-absolute":
    "normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded|<percentage>",
    "font-variant-css21": "[normal|small-caps]",
    "font-weight-absolute": "normal|bold|<number [1,1000]>",
    "frequency-percentage": "<frequency>|<percentage>",
    "general-enclosed": "[<function-token> <any-value>? )]|[( <any-value>? )]",
    "generic-family":
    "<generic-script-specific>|<generic-complete>|<generic-incomplete>|<-non-standard-generic-family>",
    "generic-name": "serif|sans-serif|cursive|fantasy|monospace",
    "geometry-box": "<shape-box>|fill-box|stroke-box|view-box",
    gradient:
    "<linear-gradient()>|<repeating-linear-gradient()>|<radial-gradient()>|<repeating-radial-gradient()>|<conic-gradient()>|<repeating-conic-gradient()>|<-legacy-gradient>",
    "grayscale()": "grayscale( <number-percentage> )",
    "grid-line":
    "auto|<custom-ident>|[<integer>&&<custom-ident>?]|[span&&[<integer>||<custom-ident>]]",
    "historical-lig-values": "[historical-ligatures|no-historical-ligatures]",
    "hsl()":
    "hsl( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsl( <hue> , <percentage> , <percentage> , <alpha-value>? )",
    "hsla()":
    "hsla( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsla( <hue> , <percentage> , <percentage> , <alpha-value>? )",
    hue: "<number>|<angle>",
    "hue-rotate()": "hue-rotate( <angle> )",
    "hue-interpolation-method": "[shorter|longer|increasing|decreasing] hue",
    "hwb()":
    "hwb( [<hue>|none] [<percentage>|none] [<percentage>|none] [/ [<alpha-value>|none]]? )",
    "hypot()": "hypot( <calc-sum># )",
    image:
    "<url>|<image()>|<image-set()>|<element()>|<paint()>|<cross-fade()>|<gradient>",
    "image()": "image( <image-tags>? [<image-src>? , <color>?]! )",
    "image-set()": "image-set( <image-set-option># )",
    "image-set-option": "[<image>|<string>] [<resolution>||type( <string> )]",
    "image-src": "<url>|<string>",
    "image-tags": "ltr|rtl",
    "inflexible-breadth": "<length-percentage>|min-content|max-content|auto",
    "inset()": "inset( <length-percentage>{1,4} [round <'border-radius'>]? )",
    "invert()": "invert( <number-percentage> )",
    "keyframes-name": "<custom-ident>|<string>",
    "keyframe-block": "<keyframe-selector># { <declaration-list> }",
    "keyframe-block-list": "<keyframe-block>+",
    "keyframe-selector":
    "from|to|<percentage>|<timeline-range-name> <percentage>",
    "lab()":
    "lab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )",
    "layer()": "layer( <layer-name> )",
    "layer-name": "<ident> ['.' <ident>]*",
    "lch()":
    "lch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )",
    "leader()": "leader( <leader-type> )",
    "leader-type": "dotted|solid|space|<string>",
    "length-percentage": "<length>|<percentage>",
    "light-dark()": "light-dark( <color> , <color> )",
    "line-names": "'[' <custom-ident>* ']'",
    "line-name-list": "[<line-names>|<name-repeat>]+",
    "line-style":
    "none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset",
    "line-width": "<length>|thin|medium|thick",
    "linear-color-hint": "<length-percentage>",
    "linear-color-stop": "<color> <color-stop-length>?",
    "linear-gradient()":
    "linear-gradient( [[<angle>|to <side-or-corner>]||<color-interpolation-method>]? , <color-stop-list> )",
    "log()": "log( <calc-sum> , <calc-sum>? )",
    "mask-layer":
    "<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||<geometry-box>||[<geometry-box>|no-clip]||<compositing-operator>||<masking-mode>",
    "mask-position":
    "[<length-percentage>|left|center|right] [<length-percentage>|top|center|bottom]?",
    "mask-reference": "none|<image>|<mask-source>",
    "mask-source": "<url>",
    "masking-mode": "alpha|luminance|match-source",
    "matrix()": "matrix( <number>#{6} )",
    "matrix3d()": "matrix3d( <number>#{16} )",
    "max()": "max( <calc-sum># )",
    "media-and": "<media-in-parens> [and <media-in-parens>]+",
    "media-condition": "<media-not>|<media-and>|<media-or>|<media-in-parens>",
    "media-condition-without-or": "<media-not>|<media-and>|<media-in-parens>",
    "media-feature": "( [<mf-plain>|<mf-boolean>|<mf-range>] )",
    "media-in-parens":
    "( <media-condition> )|<media-feature>|<general-enclosed>",
    "media-not": "not <media-in-parens>",
    "media-or": "<media-in-parens> [or <media-in-parens>]+",
    "media-query":
    "<media-condition>|[not|only]? <media-type> [and <media-condition-without-or>]?",
    "media-query-list": "<media-query>#",
    "media-type": "<ident>",
    "mf-boolean": "<mf-name>",
    "mf-name": "<ident>",
    "mf-plain": "<mf-name> : <mf-value>",
    "mf-range":
    "<mf-name> ['<'|'>']? '='? <mf-value>|<mf-value> ['<'|'>']? '='? <mf-name>|<mf-value> '<' '='? <mf-name> '<' '='? <mf-value>|<mf-value> '>' '='? <mf-name> '>' '='? <mf-value>",
    "mf-value": "<number>|<dimension>|<ident>|<ratio>",
    "min()": "min( <calc-sum># )",
    "minmax()":
    "minmax( [<length-percentage>|min-content|max-content|auto] , [<length-percentage>|<flex>|min-content|max-content|auto] )",
    "mod()": "mod( <calc-sum> , <calc-sum> )",
    "name-repeat": "repeat( [<integer [1,∞]>|auto-fill] , <line-names>+ )",
    "named-color":
    "transparent|aliceblue|antiquewhite|aqua|aquamarine|azure|beige|bisque|black|blanchedalmond|blue|blueviolet|brown|burlywood|cadetblue|chartreuse|chocolate|coral|cornflowerblue|cornsilk|crimson|cyan|darkblue|darkcyan|darkgoldenrod|darkgray|darkgreen|darkgrey|darkkhaki|darkmagenta|darkolivegreen|darkorange|darkorchid|darkred|darksalmon|darkseagreen|darkslateblue|darkslategray|darkslategrey|darkturquoise|darkviolet|deeppink|deepskyblue|dimgray|dimgrey|dodgerblue|firebrick|floralwhite|forestgreen|fuchsia|gainsboro|ghostwhite|gold|goldenrod|gray|green|greenyellow|grey|honeydew|hotpink|indianred|indigo|ivory|khaki|lavender|lavenderblush|lawngreen|lemonchiffon|lightblue|lightcoral|lightcyan|lightgoldenrodyellow|lightgray|lightgreen|lightgrey|lightpink|lightsalmon|lightseagreen|lightskyblue|lightslategray|lightslategrey|lightsteelblue|lightyellow|lime|limegreen|linen|magenta|maroon|mediumaquamarine|mediumblue|mediumorchid|mediumpurple|mediumseagreen|mediumslateblue|mediumspringgreen|mediumturquoise|mediumvioletred|midnightblue|mintcream|mistyrose|moccasin|navajowhite|navy|oldlace|olive|olivedrab|orange|orangered|orchid|palegoldenrod|palegreen|paleturquoise|palevioletred|papayawhip|peachpuff|peru|pink|plum|powderblue|purple|rebeccapurple|red|rosybrown|royalblue|saddlebrown|salmon|sandybrown|seagreen|seashell|sienna|silver|skyblue|slateblue|slategray|slategrey|snow|springgreen|steelblue|tan|teal|thistle|tomato|turquoise|violet|wheat|white|whitesmoke|yellow|yellowgreen",
    "namespace-prefix": "<ident>",
    "ns-prefix": "[<ident-token>|'*']? '|'",
    "number-percentage": "<number>|<percentage>",
    "numeric-figure-values": "[lining-nums|oldstyle-nums]",
    "numeric-fraction-values": "[diagonal-fractions|stacked-fractions]",
    "numeric-spacing-values": "[proportional-nums|tabular-nums]",
    nth: "<an-plus-b>|even|odd",
    "opacity()": "opacity( [<number-percentage>] )",
    "overflow-position": "unsafe|safe",
    "outline-radius": "<length>|<percentage>",
    "page-body":
    "<declaration>? [; <page-body>]?|<page-margin-box> <page-body>",
    "page-margin-box": "<page-margin-box-type> '{' <declaration-list> '}'",
    "page-margin-box-type":
    "@top-left-corner|@top-left|@top-center|@top-right|@top-right-corner|@bottom-left-corner|@bottom-left|@bottom-center|@bottom-right|@bottom-right-corner|@left-top|@left-middle|@left-bottom|@right-top|@right-middle|@right-bottom",
    "page-selector-list": "[<page-selector>#]?",
    "page-selector": "<pseudo-page>+|<ident> <pseudo-page>*",
    "page-size": "A5|A4|A3|B5|B4|JIS-B5|JIS-B4|letter|legal|ledger",
    "path()": "path( [<fill-rule> ,]? <string> )",
    "paint()": "paint( <ident> , <declaration-value>? )",
    "perspective()": "perspective( [<length [0,∞]>|none] )",
    "polygon()":
    "polygon( <fill-rule>? , [<length-percentage> <length-percentage>]# )",
    "polar-color-space": "hsl|hwb|lch|oklch",
    position:
    "[[left|center|right]||[top|center|bottom]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]?|[[left|right] <length-percentage>]&&[[top|bottom] <length-percentage>]]",
    "pow()": "pow( <calc-sum> , <calc-sum> )",
    "pseudo-class-selector":
    "':' <ident-token>|':' <function-token> <any-value> ')'",
    "pseudo-element-selector":
    "':' <pseudo-class-selector>|<legacy-pseudo-element-selector>",
    "pseudo-page": ": [left|right|first|blank]",
    quote: "open-quote|close-quote|no-open-quote|no-close-quote",
    "radial-gradient()":
    "radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
    ratio: "<number [0,∞]> [/ <number [0,∞]>]?",
    "ray()": "ray( <angle>&&<ray-size>?&&contain?&&[at <position>]? )",
    "ray-size":
    "closest-side|closest-corner|farthest-side|farthest-corner|sides",
    "rectangular-color-space":
    "srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020|lab|oklab|xyz|xyz-d50|xyz-d65",
    "relative-selector": "<combinator>? <complex-selector>",
    "relative-selector-list": "<relative-selector>#",
    "relative-size": "larger|smaller",
    "rem()": "rem( <calc-sum> , <calc-sum> )",
    "repeat-style": "repeat-x|repeat-y|[repeat|space|round|no-repeat]{1,2}",
    "repeating-conic-gradient()":
    "repeating-conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
    "repeating-linear-gradient()":
    "repeating-linear-gradient( [<angle>|to <side-or-corner>]? , <color-stop-list> )",
    "repeating-radial-gradient()":
    "repeating-radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
    "reversed-counter-name": "reversed( <counter-name> )",
    "rgb()":
    "rgb( <percentage>{3} [/ <alpha-value>]? )|rgb( <number>{3} [/ <alpha-value>]? )|rgb( <percentage>#{3} , <alpha-value>? )|rgb( <number>#{3} , <alpha-value>? )",
    "rgba()":
    "rgba( <percentage>{3} [/ <alpha-value>]? )|rgba( <number>{3} [/ <alpha-value>]? )|rgba( <percentage>#{3} , <alpha-value>? )|rgba( <number>#{3} , <alpha-value>? )",
    "rotate()": "rotate( [<angle>|<zero>] )",
    "rotate3d()":
    "rotate3d( <number> , <number> , <number> , [<angle>|<zero>] )",
    "rotateX()": "rotateX( [<angle>|<zero>] )",
    "rotateY()": "rotateY( [<angle>|<zero>] )",
    "rotateZ()": "rotateZ( [<angle>|<zero>] )",
    "round()": "round( <rounding-strategy>? , <calc-sum> , <calc-sum> )",
    "rounding-strategy": "nearest|up|down|to-zero",
    "saturate()": "saturate( <number-percentage> )",
    "scale()": "scale( [<number>|<percentage>]#{1,2} )",
    "scale3d()": "scale3d( [<number>|<percentage>]#{3} )",
    "scaleX()": "scaleX( [<number>|<percentage>] )",
    "scaleY()": "scaleY( [<number>|<percentage>] )",
    "scaleZ()": "scaleZ( [<number>|<percentage>] )",
    "scroll()": "scroll( [<axis>||<scroller>]? )",
    scroller: "root|nearest|self",
    "self-position": "center|start|end|self-start|self-end|flex-start|flex-end",
    "shape-radius": "<length-percentage>|closest-side|farthest-side",
    "sign()": "sign( <calc-sum> )",
    "skew()": "skew( [<angle>|<zero>] , [<angle>|<zero>]? )",
    "skewX()": "skewX( [<angle>|<zero>] )",
    "skewY()": "skewY( [<angle>|<zero>] )",
    "sepia()": "sepia( <number-percentage> )",
    shadow: "inset?&&<length>{2,4}&&<color>?",
    "shadow-t": "[<length>{2,3}&&<color>?]",
    shape:
    "rect( <top> , <right> , <bottom> , <left> )|rect( <top> <right> <bottom> <left> )",
    "shape-box": "<box>|margin-box",
    "side-or-corner": "[left|right]||[top|bottom]",
    "sin()": "sin( <calc-sum> )",
    "single-animation":
    "<'animation-duration'>||<easing-function>||<'animation-delay'>||<single-animation-iteration-count>||<single-animation-direction>||<single-animation-fill-mode>||<single-animation-play-state>||[none|<keyframes-name>]||<single-animation-timeline>",
    "single-animation-direction": "normal|reverse|alternate|alternate-reverse",
    "single-animation-fill-mode": "none|forwards|backwards|both",
    "single-animation-iteration-count": "infinite|<number>",
    "single-animation-play-state": "running|paused",
    "single-animation-timeline": "auto|none|<dashed-ident>|<scroll()>|<view()>",
    "single-transition":
    "[none|<single-transition-property>]||<time>||<easing-function>||<time>||<transition-behavior-value>",
    "single-transition-property": "all|<custom-ident>",
    size: "closest-side|farthest-side|closest-corner|farthest-corner|<length>|<length-percentage>{2}",
    "sqrt()": "sqrt( <calc-sum> )",
    "step-position": "jump-start|jump-end|jump-none|jump-both|start|end",
    "step-timing-function":
    "step-start|step-end|steps( <integer> [, <step-position>]? )",
    "subclass-selector":
    "<id-selector>|<class-selector>|<attribute-selector>|<pseudo-class-selector>",
    "supports-condition":
    "not <supports-in-parens>|<supports-in-parens> [and <supports-in-parens>]*|<supports-in-parens> [or <supports-in-parens>]*",
    "supports-in-parens":
    "( <supports-condition> )|<supports-feature>|<general-enclosed>",
    "supports-feature": "<supports-decl>|<supports-selector-fn>",
    "supports-decl": "( <declaration> )",
    "supports-selector-fn": "selector( <complex-selector> )",
    symbol: "<string>|<image>|<custom-ident>",
    "system-color":
    "AccentColor|AccentColorText|ActiveText|ButtonBorder|ButtonFace|ButtonText|Canvas|CanvasText|Field|FieldText|GrayText|Highlight|HighlightText|LinkText|Mark|MarkText|SelectedItem|SelectedItemText|VisitedText",
    "tan()": "tan( <calc-sum> )",
    target: "<target-counter()>|<target-counters()>|<target-text()>",
    "target-counter()":
    "target-counter( [<string>|<url>] , <custom-ident> , <counter-style>? )",
    "target-counters()":
    "target-counters( [<string>|<url>] , <custom-ident> , <string> , <counter-style>? )",
    "target-text()":
    "target-text( [<string>|<url>] , [content|before|after|first-letter]? )",
    "time-percentage": "<time>|<percentage>",
    "timeline-range-name":
    "cover|contain|entry|exit|entry-crossing|exit-crossing",
    "easing-function":
    "linear|<cubic-bezier-timing-function>|<step-timing-function>",
    "track-breadth": "<length-percentage>|<flex>|min-content|max-content|auto",
    "track-list":
    "[<line-names>? [<track-size>|<track-repeat>]]+ <line-names>?",
    "track-repeat":
    "repeat( [<integer [1,∞]>] , [<line-names>? <track-size>]+ <line-names>? )",
    "track-size":
    "<track-breadth>|minmax( <inflexible-breadth> , <track-breadth> )|fit-content( <length-percentage> )",
    "transform-function":
    "<matrix()>|<translate()>|<translateX()>|<translateY()>|<scale()>|<scaleX()>|<scaleY()>|<rotate()>|<skew()>|<skewX()>|<skewY()>|<matrix3d()>|<translate3d()>|<translateZ()>|<scale3d()>|<scaleZ()>|<rotate3d()>|<rotateX()>|<rotateY()>|<rotateZ()>|<perspective()>",
    "transform-list": "<transform-function>+",
    "transition-behavior-value": "normal|allow-discrete",
    "translate()": "translate( <length-percentage> , <length-percentage>? )",
    "translate3d()":
    "translate3d( <length-percentage> , <length-percentage> , <length> )",
    "translateX()": "translateX( <length-percentage> )",
    "translateY()": "translateY( <length-percentage> )",
    "translateZ()": "translateZ( <length> )",
    "type-or-unit":
    "string|color|url|integer|number|length|angle|time|frequency|cap|ch|em|ex|ic|lh|rlh|rem|vb|vi|vw|vh|vmin|vmax|mm|Q|cm|in|pt|pc|px|deg|grad|rad|turn|ms|s|Hz|kHz|%",
    "type-selector": "<wq-name>|<ns-prefix>? '*'",
    "var()": "var( <custom-property-name> , <declaration-value>? )",
    "view()": "view( [<axis>||<'view-timeline-inset'>]? )",
    "viewport-length": "auto|<length-percentage>",
    "visual-box": "content-box|padding-box|border-box",
    "wq-name": "<ns-prefix>? <ident-token>",
    "-legacy-gradient":
    "<-webkit-gradient()>|<-legacy-linear-gradient>|<-legacy-repeating-linear-gradient>|<-legacy-radial-gradient>|<-legacy-repeating-radial-gradient>",
    "-legacy-linear-gradient":
    "-moz-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-linear-gradient( <-legacy-linear-gradient-arguments> )",
    "-legacy-repeating-linear-gradient":
    "-moz-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )",
    "-legacy-linear-gradient-arguments":
    "[<angle>|<side-or-corner>]? , <color-stop-list>",
    "-legacy-radial-gradient":
    "-moz-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-radial-gradient( <-legacy-radial-gradient-arguments> )",
    "-legacy-repeating-radial-gradient":
    "-moz-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )",
    "-legacy-radial-gradient-arguments":
    "[<position> ,]? [[[<-legacy-radial-gradient-shape>||<-legacy-radial-gradient-size>]|[<length>|<percentage>]{2}] ,]? <color-stop-list>",
    "-legacy-radial-gradient-size":
    "closest-side|closest-corner|farthest-side|farthest-corner|contain|cover",
    "-legacy-radial-gradient-shape": "circle|ellipse",
    "-non-standard-font":
    "-apple-system-body|-apple-system-headline|-apple-system-subheadline|-apple-system-caption1|-apple-system-caption2|-apple-system-footnote|-apple-system-short-body|-apple-system-short-headline|-apple-system-short-subheadline|-apple-system-short-caption1|-apple-system-short-footnote|-apple-system-tall-body",
    "-non-standard-color":
    "-moz-ButtonDefault|-moz-ButtonHoverFace|-moz-ButtonHoverText|-moz-CellHighlight|-moz-CellHighlightText|-moz-Combobox|-moz-ComboboxText|-moz-Dialog|-moz-DialogText|-moz-dragtargetzone|-moz-EvenTreeRow|-moz-Field|-moz-FieldText|-moz-html-CellHighlight|-moz-html-CellHighlightText|-moz-mac-accentdarkestshadow|-moz-mac-accentdarkshadow|-moz-mac-accentface|-moz-mac-accentlightesthighlight|-moz-mac-accentlightshadow|-moz-mac-accentregularhighlight|-moz-mac-accentregularshadow|-moz-mac-chrome-active|-moz-mac-chrome-inactive|-moz-mac-focusring|-moz-mac-menuselect|-moz-mac-menushadow|-moz-mac-menutextselect|-moz-MenuHover|-moz-MenuHoverText|-moz-MenuBarText|-moz-MenuBarHoverText|-moz-nativehyperlinktext|-moz-OddTreeRow|-moz-win-communicationstext|-moz-win-mediatext|-moz-activehyperlinktext|-moz-default-background-color|-moz-default-color|-moz-hyperlinktext|-moz-visitedhyperlinktext|-webkit-activelink|-webkit-focus-ring-color|-webkit-link|-webkit-text",
    "-non-standard-image-rendering":
    "optimize-contrast|-moz-crisp-edges|-o-crisp-edges|-webkit-optimize-contrast",
    "-non-standard-overflow":
    "overlay|-moz-scrollbars-none|-moz-scrollbars-horizontal|-moz-scrollbars-vertical|-moz-hidden-unscrollable",
    "-non-standard-size":
    "intrinsic|min-intrinsic|-webkit-fill-available|-webkit-fit-content|-webkit-min-content|-webkit-max-content|-moz-available|-moz-fit-content|-moz-min-content|-moz-max-content",
    "-webkit-gradient()":
    "-webkit-gradient( <-webkit-gradient-type> , <-webkit-gradient-point> [, <-webkit-gradient-point>|, <-webkit-gradient-radius> , <-webkit-gradient-point>] [, <-webkit-gradient-radius>]? [, <-webkit-gradient-color-stop>]* )",
    "-webkit-gradient-color-stop":
    "from( <color> )|color-stop( [<number-zero-one>|<percentage>] , <color> )|to( <color> )",
    "-webkit-gradient-point":
    "[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]",
    "-webkit-gradient-radius": "<length>|<percentage>",
    "-webkit-gradient-type": "linear|radial",
    "-webkit-mask-box-repeat": "repeat|stretch|round",
    "-ms-filter-function-list": "<-ms-filter-function>+",
    "-ms-filter-function":
    "<-ms-filter-function-progid>|<-ms-filter-function-legacy>",
    "-ms-filter-function-progid":
    "'progid:' [<ident-token> '.']* [<ident-token>|<function-token> <any-value>? )]",
    "-ms-filter-function-legacy":
    "<ident-token>|<function-token> <any-value>? )",
    "absolute-color-base":
    "<hex-color>|<absolute-color-function>|<named-color>|transparent",
    "absolute-color-function":
    "<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>",
    age: "child|young|old",
    "anchor-name": "<dashed-ident>",
    "attr-name": "<wq-name>",
    "attr-fallback": "<any-value>",
    "bg-clip": "<box>|border|text",
    bottom: "<length>|auto",
    "container-name": "<custom-ident>",
    "container-condition":
    "not <query-in-parens>|<query-in-parens> [[and <query-in-parens>]*|[or <query-in-parens>]*]",
    "coord-box":
    "content-box|padding-box|border-box|fill-box|stroke-box|view-box",
    "generic-voice": "[<age>? <gender> <integer>?]",
    gender: "male|female|neutral",
    "generic-script-specific":
    "generic( kai )|generic( fangsong )|generic( nastaliq )",
    "generic-complete":
    "serif|sans-serif|system-ui|cursive|fantasy|math|monospace",
    "generic-incomplete": "ui-serif|ui-sans-serif|ui-monospace|ui-rounded",
    "-non-standard-generic-family": "-apple-system|BlinkMacSystemFont",
    left: "<length>|auto",
    "color-base":
    "<hex-color>|<color-function>|<named-color>|<color-mix()>|transparent",
    "color-function":
    "<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>",
    "device-cmyk()": "<legacy-device-cmyk-syntax>|<modern-device-cmyk-syntax>",
    "legacy-device-cmyk-syntax": "device-cmyk( <number>#{4} )",
    "modern-device-cmyk-syntax":
    "device-cmyk( <cmyk-component>{4} [/ [<alpha-value>|none]]? )",
    "cmyk-component": "<number>|<percentage>|none",
    "color-mix()":
    "color-mix( <color-interpolation-method> , [<color>&&<percentage [0,100]>?]#{2} )",
    "color-space":
    "<rectangular-color-space>|<polar-color-space>|<custom-color-space>",
    "custom-color-space": "<dashed-ident>",
    paint: "none|<color>|<url> [none|<color>]?|context-fill|context-stroke",
    "palette-identifier": "<dashed-ident>",
    right: "<length>|auto",
    "scope-start": "<forgiving-selector-list>",
    "scope-end": "<forgiving-selector-list>",
    "forgiving-selector-list": "<complex-real-selector-list>",
    "forgiving-relative-selector-list": "<relative-real-selector-list>",
    "selector-list": "<complex-selector-list>",
    "complex-real-selector-list": "<complex-real-selector>#",
    "simple-selector-list": "<simple-selector>#",
    "relative-real-selector-list": "<relative-real-selector>#",
    "complex-selector-unit":
    "[<compound-selector>? <pseudo-compound-selector>*]!",
    "complex-real-selector":
    "<compound-selector> [<combinator>? <compound-selector>]*",
    "relative-real-selector": "<combinator>? <complex-real-selector>",
    "pseudo-compound-selector":
    "<pseudo-element-selector> <pseudo-class-selector>*",
    "simple-selector": "<type-selector>|<subclass-selector>",
    "legacy-pseudo-element-selector":
    "':' [before|after|first-line|first-letter]",
    "single-animation-composition": "replace|add|accumulate",
    "svg-length": "<percentage>|<length>|<number>",
    "svg-writing-mode": "lr-tb|rl-tb|tb-rl|lr|rl|tb",
    top: "<length>|auto",
    x: "<number>",
    y: "<number>",
    declaration: "<ident-token> : <declaration-value>? ['!' important]?",
    "declaration-list": "[<declaration>? ';']* <declaration>?",
    url: "url( <string> <url-modifier>* )|<url-token>",
    "url-modifier": "<ident>|<function-token> <any-value> )",
    "number-zero-one": "<number [0,1]>",
    "number-one-or-greater": "<number [1,∞]>",
    "color()": "color( <colorspace-params> [/ [<alpha-value>|none]]? )",
    "colorspace-params": "[<predefined-rgb-params>|<xyz-params>]",
    "predefined-rgb-params": "<predefined-rgb> [<number>|<percentage>|none]{3}",
    "predefined-rgb":
    "srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020",
    "xyz-params": "<xyz-space> [<number>|<percentage>|none]{3}",
    "xyz-space": "xyz|xyz-d50|xyz-d65",
    "oklab()":
    "oklab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )",
    "oklch()":
    "oklch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )",
    "offset-path": "<ray()>|<url>|<basic-shape>",
    "rect()":
    "rect( [<length-percentage>|auto]{4} [round <'border-radius'>]? )",
    "xywh()":
    "xywh( <length-percentage>{2} <length-percentage [0,∞]>{2} [round <'border-radius'>]? )",
    "query-in-parens":
    "( <container-condition> )|( <size-feature> )|style( <style-query> )|<general-enclosed>",
    "size-feature": "<mf-plain>|<mf-boolean>|<mf-range>",
    "style-feature": "<declaration>",
    "style-query": "<style-condition>|<style-feature>",
    "style-condition":
    "not <style-in-parens>|<style-in-parens> [[and <style-in-parens>]*|[or <style-in-parens>]*]",
    "style-in-parens":
    "( <style-condition> )|( <style-feature> )|<general-enclosed>",
    "-non-standard-display":
    "-ms-inline-flexbox|-ms-grid|-ms-inline-grid|-webkit-flex|-webkit-inline-flex|-webkit-box|-webkit-inline-box|-moz-inline-stack|-moz-box|-moz-inline-box",
    "inset-area":
    "[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]",
    "position-area":
    "[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|center|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|center|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]",
    "anchor()":
    "anchor( <anchor-element>?&&<anchor-side> , <length-percentage>? )",
    "anchor-side":
    "inside|outside|top|left|right|bottom|start|end|self-start|self-end|<percentage>|center",
    "anchor-size()":
    "anchor-size( [<anchor-element>||<anchor-size>]? , <length-percentage>? )",
    "anchor-size": "width|height|block|inline|self-block|self-inline",
    "anchor-element": "<dashed-ident>",
    "try-size": "most-width|most-height|most-block-size|most-inline-size",
    "try-tactic": "flip-block||flip-inline||flip-start",
    "font-variant-css2": "normal|small-caps",
    "font-width-css3":
    "normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded",
    "system-family-name":
    "caption|icon|menu|message-box|small-caption|status-bar"
  },
  properties: {
    "--*": "<declaration-value>",
    "-ms-accelerator": "false|true",
    "-ms-block-progression": "tb|rl|bt|lr",
    "-ms-content-zoom-chaining": "none|chained",
    "-ms-content-zooming": "none|zoom",
    "-ms-content-zoom-limit":
    "<'-ms-content-zoom-limit-min'> <'-ms-content-zoom-limit-max'>",
    "-ms-content-zoom-limit-max": "<percentage>",
    "-ms-content-zoom-limit-min": "<percentage>",
    "-ms-content-zoom-snap":
    "<'-ms-content-zoom-snap-type'>||<'-ms-content-zoom-snap-points'>",
    "-ms-content-zoom-snap-points":
    "snapInterval( <percentage> , <percentage> )|snapList( <percentage># )",
    "-ms-content-zoom-snap-type": "none|proximity|mandatory",
    "-ms-filter": "<string>",
    "-ms-flow-from": "[none|<custom-ident>]#",
    "-ms-flow-into": "[none|<custom-ident>]#",
    "-ms-grid-columns": "none|<track-list>|<auto-track-list>",
    "-ms-grid-rows": "none|<track-list>|<auto-track-list>",
    "-ms-high-contrast-adjust": "auto|none",
    "-ms-hyphenate-limit-chars": "auto|<integer>{1,3}",
    "-ms-hyphenate-limit-lines": "no-limit|<integer>",
    "-ms-hyphenate-limit-zone": "<percentage>|<length>",
    "-ms-ime-align": "auto|after",
    "-ms-overflow-style": "auto|none|scrollbar|-ms-autohiding-scrollbar",
    "-ms-scrollbar-3dlight-color": "<color>",
    "-ms-scrollbar-arrow-color": "<color>",
    "-ms-scrollbar-base-color": "<color>",
    "-ms-scrollbar-darkshadow-color": "<color>",
    "-ms-scrollbar-face-color": "<color>",
    "-ms-scrollbar-highlight-color": "<color>",
    "-ms-scrollbar-shadow-color": "<color>",
    "-ms-scrollbar-track-color": "<color>",
    "-ms-scroll-chaining": "chained|none",
    "-ms-scroll-limit":
    "<'-ms-scroll-limit-x-min'> <'-ms-scroll-limit-y-min'> <'-ms-scroll-limit-x-max'> <'-ms-scroll-limit-y-max'>",
    "-ms-scroll-limit-x-max": "auto|<length>",
    "-ms-scroll-limit-x-min": "<length>",
    "-ms-scroll-limit-y-max": "auto|<length>",
    "-ms-scroll-limit-y-min": "<length>",
    "-ms-scroll-rails": "none|railed",
    "-ms-scroll-snap-points-x":
    "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
    "-ms-scroll-snap-points-y":
    "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
    "-ms-scroll-snap-type": "none|proximity|mandatory",
    "-ms-scroll-snap-x":
    "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-x'>",
    "-ms-scroll-snap-y":
    "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-y'>",
    "-ms-scroll-translation": "none|vertical-to-horizontal",
    "-ms-text-autospace":
    "none|ideograph-alpha|ideograph-numeric|ideograph-parenthesis|ideograph-space",
    "-ms-touch-select": "grippers|none",
    "-ms-user-select": "none|element|text",
    "-ms-wrap-flow": "auto|both|start|end|maximum|clear",
    "-ms-wrap-margin": "<length>",
    "-ms-wrap-through": "wrap|none",
    "-moz-appearance":
    "none|button|button-arrow-down|button-arrow-next|button-arrow-previous|button-arrow-up|button-bevel|button-focus|caret|checkbox|checkbox-container|checkbox-label|checkmenuitem|dualbutton|groupbox|listbox|listitem|menuarrow|menubar|menucheckbox|menuimage|menuitem|menuitemtext|menulist|menulist-button|menulist-text|menulist-textfield|menupopup|menuradio|menuseparator|meterbar|meterchunk|progressbar|progressbar-vertical|progresschunk|progresschunk-vertical|radio|radio-container|radio-label|radiomenuitem|range|range-thumb|resizer|resizerpanel|scale-horizontal|scalethumbend|scalethumb-horizontal|scalethumbstart|scalethumbtick|scalethumb-vertical|scale-vertical|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|separator|sheet|spinner|spinner-downbutton|spinner-textfield|spinner-upbutton|splitter|statusbar|statusbarpanel|tab|tabpanel|tabpanels|tab-scroll-arrow-back|tab-scroll-arrow-forward|textfield|textfield-multiline|toolbar|toolbarbutton|toolbarbutton-dropdown|toolbargripper|toolbox|tooltip|treeheader|treeheadercell|treeheadersortarrow|treeitem|treeline|treetwisty|treetwistyopen|treeview|-moz-mac-unified-toolbar|-moz-win-borderless-glass|-moz-win-browsertabbar-toolbox|-moz-win-communicationstext|-moz-win-communications-toolbox|-moz-win-exclude-glass|-moz-win-glass|-moz-win-mediatext|-moz-win-media-toolbox|-moz-window-button-box|-moz-window-button-box-maximized|-moz-window-button-close|-moz-window-button-maximize|-moz-window-button-minimize|-moz-window-button-restore|-moz-window-frame-bottom|-moz-window-frame-left|-moz-window-frame-right|-moz-window-titlebar|-moz-window-titlebar-maximized",
    "-moz-binding": "<url>|none",
    "-moz-border-bottom-colors": "<color>+|none",
    "-moz-border-left-colors": "<color>+|none",
    "-moz-border-right-colors": "<color>+|none",
    "-moz-border-top-colors": "<color>+|none",
    "-moz-context-properties":
    "none|[fill|fill-opacity|stroke|stroke-opacity]#",
    "-moz-float-edge": "border-box|content-box|margin-box|padding-box",
    "-moz-force-broken-image-icon": "0|1",
    "-moz-image-region": "<shape>|auto",
    "-moz-orient": "inline|block|horizontal|vertical",
    "-moz-outline-radius": "<outline-radius>{1,4} [/ <outline-radius>{1,4}]?",
    "-moz-outline-radius-bottomleft": "<outline-radius>",
    "-moz-outline-radius-bottomright": "<outline-radius>",
    "-moz-outline-radius-topleft": "<outline-radius>",
    "-moz-outline-radius-topright": "<outline-radius>",
    "-moz-stack-sizing": "ignore|stretch-to-fit",
    "-moz-text-blink": "none|blink",
    "-moz-user-focus":
    "ignore|normal|select-after|select-before|select-menu|select-same|select-all|none",
    "-moz-user-input": "auto|none|enabled|disabled",
    "-moz-user-modify": "read-only|read-write|write-only",
    "-moz-window-dragging": "drag|no-drag",
    "-moz-window-shadow": "default|menu|tooltip|sheet|none",
    "-webkit-appearance":
    "none|button|button-bevel|caps-lock-indicator|caret|checkbox|default-button|inner-spin-button|listbox|listitem|media-controls-background|media-controls-fullscreen-background|media-current-time-display|media-enter-fullscreen-button|media-exit-fullscreen-button|media-fullscreen-button|media-mute-button|media-overlay-play-button|media-play-button|media-seek-back-button|media-seek-forward-button|media-slider|media-sliderthumb|media-time-remaining-display|media-toggle-closed-captions-button|media-volume-slider|media-volume-slider-container|media-volume-sliderthumb|menulist|menulist-button|menulist-text|menulist-textfield|meter|progress-bar|progress-bar-value|push-button|radio|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbargripper-horizontal|scrollbargripper-vertical|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|searchfield-cancel-button|searchfield-decoration|searchfield-results-button|searchfield-results-decoration|slider-horizontal|slider-vertical|sliderthumb-horizontal|sliderthumb-vertical|square-button|textarea|textfield|-apple-pay-button",
    "-webkit-border-before": "<'border-width'>||<'border-style'>||<color>",
    "-webkit-border-before-color": "<color>",
    "-webkit-border-before-style": "<'border-style'>",
    "-webkit-border-before-width": "<'border-width'>",
    "-webkit-box-reflect": "[above|below|right|left]? <length>? <image>?",
    "-webkit-line-clamp": "none|<integer>",
    "-webkit-mask":
    "[<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||[<box>|border|padding|content|text]||[<box>|border|padding|content]]#",
    "-webkit-mask-attachment": "<attachment>#",
    "-webkit-mask-clip": "[<box>|border|padding|content|text]#",
    "-webkit-mask-composite": "<composite-style>#",
    "-webkit-mask-image": "<mask-reference>#",
    "-webkit-mask-origin": "[<box>|border|padding|content]#",
    "-webkit-mask-position": "<position>#",
    "-webkit-mask-position-x": "[<length-percentage>|left|center|right]#",
    "-webkit-mask-position-y": "[<length-percentage>|top|center|bottom]#",
    "-webkit-mask-repeat": "<repeat-style>#",
    "-webkit-mask-repeat-x": "repeat|no-repeat|space|round",
    "-webkit-mask-repeat-y": "repeat|no-repeat|space|round",
    "-webkit-mask-size": "<bg-size>#",
    "-webkit-overflow-scrolling": "auto|touch",
    "-webkit-tap-highlight-color": "<color>",
    "-webkit-text-fill-color": "<color>",
    "-webkit-text-stroke": "<length>||<color>",
    "-webkit-text-stroke-color": "<color>",
    "-webkit-text-stroke-width": "<length>",
    "-webkit-touch-callout": "default|none",
    "-webkit-user-modify": "read-only|read-write|read-write-plaintext-only",
    "accent-color": "auto|<color>",
    "align-content":
    "normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>",
    "align-items":
    "normal|stretch|<baseline-position>|[<overflow-position>? <self-position>]",
    "align-self":
    "auto|normal|stretch|<baseline-position>|<overflow-position>? <self-position>",
    "align-tracks":
    "[normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>]#",
    all: "initial|inherit|unset|revert|revert-layer",
    "anchor-name": "none|<dashed-ident>#",
    "anchor-scope": "none|all|<dashed-ident>#",
    animation: "<single-animation>#",
    "animation-composition": "<single-animation-composition>#",
    "animation-delay": "<time>#",
    "animation-direction": "<single-animation-direction>#",
    "animation-duration": "<time>#",
    "animation-fill-mode": "<single-animation-fill-mode>#",
    "animation-iteration-count": "<single-animation-iteration-count>#",
    "animation-name": "[none|<keyframes-name>]#",
    "animation-play-state": "<single-animation-play-state>#",
    "animation-range": "[<'animation-range-start'> <'animation-range-end'>?]#",
    "animation-range-end":
    "[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#",
    "animation-range-start":
    "[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#",
    "animation-timing-function": "<easing-function>#",
    "animation-timeline": "<single-animation-timeline>#",
    appearance: "none|auto|textfield|menulist-button|<compat-auto>",
    "aspect-ratio": "auto||<ratio>",
    azimuth:
    "<angle>|[[left-side|far-left|left|center-left|center|center-right|right|far-right|right-side]||behind]|leftwards|rightwards",
    "backdrop-filter": "none|<filter-function-list>",
    "backface-visibility": "visible|hidden",
    background: "[<bg-layer> ,]* <final-bg-layer>",
    "background-attachment": "<attachment>#",
    "background-blend-mode": "<blend-mode>#",
    "background-clip": "<bg-clip>#",
    "background-color": "<color>",
    "background-image": "<bg-image>#",
    "background-origin": "<box>#",
    "background-position": "<bg-position>#",
    "background-position-x":
    "[center|[[left|right|x-start|x-end]? <length-percentage>?]!]#",
    "background-position-y":
    "[center|[[top|bottom|y-start|y-end]? <length-percentage>?]!]#",
    "background-repeat": "<repeat-style>#",
    "background-size": "<bg-size>#",
    "block-size": "<'width'>",
    border: "<line-width>||<line-style>||<color>",
    "border-block": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-color": "<'border-top-color'>{1,2}",
    "border-block-style": "<'border-top-style'>",
    "border-block-width": "<'border-top-width'>",
    "border-block-end": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-end-color": "<'border-top-color'>",
    "border-block-end-style": "<'border-top-style'>",
    "border-block-end-width": "<'border-top-width'>",
    "border-block-start": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-block-start-color": "<'border-top-color'>",
    "border-block-start-style": "<'border-top-style'>",
    "border-block-start-width": "<'border-top-width'>",
    "border-bottom": "<line-width>||<line-style>||<color>",
    "border-bottom-color": "<'border-top-color'>",
    "border-bottom-left-radius": "<length-percentage>{1,2}",
    "border-bottom-right-radius": "<length-percentage>{1,2}",
    "border-bottom-style": "<line-style>",
    "border-bottom-width": "<line-width>",
    "border-collapse": "collapse|separate",
    "border-color": "<color>{1,4}",
    "border-end-end-radius": "<length-percentage>{1,2}",
    "border-end-start-radius": "<length-percentage>{1,2}",
    "border-image":
    "<'border-image-source'>||<'border-image-slice'> [/ <'border-image-width'>|/ <'border-image-width'>? / <'border-image-outset'>]?||<'border-image-repeat'>",
    "border-image-outset": "[<length>|<number>]{1,4}",
    "border-image-repeat": "[stretch|repeat|round|space]{1,2}",
    "border-image-slice": "<number-percentage>{1,4}&&fill?",
    "border-image-source": "none|<image>",
    "border-image-width": "[<length-percentage>|<number>|auto]{1,4}",
    "border-inline": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-end": "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-color": "<'border-top-color'>{1,2}",
    "border-inline-style": "<'border-top-style'>",
    "border-inline-width": "<'border-top-width'>",
    "border-inline-end-color": "<'border-top-color'>",
    "border-inline-end-style": "<'border-top-style'>",
    "border-inline-end-width": "<'border-top-width'>",
    "border-inline-start":
    "<'border-top-width'>||<'border-top-style'>||<color>",
    "border-inline-start-color": "<'border-top-color'>",
    "border-inline-start-style": "<'border-top-style'>",
    "border-inline-start-width": "<'border-top-width'>",
    "border-left": "<line-width>||<line-style>||<color>",
    "border-left-color": "<color>",
    "border-left-style": "<line-style>",
    "border-left-width": "<line-width>",
    "border-radius": "<length-percentage>{1,4} [/ <length-percentage>{1,4}]?",
    "border-right": "<line-width>||<line-style>||<color>",
    "border-right-color": "<color>",
    "border-right-style": "<line-style>",
    "border-right-width": "<line-width>",
    "border-spacing": "<length> <length>?",
    "border-start-end-radius": "<length-percentage>{1,2}",
    "border-start-start-radius": "<length-percentage>{1,2}",
    "border-style": "<line-style>{1,4}",
    "border-top": "<line-width>||<line-style>||<color>",
    "border-top-color": "<color>",
    "border-top-left-radius": "<length-percentage>{1,2}",
    "border-top-right-radius": "<length-percentage>{1,2}",
    "border-top-style": "<line-style>",
    "border-top-width": "<line-width>",
    "border-width": "<line-width>{1,4}",
    bottom: "<length>|<percentage>|auto",
    "box-align": "start|center|end|baseline|stretch",
    "box-decoration-break": "slice|clone",
    "box-direction": "normal|reverse|inherit",
    "box-flex": "<number>",
    "box-flex-group": "<integer>",
    "box-lines": "single|multiple",
    "box-ordinal-group": "<integer>",
    "box-orient": "horizontal|vertical|inline-axis|block-axis|inherit",
    "box-pack": "start|center|end|justify",
    "box-shadow": "none|<shadow>#",
    "box-sizing": "content-box|border-box",
    "break-after":
    "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
    "break-before":
    "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
    "break-inside": "auto|avoid|avoid-page|avoid-column|avoid-region",
    "caption-side": "top|bottom|block-start|block-end|inline-start|inline-end",
    caret: "<'caret-color'>||<'caret-shape'>",
    "caret-color": "auto|<color>",
    "caret-shape": "auto|bar|block|underscore",
    clear: "none|left|right|both|inline-start|inline-end",
    clip: "<shape>|auto",
    "clip-path": "<clip-source>|[<basic-shape>||<geometry-box>]|none",
    "clip-rule": "nonzero|evenodd",
    color: "<color>",
    "color-interpolation-filters": "auto|sRGB|linearRGB",
    "color-scheme": "normal|[light|dark|<custom-ident>]+&&only?",
    "column-count": "<integer>|auto",
    "column-fill": "auto|balance",
    "column-gap": "normal|<length-percentage>",
    "column-rule":
    "<'column-rule-width'>||<'column-rule-style'>||<'column-rule-color'>",
    "column-rule-color": "<color>",
    "column-rule-style": "<'border-style'>",
    "column-rule-width": "<'border-width'>",
    "column-span": "none|all",
    "column-width": "<length>|auto",
    columns: "<'column-width'>||<'column-count'>",
    contain: "none|strict|content|[[size||inline-size]||layout||style||paint]",
    "contain-intrinsic-size": "[auto? [none|<length>]]{1,2}",
    "contain-intrinsic-block-size": "auto? [none|<length>]",
    "contain-intrinsic-height": "auto? [none|<length>]",
    "contain-intrinsic-inline-size": "auto? [none|<length>]",
    "contain-intrinsic-width": "auto? [none|<length>]",
    container: "<'container-name'> [/ <'container-type'>]?",
    "container-name": "none|<custom-ident>+",
    "container-type": "normal||[size|inline-size]",
    content:
    "normal|none|[<content-replacement>|<content-list>] [/ [<string>|<counter>]+]?",
    "content-visibility": "visible|auto|hidden",
    "counter-increment": "[<counter-name> <integer>?]+|none",
    "counter-reset":
    "[<counter-name> <integer>?|<reversed-counter-name> <integer>?]+|none",
    "counter-set": "[<counter-name> <integer>?]+|none",
    cursor:
    "[[<url> [<x> <y>]? ,]* [auto|default|none|context-menu|help|pointer|progress|wait|cell|crosshair|text|vertical-text|alias|copy|move|no-drop|not-allowed|e-resize|n-resize|ne-resize|nw-resize|s-resize|se-resize|sw-resize|w-resize|ew-resize|ns-resize|nesw-resize|nwse-resize|col-resize|row-resize|all-scroll|zoom-in|zoom-out|grab|grabbing|hand|-webkit-grab|-webkit-grabbing|-webkit-zoom-in|-webkit-zoom-out|-moz-grab|-moz-grabbing|-moz-zoom-in|-moz-zoom-out]]",
    d: "none|path( <string> )",
    cx: "<length>|<percentage>",
    cy: "<length>|<percentage>",
    direction: "ltr|rtl",
    display:
    "[<display-outside>||<display-inside>]|<display-listitem>|<display-internal>|<display-box>|<display-legacy>|<-non-standard-display>",
    "dominant-baseline":
    "auto|use-script|no-change|reset-size|ideographic|alphabetic|hanging|mathematical|central|middle|text-after-edge|text-before-edge",
    "empty-cells": "show|hide",
    "field-sizing": "content|fixed",
    fill: "<paint>",
    "fill-opacity": "<number-zero-one>",
    "fill-rule": "nonzero|evenodd",
    filter: "none|<filter-function-list>|<-ms-filter-function-list>",
    flex: "none|[<'flex-grow'> <'flex-shrink'>?||<'flex-basis'>]",
    "flex-basis": "content|<'width'>",
    "flex-direction": "row|row-reverse|column|column-reverse",
    "flex-flow": "<'flex-direction'>||<'flex-wrap'>",
    "flex-grow": "<number>",
    "flex-shrink": "<number>",
    "flex-wrap": "nowrap|wrap|wrap-reverse",
    float: "left|right|none|inline-start|inline-end",
    font: "[[<'font-style'>||<font-variant-css2>||<'font-weight'>||<font-width-css3>]? <'font-size'> [/ <'line-height'>]? <'font-family'>#]|<system-family-name>|<-non-standard-font>",
    "font-family": "[<family-name>|<generic-family>]#",
    "font-feature-settings": "normal|<feature-tag-value>#",
    "font-kerning": "auto|normal|none",
    "font-language-override": "normal|<string>",
    "font-optical-sizing": "auto|none",
    "font-palette": "normal|light|dark|<palette-identifier>",
    "font-variation-settings": "normal|[<string> <number>]#",
    "font-size": "<absolute-size>|<relative-size>|<length-percentage>",
    "font-size-adjust":
    "none|[ex-height|cap-height|ch-width|ic-width|ic-height]? [from-font|<number>]",
    "font-smooth": "auto|never|always|<absolute-size>|<length>",
    "font-stretch": "<font-stretch-absolute>",
    "font-style": "normal|italic|oblique <angle>?",
    "font-synthesis": "none|[weight||style||small-caps||position]",
    "font-synthesis-position": "auto|none",
    "font-synthesis-small-caps": "auto|none",
    "font-synthesis-style": "auto|none",
    "font-synthesis-weight": "auto|none",
    "font-variant":
    "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>||stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )||[small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps]||<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero||<east-asian-variant-values>||<east-asian-width-values>||ruby]",
    "font-variant-alternates":
    "normal|[stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )]",
    "font-variant-caps":
    "normal|small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps",
    "font-variant-east-asian":
    "normal|[<east-asian-variant-values>||<east-asian-width-values>||ruby]",
    "font-variant-emoji": "normal|text|emoji|unicode",
    "font-variant-ligatures":
    "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>]",
    "font-variant-numeric":
    "normal|[<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero]",
    "font-variant-position": "normal|sub|super",
    "font-weight": "<font-weight-absolute>|bolder|lighter",
    "forced-color-adjust": "auto|none|preserve-parent-color",
    gap: "<'row-gap'> <'column-gap'>?",
    grid: "<'grid-template'>|<'grid-template-rows'> / [auto-flow&&dense?] <'grid-auto-columns'>?|[auto-flow&&dense?] <'grid-auto-rows'>? / <'grid-template-columns'>",
    "grid-area": "<grid-line> [/ <grid-line>]{0,3}",
    "grid-auto-columns": "<track-size>+",
    "grid-auto-flow": "[row|column]||dense",
    "grid-auto-rows": "<track-size>+",
    "grid-column": "<grid-line> [/ <grid-line>]?",
    "grid-column-end": "<grid-line>",
    "grid-column-gap": "<length-percentage>",
    "grid-column-start": "<grid-line>",
    "grid-gap": "<'grid-row-gap'> <'grid-column-gap'>?",
    "grid-row": "<grid-line> [/ <grid-line>]?",
    "grid-row-end": "<grid-line>",
    "grid-row-gap": "<length-percentage>",
    "grid-row-start": "<grid-line>",
    "grid-template":
    "none|[<'grid-template-rows'> / <'grid-template-columns'>]|[<line-names>? <string> <track-size>? <line-names>?]+ [/ <explicit-track-list>]?",
    "grid-template-areas": "none|<string>+",
    "grid-template-columns":
    "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
    "grid-template-rows":
    "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
    "hanging-punctuation": "none|[first||[force-end|allow-end]||last]",
    height:
    "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "hyphenate-character": "auto|<string>",
    "hyphenate-limit-chars": "[auto|<integer>]{1,3}",
    hyphens: "none|manual|auto",
    "image-orientation": "from-image|<angle>|[<angle>? flip]",
    "image-rendering":
    "auto|crisp-edges|pixelated|optimizeSpeed|optimizeQuality|<-non-standard-image-rendering>",
    "image-resolution": "[from-image||<resolution>]&&snap?",
    "ime-mode": "auto|normal|active|inactive|disabled",
    "initial-letter": "normal|[<number> <integer>?]",
    "initial-letter-align": "[auto|alphabetic|hanging|ideographic]",
    "inline-size": "<'width'>",
    "input-security": "auto|none",
    inset: "<'top'>{1,4}",
    "inset-block": "<'top'>{1,2}",
    "inset-block-end": "<'top'>",
    "inset-block-start": "<'top'>",
    "inset-inline": "<'top'>{1,2}",
    "inset-inline-end": "<'top'>",
    "inset-inline-start": "<'top'>",
    "interpolate-size": "numeric-only|allow-keywords",
    isolation: "auto|isolate",
    "justify-content":
    "normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]",
    "justify-items":
    "normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]|legacy|legacy&&[left|right|center]",
    "justify-self":
    "auto|normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]",
    "justify-tracks":
    "[normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]]#",
    left: "<length>|<percentage>|auto",
    "letter-spacing": "normal|<length-percentage>",
    "line-break": "auto|loose|normal|strict|anywhere",
    "line-clamp": "none|<integer>",
    "line-height": "normal|<number>|<length>|<percentage>",
    "line-height-step": "<length>",
    "list-style":
    "<'list-style-type'>||<'list-style-position'>||<'list-style-image'>",
    "list-style-image": "<image>|none",
    "list-style-position": "inside|outside",
    "list-style-type": "<counter-style>|<string>|none",
    margin: "[<length>|<percentage>|auto]{1,4}",
    "margin-block": "<'margin-left'>{1,2}",
    "margin-block-end": "<'margin-left'>",
    "margin-block-start": "<'margin-left'>",
    "margin-bottom": "<length>|<percentage>|auto",
    "margin-inline": "<'margin-left'>{1,2}",
    "margin-inline-end": "<'margin-left'>",
    "margin-inline-start": "<'margin-left'>",
    "margin-left": "<length>|<percentage>|auto",
    "margin-right": "<length>|<percentage>|auto",
    "margin-top": "<length>|<percentage>|auto",
    "margin-trim": "none|in-flow|all",
    marker: "none|<url>",
    "marker-end": "none|<url>",
    "marker-mid": "none|<url>",
    "marker-start": "none|<url>",
    mask: "<mask-layer>#",
    "mask-border":
    "<'mask-border-source'>||<'mask-border-slice'> [/ <'mask-border-width'>? [/ <'mask-border-outset'>]?]?||<'mask-border-repeat'>||<'mask-border-mode'>",
    "mask-border-mode": "luminance|alpha",
    "mask-border-outset": "[<length>|<number>]{1,4}",
    "mask-border-repeat": "[stretch|repeat|round|space]{1,2}",
    "mask-border-slice": "<number-percentage>{1,4} fill?",
    "mask-border-source": "none|<image>",
    "mask-border-width": "[<length-percentage>|<number>|auto]{1,4}",
    "mask-clip": "[<geometry-box>|no-clip]#",
    "mask-composite": "<compositing-operator>#",
    "mask-image": "<mask-reference>#",
    "mask-mode": "<masking-mode>#",
    "mask-origin": "<geometry-box>#",
    "mask-position": "<position>#",
    "mask-repeat": "<repeat-style>#",
    "mask-size": "<bg-size>#",
    "mask-type": "luminance|alpha",
    "masonry-auto-flow": "[pack|next]||[definite-first|ordered]",
    "math-depth": "auto-add|add( <integer> )|<integer>",
    "math-shift": "normal|compact",
    "math-style": "normal|compact",
    "max-block-size": "<'max-width'>",
    "max-height":
    "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "max-inline-size": "<'max-width'>",
    "max-lines": "none|<integer>",
    "max-width":
    "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "min-block-size": "<'min-width'>",
    "min-height":
    "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "min-inline-size": "<'min-width'>",
    "min-width":
    "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "mix-blend-mode": "<blend-mode>|plus-lighter",
    "object-fit": "fill|contain|cover|none|scale-down",
    "object-position": "<position>",
    offset:
    "[<'offset-position'>? [<'offset-path'> [<'offset-distance'>||<'offset-rotate'>]?]?]! [/ <'offset-anchor'>]?",
    "offset-anchor": "auto|<position>",
    "offset-distance": "<length-percentage>",
    "offset-path": "none|<offset-path>||<coord-box>",
    "offset-position": "normal|auto|<position>",
    "offset-rotate": "[auto|reverse]||<angle>",
    opacity: "<alpha-value>",
    order: "<integer>",
    orphans: "<integer>",
    outline: "[<'outline-width'>||<'outline-style'>||<'outline-color'>]",
    "outline-color": "auto|<color>",
    "outline-offset": "<length>",
    "outline-style": "auto|<'border-style'>",
    "outline-width": "<line-width>",
    overflow: "[visible|hidden|clip|scroll|auto]{1,2}|<-non-standard-overflow>",
    "overflow-anchor": "auto|none",
    "overflow-block": "visible|hidden|clip|scroll|auto",
    "overflow-clip-box": "padding-box|content-box",
    "overflow-clip-margin": "<visual-box>||<length [0,∞]>",
    "overflow-inline": "visible|hidden|clip|scroll|auto",
    "overflow-wrap": "normal|break-word|anywhere",
    "overflow-x": "visible|hidden|clip|scroll|auto",
    "overflow-y": "visible|hidden|clip|scroll|auto",
    overlay: "none|auto",
    "overscroll-behavior": "[contain|none|auto]{1,2}",
    "overscroll-behavior-block": "contain|none|auto",
    "overscroll-behavior-inline": "contain|none|auto",
    "overscroll-behavior-x": "contain|none|auto",
    "overscroll-behavior-y": "contain|none|auto",
    padding: "[<length>|<percentage>]{1,4}",
    "padding-block": "<'padding-left'>{1,2}",
    "padding-block-end": "<'padding-left'>",
    "padding-block-start": "<'padding-left'>",
    "padding-bottom": "<length>|<percentage>",
    "padding-inline": "<'padding-left'>{1,2}",
    "padding-inline-end": "<'padding-left'>",
    "padding-inline-start": "<'padding-left'>",
    "padding-left": "<length>|<percentage>",
    "padding-right": "<length>|<percentage>",
    "padding-top": "<length>|<percentage>",
    page: "auto|<custom-ident>",
    "page-break-after": "auto|always|avoid|left|right|recto|verso",
    "page-break-before": "auto|always|avoid|left|right|recto|verso",
    "page-break-inside": "auto|avoid",
    "paint-order": "normal|[fill||stroke||markers]",
    perspective: "none|<length>",
    "perspective-origin": "<position>",
    "place-content": "<'align-content'> <'justify-content'>?",
    "place-items": "<'align-items'> <'justify-items'>?",
    "place-self": "<'align-self'> <'justify-self'>?",
    "pointer-events":
    "auto|none|visiblePainted|visibleFill|visibleStroke|visible|painted|fill|stroke|all|inherit",
    position: "static|relative|absolute|sticky|fixed|-webkit-sticky",
    "position-anchor": "auto|<anchor-name>",
    "position-area": "none|<position-area>",
    "position-try": "<'position-try-order'>? <'position-try-fallbacks'>",
    "position-try-fallbacks":
    "none|[[<dashed-ident>||<try-tactic>]|<'position-area'>]#",
    "position-try-order": "normal|<try-size>",
    "position-visibility":
    "always|[anchors-valid||anchors-visible||no-overflow]",
    "print-color-adjust": "economy|exact",
    quotes: "none|auto|[<string> <string>]+",
    r: "<length>|<percentage>",
    resize: "none|both|horizontal|vertical|block|inline",
    right: "<length>|<percentage>|auto",
    rotate: "none|<angle>|[x|y|z|<number>{3}]&&<angle>",
    "row-gap": "normal|<length-percentage>",
    "ruby-align": "start|center|space-between|space-around",
    "ruby-merge": "separate|collapse|auto",
    "ruby-position": "[alternate||[over|under]]|inter-character",
    rx: "<length>|<percentage>",
    ry: "<length>|<percentage>",
    scale: "none|[<number>|<percentage>]{1,3}",
    "scrollbar-color": "auto|<color>{2}",
    "scrollbar-gutter": "auto|stable&&both-edges?",
    "scrollbar-width": "auto|thin|none",
    "scroll-behavior": "auto|smooth",
    "scroll-margin": "<length>{1,4}",
    "scroll-margin-block": "<length>{1,2}",
    "scroll-margin-block-start": "<length>",
    "scroll-margin-block-end": "<length>",
    "scroll-margin-bottom": "<length>",
    "scroll-margin-inline": "<length>{1,2}",
    "scroll-margin-inline-start": "<length>",
    "scroll-margin-inline-end": "<length>",
    "scroll-margin-left": "<length>",
    "scroll-margin-right": "<length>",
    "scroll-margin-top": "<length>",
    "scroll-padding": "[auto|<length-percentage>]{1,4}",
    "scroll-padding-block": "[auto|<length-percentage>]{1,2}",
    "scroll-padding-block-start": "auto|<length-percentage>",
    "scroll-padding-block-end": "auto|<length-percentage>",
    "scroll-padding-bottom": "auto|<length-percentage>",
    "scroll-padding-inline": "[auto|<length-percentage>]{1,2}",
    "scroll-padding-inline-start": "auto|<length-percentage>",
    "scroll-padding-inline-end": "auto|<length-percentage>",
    "scroll-padding-left": "auto|<length-percentage>",
    "scroll-padding-right": "auto|<length-percentage>",
    "scroll-padding-top": "auto|<length-percentage>",
    "scroll-snap-align": "[none|start|end|center]{1,2}",
    "scroll-snap-coordinate": "none|<position>#",
    "scroll-snap-destination": "<position>",
    "scroll-snap-points-x": "none|repeat( <length-percentage> )",
    "scroll-snap-points-y": "none|repeat( <length-percentage> )",
    "scroll-snap-stop": "normal|always",
    "scroll-snap-type": "none|[x|y|block|inline|both] [mandatory|proximity]?",
    "scroll-snap-type-x": "none|mandatory|proximity",
    "scroll-snap-type-y": "none|mandatory|proximity",
    "scroll-timeline": "[<'scroll-timeline-name'>||<'scroll-timeline-axis'>]#",
    "scroll-timeline-axis": "[block|inline|x|y]#",
    "scroll-timeline-name": "[none|<dashed-ident>]#",
    "shape-image-threshold": "<alpha-value>",
    "shape-margin": "<length-percentage>",
    "shape-outside": "none|[<shape-box>||<basic-shape>]|<image>",
    "shape-rendering": "auto|optimizeSpeed|crispEdges|geometricPrecision",
    stroke: "<paint>",
    "stroke-dasharray": "none|[<svg-length>+]#",
    "stroke-dashoffset": "<svg-length>",
    "stroke-linecap": "butt|round|square",
    "stroke-linejoin": "miter|round|bevel",
    "stroke-miterlimit": "<number-one-or-greater>",
    "stroke-opacity": "<'opacity'>",
    "stroke-width": "<svg-length>",
    "tab-size": "<integer>|<length>",
    "table-layout": "auto|fixed",
    "text-align": "start|end|left|right|center|justify|match-parent",
    "text-align-last": "auto|start|end|left|right|center|justify",
    "text-anchor": "start|middle|end",
    "text-combine-upright": "none|all|[digits <integer>?]",
    "text-decoration":
    "<'text-decoration-line'>||<'text-decoration-style'>||<'text-decoration-color'>||<'text-decoration-thickness'>",
    "text-decoration-color": "<color>",
    "text-decoration-line":
    "none|[underline||overline||line-through||blink]|spelling-error|grammar-error",
    "text-decoration-skip":
    "none|[objects||[spaces|[leading-spaces||trailing-spaces]]||edges||box-decoration]",
    "text-decoration-skip-ink": "auto|all|none",
    "text-decoration-style": "solid|double|dotted|dashed|wavy",
    "text-decoration-thickness": "auto|from-font|<length>|<percentage>",
    "text-emphasis": "<'text-emphasis-style'>||<'text-emphasis-color'>",
    "text-emphasis-color": "<color>",
    "text-emphasis-position": "auto|[over|under]&&[right|left]?",
    "text-emphasis-style":
    "none|[[filled|open]||[dot|circle|double-circle|triangle|sesame]]|<string>",
    "text-indent": "<length-percentage>&&hanging?&&each-line?",
    "text-justify": "auto|inter-character|inter-word|none",
    "text-orientation": "mixed|upright|sideways",
    "text-overflow": "[clip|ellipsis|<string>]{1,2}",
    "text-rendering":
    "auto|optimizeSpeed|optimizeLegibility|geometricPrecision",
    "text-shadow": "none|<shadow-t>#",
    "text-size-adjust": "none|auto|<percentage>",
    "text-spacing-trim":
    "space-all|normal|space-first|trim-start|trim-both|trim-all|auto",
    "text-transform":
    "none|capitalize|uppercase|lowercase|full-width|full-size-kana",
    "text-underline-offset": "auto|<length>|<percentage>",
    "text-underline-position": "auto|from-font|[under||[left|right]]",
    "text-wrap": "<'text-wrap-mode'>||<'text-wrap-style'>",
    "text-wrap-mode": "auto|wrap|nowrap",
    "text-wrap-style": "auto|balance|stable|pretty",
    "timeline-scope": "none|<dashed-ident>#",
    top: "<length>|<percentage>|auto",
    "touch-action":
    "auto|none|[[pan-x|pan-left|pan-right]||[pan-y|pan-up|pan-down]||pinch-zoom]|manipulation",
    transform: "none|<transform-list>",
    "transform-box": "content-box|border-box|fill-box|stroke-box|view-box",
    "transform-origin":
    "[<length-percentage>|left|center|right|top|bottom]|[[<length-percentage>|left|center|right]&&[<length-percentage>|top|center|bottom]] <length>?",
    "transform-style": "flat|preserve-3d",
    transition: "<single-transition>#",
    "transition-behavior": "<transition-behavior-value>#",
    "transition-delay": "<time>#",
    "transition-duration": "<time>#",
    "transition-property": "none|<single-transition-property>#",
    "transition-timing-function": "<easing-function>#",
    translate: "none|<length-percentage> [<length-percentage> <length>?]?",
    "unicode-bidi":
    "normal|embed|isolate|bidi-override|isolate-override|plaintext|-moz-isolate|-moz-isolate-override|-moz-plaintext|-webkit-isolate|-webkit-isolate-override|-webkit-plaintext",
    "user-select": "auto|text|none|contain|all",
    "vector-effect":
    "none|non-scaling-stroke|non-scaling-size|non-rotation|fixed-position",
    "vertical-align":
    "baseline|sub|super|text-top|text-bottom|middle|top|bottom|<percentage>|<length>",
    "view-timeline": "[<'view-timeline-name'> <'view-timeline-axis'>?]#",
    "view-timeline-axis": "[block|inline|x|y]#",
    "view-timeline-inset": "[[auto|<length-percentage>]{1,2}]#",
    "view-timeline-name": "none|<dashed-ident>#",
    "view-transition-name": "none|<custom-ident>",
    visibility: "visible|hidden|collapse",
    "white-space":
    "normal|pre|nowrap|pre-wrap|pre-line|break-spaces|[<'white-space-collapse'>||<'text-wrap'>||<'white-space-trim'>]",
    "white-space-collapse":
    "collapse|discard|preserve|preserve-breaks|preserve-spaces|break-spaces",
    widows: "<integer>",
    width:
    "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
    "will-change": "auto|<animateable-feature>#",
    "word-break": "normal|break-all|keep-all|break-word|auto-phrase",
    "word-spacing": "normal|<length>",
    "word-wrap": "normal|break-word",
    "writing-mode":
    "horizontal-tb|vertical-rl|vertical-lr|sideways-rl|sideways-lr|<svg-writing-mode>",
    x: "<length>|<percentage>",
    y: "<length>|<percentage>",
    "z-index": "auto|<integer>",
    zoom: "normal|reset|<number>|<percentage>",
    "-moz-background-clip": "padding|border",
    "-moz-border-radius-bottomleft": "<'border-bottom-left-radius'>",
    "-moz-border-radius-bottomright": "<'border-bottom-right-radius'>",
    "-moz-border-radius-topleft": "<'border-top-left-radius'>",
    "-moz-border-radius-topright": "<'border-bottom-right-radius'>",
    "-moz-control-character-visibility": "visible|hidden",
    "-moz-osx-font-smoothing": "auto|grayscale",
    "-moz-user-select": "none|text|all|-moz-none",
    "-ms-flex-align": "start|end|center|baseline|stretch",
    "-ms-flex-item-align": "auto|start|end|center|baseline|stretch",
    "-ms-flex-line-pack": "start|end|center|justify|distribute|stretch",
    "-ms-flex-negative": "<'flex-shrink'>",
    "-ms-flex-pack": "start|end|center|justify|distribute",
    "-ms-flex-order": "<integer>",
    "-ms-flex-positive": "<'flex-grow'>",
    "-ms-flex-preferred-size": "<'flex-basis'>",
    "-ms-interpolation-mode": "nearest-neighbor|bicubic",
    "-ms-grid-column-align": "start|end|center|stretch",
    "-ms-grid-row-align": "start|end|center|stretch",
    "-ms-hyphenate-limit-last": "none|always|column|page|spread",
    "-webkit-background-clip": "[<box>|border|padding|content|text]#",
    "-webkit-column-break-after": "always|auto|avoid",
    "-webkit-column-break-before": "always|auto|avoid",
    "-webkit-column-break-inside": "always|auto|avoid",
    "-webkit-font-smoothing": "auto|none|antialiased|subpixel-antialiased",
    "-webkit-mask-box-image":
    "[<url>|<gradient>|none] [<length-percentage>{4} <-webkit-mask-box-repeat>{2}]?",
    "-webkit-print-color-adjust": "economy|exact",
    "-webkit-text-security": "none|circle|disc|square",
    "-webkit-user-drag": "none|element|auto",
    "-webkit-user-select": "auto|none|text|all",
    "alignment-baseline":
    "auto|baseline|before-edge|text-before-edge|middle|central|after-edge|text-after-edge|ideographic|alphabetic|hanging|mathematical",
    "baseline-shift": "baseline|sub|super|<svg-length>",
    behavior: "<url>+",
    cue: "<'cue-before'> <'cue-after'>?",
    "cue-after": "<url> <decibel>?|none",
    "cue-before": "<url> <decibel>?|none",
    "glyph-orientation-horizontal": "<angle>",
    "glyph-orientation-vertical": "<angle>",
    kerning: "auto|<svg-length>",
    pause: "<'pause-before'> <'pause-after'>?",
    "pause-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "pause-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
    rest: "<'rest-before'> <'rest-after'>?",
    "rest-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
    "rest-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
    src: "[<url> [format( <string># )]?|local( <family-name> )]#",
    speak: "auto|never|always",
    "speak-as":
    "normal|spell-out||digits||[literal-punctuation|no-punctuation]",
    "unicode-range": "<urange>#",
    "voice-balance": "<number>|left|center|right|leftwards|rightwards",
    "voice-duration": "auto|<time>",
    "voice-family":
    "[[<family-name>|<generic-voice>] ,]* [<family-name>|<generic-voice>]|preserve",
    "voice-pitch":
    "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
    "voice-range":
    "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
    "voice-rate": "[normal|x-slow|slow|medium|fast|x-fast]||<percentage>",
    "voice-stress": "normal|strong|moderate|none|reduced",
    "voice-volume": "silent|[[x-soft|soft|medium|loud|x-loud]||<decibel>]",
    "white-space-trim": "none|discard-before||discard-after||discard-inner"
  },
  atrules: {
    charset: { prelude: "<string>", descriptors: null },
    "counter-style": {
      prelude: "<counter-style-name>",
      descriptors: {
        "additive-symbols": "[<integer>&&<symbol>]#",
        fallback: "<counter-style-name>",
        negative: "<symbol> <symbol>?",
        pad: "<integer>&&<symbol>",
        prefix: "<symbol>",
        range: "[[<integer>|infinite]{2}]#|auto",
        "speak-as": "auto|bullets|numbers|words|spell-out|<counter-style-name>",
        suffix: "<symbol>",
        symbols: "<symbol>+",
        system:
        "cyclic|numeric|alphabetic|symbolic|additive|[fixed <integer>?]|[extends <counter-style-name>]"
      }
    },
    document: {
      prelude:
      "[<url>|url-prefix( <string> )|domain( <string> )|media-document( <string> )|regexp( <string> )]#",
      descriptors: null
    },
    "font-palette-values": {
      prelude: "<dashed-ident>",
      descriptors: {
        "base-palette": "light|dark|<integer [0,∞]>",
        "font-family": "<family-name>#",
        "override-colors": "[<integer [0,∞]> <absolute-color-base>]#"
      }
    },
    "font-face": {
      prelude: null,
      descriptors: {
        "ascent-override": "normal|<percentage>",
        "descent-override": "normal|<percentage>",
        "font-display": "[auto|block|swap|fallback|optional]",
        "font-family": "<family-name>",
        "font-feature-settings": "normal|<feature-tag-value>#",
        "font-variation-settings": "normal|[<string> <number>]#",
        "font-stretch": "<font-stretch-absolute>{1,2}",
        "font-style": "normal|italic|oblique <angle>{0,2}",
        "font-weight": "<font-weight-absolute>{1,2}",
        "line-gap-override": "normal|<percentage>",
        "size-adjust": "<percentage>",
        src: "[<url> [format( <string># )]?|local( <family-name> )]#",
        "unicode-range": "<urange>#"
      }
    },
    "font-feature-values": { prelude: "<family-name>#", descriptors: null },
    import: {
      prelude:
      "[<string>|<url>] [layer|layer( <layer-name> )]? [supports( [<supports-condition>|<declaration>] )]? <media-query-list>?",
      descriptors: null
    },
    keyframes: { prelude: "<keyframes-name>", descriptors: null },
    layer: { prelude: "[<layer-name>#|<layer-name>?]", descriptors: null },
    media: { prelude: "<media-query-list>", descriptors: null },
    namespace: {
      prelude: "<namespace-prefix>? [<string>|<url>]",
      descriptors: null
    },
    page: {
      prelude: "<page-selector-list>",
      descriptors: {
        bleed: "auto|<length>",
        marks: "none|[crop||cross]",
        "page-orientation": "upright|rotate-left|rotate-right",
        size: "<length>{1,2}|auto|[<page-size>||[portrait|landscape]]"
      }
    },
    "position-try": {
      prelude: "<dashed-ident>",
      descriptors: {
        top: "<'top'>",
        left: "<'left'>",
        bottom: "<'bottom'>",
        right: "<'right'>",
        "inset-block-start": "<'inset-block-start'>",
        "inset-block-end": "<'inset-block-end'>",
        "inset-inline-start": "<'inset-inline-start'>",
        "inset-inline-end": "<'inset-inline-end'>",
        "inset-block": "<'inset-block'>",
        "inset-inline": "<'inset-inline'>",
        inset: "<'inset'>",
        "margin-top": "<'margin-top'>",
        "margin-left": "<'margin-left'>",
        "margin-bottom": "<'margin-bottom'>",
        "margin-right": "<'margin-right'>",
        "margin-block-start": "<'margin-block-start'>",
        "margin-block-end": "<'margin-block-end'>",
        "margin-inline-start": "<'margin-inline-start'>",
        "margin-inline-end": "<'margin-inline-end'>",
        margin: "<'margin'>",
        "margin-block": "<'margin-block'>",
        "margin-inline": "<'margin-inline'>",
        width: "<'width'>",
        height: "<'height'>",
        "min-width": "<'min-width'>",
        "min-height": "<'min-height'>",
        "max-width": "<'max-width'>",
        "max-height": "<'max-height'>",
        "block-size": "<'block-size'>",
        "inline-size": "<'inline-size'>",
        "min-block-size": "<'min-block-size'>",
        "min-inline-size": "<'min-inline-size'>",
        "max-block-size": "<'max-block-size'>",
        "max-inline-size": "<'max-inline-size'>",
        "align-self": "<'align-self'>|anchor-center",
        "justify-self": "<'justify-self'>|anchor-center"
      }
    },
    property: {
      prelude: "<custom-property-name>",
      descriptors: {
        syntax: "<string>",
        inherits: "true|false",
        "initial-value": "<declaration-value>?"
      }
    },
    scope: {
      prelude: "[( <scope-start> )]? [to ( <scope-end> )]?",
      descriptors: null
    },
    "starting-style": { prelude: null, descriptors: null },
    supports: { prelude: "<supports-condition>", descriptors: null },
    container: {
      prelude: "[<container-name>]? <container-condition>",
      descriptors: null
    },
    nest: { prelude: "<complex-selector-list>", descriptors: null }
  }
};
var Nn = {};
I(Nn, {
  WhiteSpace: () => Pu,
  Value: () => Uu,
  Url: () => Iu,
  UnicodeRange: () => Du,
  TypeSelector: () => au,
  SupportsDeclaration: () => fu,
  StyleSheet: () => $u,
  String: () => vu,
  SelectorList: () => gu,
  Selector: () => cu,
  Scope: () => eu,
  Rule: () => iu,
  Raw: () => tu,
  Ratio: () => sc,
  PseudoElementSelector: () => Tc,
  PseudoClassSelector: () => Zc,
  Percentage: () => Rc,
  Parentheses: () => Ac,
  Operator: () => Bc,
  Number: () => Gc,
  Nth: () => Fc,
  NestingSelector: () => Ec,
  MediaQueryList: () => Vc,
  MediaQuery: () => Kc,
  LayerList: () => qc,
  Layer: () => Pc,
  Identifier: () => Ic,
  IdSelector: () => Uc,
  Hash: () => jc,
  GeneralEnclosed: () => _c,
  Function: () => ac,
  FeatureRange: () => wc,
  FeatureFunction: () => $c,
  Feature: () => vc,
  Dimension: () => mc,
  DeclarationList: () => uc,
  Declaration: () => ec,
  Condition: () => ic,
  Comment: () => tc,
  Combinator: () => sl,
  ClassSelector: () => Tl,
  CDO: () => Zl,
  CDC: () => Rl,
  Brackets: () => Al,
  Block: () => Bl,
  AttributeSelector: () => Gl,
  AtrulePrelude: () => Ql,
  Atrule: () => Yl,
  AnPlusB: () => Ll
});
var Ll = {};
I(Ll, {
  structure: () => E1,
  parse: () => Kl,
  name: () => Y1,
  generate: () => Q1
});
var Mr = 43,
  Xr = 45,
  go = 110,
  Ut = !0,
  V1 = !1;
function mo(r, t) {
  let i = this.tokenStart + r,
    o = this.charCodeAt(i);
  if (o === Mr || o === Xr) {
    if (t) this.error("Number sign is not allowed");
    i++;
  }
  for (; i < this.tokenEnd; i++)
  if (!cr(this.charCodeAt(i))) this.error("Integer is expected", i);
}
function st(r) {
  return mo.call(this, 0, r);
}
function xt(r, t) {
  if (!this.cmpChar(this.tokenStart + r, t)) {
    let i = "";
    switch (t) {
      case go:
        i = "N is expected";
        break;
      case Xr:
        i = "HyphenMinus is expected";
        break;
    }
    this.error(i, this.tokenStart + r);
  }
}
function Wl() {
  let r = 0,
    t = 0,
    i = this.tokenType;
  while (i === Y || i === A) i = this.lookupType(++r);
  if (i !== U)
  if (this.isDelim(Mr, r) || this.isDelim(Xr, r)) {
    t = this.isDelim(Mr, r) ? Mr : Xr;
    do i = this.lookupType(++r); while (
    i === Y || i === A);
    if (i !== U) this.skip(r), st.call(this, Ut);
  } else return null;
  if (r > 0) this.skip(r);
  if (t === 0) {
    if (i = this.charCodeAt(this.tokenStart), i !== Mr && i !== Xr)
    this.error("Number sign is expected");
  }
  return (
    st.call(this, t !== 0),
    t === Xr ? "-" + this.consume(U) : this.consume(U));

}
var Y1 = "AnPlusB",
  E1 = { a: [String, null], b: [String, null] };
function Kl() {
  let r = this.tokenStart,
    t = null,
    i = null;
  if (this.tokenType === U) st.call(this, V1), i = this.consume(U);else
  if (this.tokenType === w && this.cmpChar(this.tokenStart, Xr))
  switch (
  t = "-1", xt.call(this, 1, go), this.tokenEnd - this.tokenStart) {

    case 2:
      this.next(), i = Wl.call(this);
      break;
    case 3:
      xt.call(this, 2, Xr),
      this.next(),
      this.skipSC(),
      st.call(this, Ut),
      i = "-" + this.consume(U);
      break;
    default:
      xt.call(this, 2, Xr),
      mo.call(this, 3, Ut),
      this.next(),
      i = this.substrToCursor(r + 2);
  } else
  if (
  this.tokenType === w ||
  this.isDelim(Mr) && this.lookupType(1) === w)
  {
    let o = 0;
    if (t = "1", this.isDelim(Mr)) o = 1, this.next();
    switch (xt.call(this, 0, go), this.tokenEnd - this.tokenStart) {
      case 1:
        this.next(), i = Wl.call(this);
        break;
      case 2:
        xt.call(this, 1, Xr),
        this.next(),
        this.skipSC(),
        st.call(this, Ut),
        i = "-" + this.consume(U);
        break;
      default:
        xt.call(this, 1, Xr),
        mo.call(this, 2, Ut),
        this.next(),
        i = this.substrToCursor(r + o + 1);
    }
  } else if (this.tokenType === q) {
    let o = this.charCodeAt(this.tokenStart),
      n = o === Mr || o === Xr,
      e = this.tokenStart + n;
    for (; e < this.tokenEnd; e++) if (!cr(this.charCodeAt(e))) break;
    if (e === this.tokenStart + n)
    this.error("Integer is expected", this.tokenStart + n);
    if (
    xt.call(this, e - this.tokenStart, go),
    t = this.substring(r, e),
    e + 1 === this.tokenEnd)

    this.next(), i = Wl.call(this);else
    if (
    xt.call(this, e - this.tokenStart + 1, Xr), e + 2 === this.tokenEnd)

    this.next(),
    this.skipSC(),
    st.call(this, Ut),
    i = "-" + this.consume(U);else

    mo.call(this, e - this.tokenStart + 2, Ut),
    this.next(),
    i = this.substrToCursor(e + 1);
  } else this.error();
  if (t !== null && t.charCodeAt(0) === Mr) t = t.substr(1);
  if (i !== null && i.charCodeAt(0) === Mr) i = i.substr(1);
  return {
    type: "AnPlusB",
    loc: this.getLocation(r, this.tokenStart),
    a: t,
    b: i
  };
}
function Q1(r) {
  if (r.a) {
    let t =
    r.a === "+1" && "n" ||
    r.a === "1" && "n" ||
    r.a === "-1" && "-n" ||
    r.a + "n";
    if (r.b) {
      let i = r.b[0] === "-" || r.b[0] === "+" ? r.b : "+" + r.b;
      this.tokenize(t + i);
    } else this.tokenize(t);
  } else this.tokenize(r.b);
}
var Yl = {};
I(Yl, {
  walkContext: () => G1,
  structure: () => N1,
  parse: () => Vl,
  name: () => S1,
  generate: () => B1
});
function px() {
  return this.Raw(this.consumeUntilLeftCurlyBracketOrSemicolon, !0);
}
function F1() {
  for (let r = 1, t; t = this.lookupType(r); r++) {
    if (t === xr) return !0;
    if (t === Z || t === R) return !1;
  }
  return !1;
}
var S1 = "Atrule",
  G1 = "atrule",
  N1 = {
    name: String,
    prelude: ["AtrulePrelude", "Raw", null],
    block: ["Block", null]
  };
function Vl(r = !1) {
  let t = this.tokenStart,
    i,
    o,
    n = null,
    e = null;
  if (
  this.eat(R),
  i = this.substrToCursor(t + 1),
  o = i.toLowerCase(),
  this.skipSC(),
  this.eof === !1 && this.tokenType !== Z && this.tokenType !== nr)
  {
    if (this.parseAtrulePrelude)
    n = this.parseWithFallback(this.AtrulePrelude.bind(this, i, r), px);else
    n = px.call(this, this.tokenIndex);
    this.skipSC();
  }
  switch (this.tokenType) {
    case nr:
      this.next();
      break;
    case Z:
      if (
      hasOwnProperty.call(this.atrule, o) &&
      typeof this.atrule[o].block === "function")

      e = this.atrule[o].block.call(this, r);else
      e = this.Block(F1.call(this));
      break;
  }
  return {
    type: "Atrule",
    loc: this.getLocation(t, this.tokenStart),
    name: i,
    prelude: n,
    block: e
  };
}
function B1(r) {
  if (this.token(R, "@" + r.name), r.prelude !== null) this.node(r.prelude);
  if (r.block) this.node(r.block);else
  this.token(nr, ";");
}
var Ql = {};
I(Ql, {
  walkContext: () => A1,
  structure: () => H1,
  parse: () => El,
  name: () => y1,
  generate: () => R1
});
var y1 = "AtrulePrelude",
  A1 = "atrulePrelude",
  H1 = { children: [[]] };
function El(r) {
  let t = null;
  if (r !== null) r = r.toLowerCase();
  if (
  this.skipSC(),
  hasOwnProperty.call(this.atrule, r) &&
  typeof this.atrule[r].prelude === "function")

  t = this.atrule[r].prelude.call(this);else
  t = this.readSequence(this.scope.AtrulePrelude);
  if (
  this.skipSC(),
  this.eof !== !0 && this.tokenType !== Z && this.tokenType !== nr)

  this.error("Semicolon or block is expected");
  return {
    type: "AtrulePrelude",
    loc: this.getLocationFromList(t),
    children: t
  };
}
function R1(r) {
  this.children(r);
}
var Gl = {};
I(Gl, {
  structure: () => rp,
  parse: () => Sl,
  name: () => s1,
  generate: () => tp
});
var M1 = 36,
  _x = 42,
  bo = 61,
  Z1 = 94,
  Fl = 124,
  C1 = 126;
function T1() {
  if (this.eof) this.error("Unexpected end of input");
  let r = this.tokenStart,
    t = !1;
  if (this.isDelim(_x)) t = !0, this.next();else
  if (!this.isDelim(Fl)) this.eat(w);
  if (this.isDelim(Fl)) {
    if (this.charCodeAt(this.tokenStart + 1) !== bo) this.next(), this.eat(w);else
    if (t) this.error("Identifier is expected", this.tokenEnd);
  } else if (t) this.error("Vertical line is expected");
  return {
    type: "Identifier",
    loc: this.getLocation(r, this.tokenStart),
    name: this.substrToCursor(r)
  };
}
function d1() {
  let r = this.tokenStart,
    t = this.charCodeAt(r);
  if (t !== bo && t !== C1 && t !== Z1 && t !== M1 && t !== _x && t !== Fl)
  this.error("Attribute selector (=, ~=, ^=, $=, *=, |=) is expected");
  if (this.next(), t !== bo) {
    if (!this.isDelim(bo)) this.error("Equal sign is expected");
    this.next();
  }
  return this.substrToCursor(r);
}
var s1 = "AttributeSelector",
  rp = {
    name: "Identifier",
    matcher: [String, null],
    value: ["String", "Identifier", null],
    flags: [String, null]
  };
function Sl() {
  let r = this.tokenStart,
    t,
    i = null,
    o = null,
    n = null;
  if (
  this.eat(mr),
  this.skipSC(),
  t = T1.call(this),
  this.skipSC(),
  this.tokenType !== wr)
  {
    if (this.tokenType !== w)
    i = d1.call(this),
    this.skipSC(),
    o = this.tokenType === gr ? this.String() : this.Identifier(),
    this.skipSC();
    if (this.tokenType === w) n = this.consume(w), this.skipSC();
  }
  return (
    this.eat(wr),
    {
      type: "AttributeSelector",
      loc: this.getLocation(r, this.tokenStart),
      name: t,
      matcher: i,
      value: o,
      flags: n
    });

}
function tp(r) {
  if (this.token(P, "["), this.node(r.name), r.matcher !== null)
  this.tokenize(r.matcher), this.node(r.value);
  if (r.flags !== null) this.token(w, r.flags);
  this.token(P, "]");
}
var Bl = {};
I(Bl, {
  walkContext: () => ep,
  structure: () => lp,
  parse: () => Nl,
  name: () => op,
  generate: () => cp
});
var np = 38;
function Ox() {
  return this.Raw(null, !0);
}
function Dx() {
  return this.parseWithFallback(this.Rule, Ox);
}
function jx() {
  return this.Raw(this.consumeUntilSemicolonIncluded, !0);
}
function ip() {
  if (this.tokenType === nr) return jx.call(this, this.tokenIndex);
  let r = this.parseWithFallback(this.Declaration, jx);
  if (this.tokenType === nr) this.next();
  return r;
}
var op = "Block",
  ep = "block",
  lp = { children: [["Atrule", "Rule", "Declaration"]] };
function Nl(r) {
  let t = r ? ip : Dx,
    i = this.tokenStart,
    o = this.createList();
  this.eat(Z);
  r: while (!this.eof)
  switch (this.tokenType) {
    case xr:
      break r;
    case Y:
    case A:
      this.next();
      break;
    case R:
      o.push(this.parseWithFallback(this.Atrule.bind(this, r), Ox));
      break;
    default:
      if (r && this.isDelim(np)) o.push(Dx.call(this));else
      o.push(t.call(this));
  }
  if (!this.eof) this.eat(xr);
  return {
    type: "Block",
    loc: this.getLocation(i, this.tokenStart),
    children: o
  };
}
function cp(r) {
  this.token(Z, "{"),
  this.children(r, (t) => {
    if (t.type === "Declaration") this.token(nr, ";");
  }),
  this.token(xr, "}");
}
var Al = {};
I(Al, {
  structure: () => gp,
  parse: () => yl,
  name: () => up,
  generate: () => mp
});
var up = "Brackets",
  gp = { children: [[]] };
function yl(r, t) {
  let i = this.tokenStart,
    o = null;
  if (this.eat(mr), o = r.call(this, t), !this.eof) this.eat(wr);
  return {
    type: "Brackets",
    loc: this.getLocation(i, this.tokenStart),
    children: o
  };
}
function mp(r) {
  this.token(P, "["), this.children(r), this.token(P, "]");
}
var Rl = {};
I(Rl, {
  structure: () => vp,
  parse: () => Hl,
  name: () => bp,
  generate: () => hp
});
var bp = "CDC",
  vp = [];
function Hl() {
  let r = this.tokenStart;
  return (
    this.eat(hr),
    { type: "CDC", loc: this.getLocation(r, this.tokenStart) });

}
function hp() {
  this.token(hr, "-->");
}
var Zl = {};
I(Zl, {
  structure: () => xp,
  parse: () => Ml,
  name: () => $p,
  generate: () => fp
});
var $p = "CDO",
  xp = [];
function Ml() {
  let r = this.tokenStart;
  return (
    this.eat(dr),
    { type: "CDO", loc: this.getLocation(r, this.tokenStart) });

}
function fp() {
  this.token(dr, "<!--");
}
var Tl = {};
I(Tl, {
  structure: () => ap,
  parse: () => Cl,
  name: () => zp,
  generate: () => pp
});
var wp = 46,
  zp = "ClassSelector",
  ap = { name: String };
function Cl() {
  return (
    this.eatDelim(wp),
    {
      type: "ClassSelector",
      loc: this.getLocation(this.tokenStart - 1, this.tokenEnd),
      name: this.consume(w)
    });

}
function pp(r) {
  this.token(P, "."), this.token(w, r.name);
}
var sl = {};
I(sl, {
  structure: () => Ip,
  parse: () => dl,
  name: () => Op,
  generate: () => kp
});
var _p = 43,
  Ix = 47,
  Dp = 62,
  jp = 126,
  Op = "Combinator",
  Ip = { name: String };
function dl() {
  let r = this.tokenStart,
    t;
  switch (this.tokenType) {
    case Y:
      t = " ";
      break;
    case P:
      switch (this.charCodeAt(this.tokenStart)) {
        case Dp:
        case _p:
        case jp:
          this.next();
          break;
        case Ix:
          this.next(), this.eatIdent("deep"), this.eatDelim(Ix);
          break;
        default:
          this.error("Combinator is expected");
      }
      t = this.substrToCursor(r);
      break;
  }
  return {
    type: "Combinator",
    loc: this.getLocation(r, this.tokenStart),
    name: t
  };
}
function kp(r) {
  this.tokenize(r.name);
}
var tc = {};
I(tc, {
  structure: () => Xp,
  parse: () => rc,
  name: () => Pp,
  generate: () => qp
});
var Up = 42,
  Jp = 47,
  Pp = "Comment",
  Xp = { value: String };
function rc() {
  let r = this.tokenStart,
    t = this.tokenEnd;
  if (
  this.eat(A),
  t - r + 2 >= 2 &&
  this.charCodeAt(t - 2) === Up &&
  this.charCodeAt(t - 1) === Jp)

  t -= 2;
  return {
    type: "Comment",
    loc: this.getLocation(r, this.tokenStart),
    value: this.substring(r + 2, t)
  };
}
function qp(r) {
  this.token(A, "/*" + r.value + "*/");
}
var ic = {};
I(ic, {
  structure: () => Lp,
  parse: () => nc,
  name: () => Kp,
  generate: () => Yp
});
var Wp = new Set([d, j, Qr]),
  Kp = "Condition",
  Lp = {
    kind: String,
    children: [
    [
    "Identifier",
    "Feature",
    "FeatureFunction",
    "FeatureRange",
    "SupportsDeclaration"]]


  };
function kx(r) {
  if (this.lookupTypeNonSC(1) === w && Wp.has(this.lookupTypeNonSC(2)))
  return this.Feature(r);
  return this.FeatureRange(r);
}
var Vp = {
  media: kx,
  container: kx,
  supports() {
    return this.SupportsDeclaration();
  }
};
function nc(r = "media") {
  let t = this.createList();
  r: while (!this.eof)
  switch (this.tokenType) {
    case A:
    case Y:
      this.next();
      continue;
    case w:
      t.push(this.Identifier());
      break;
    case K:{
        let i = this.parseWithFallback(
          () => Vp[r].call(this, r),
          () => null
        );
        if (!i)
        i = this.parseWithFallback(
          () => {
            this.eat(K);
            let o = this.Condition(r);
            return this.eat(j), o;
          },
          () => {
            return this.GeneralEnclosed(r);
          }
        );
        t.push(i);
        break;
      }
    case k:{
        let i = this.parseWithFallback(
          () => this.FeatureFunction(r),
          () => null
        );
        if (!i) i = this.GeneralEnclosed(r);
        t.push(i);
        break;
      }
    default:
      break r;
  }
  if (t.isEmpty) this.error("Condition is expected");
  return {
    type: "Condition",
    loc: this.getLocationFromList(t),
    kind: r,
    children: t
  };
}
function Yp(r) {
  r.children.forEach((t) => {
    if (t.type === "Condition")
    this.token(K, "("), this.node(t), this.token(j, ")");else
    this.node(t);
  });
}
var ec = {};
I(ec, {
  walkContext: () => Hp,
  structure: () => Rp,
  parse: () => oc,
  name: () => Ap,
  generate: () => Mp
});
var Jx = 33,
  Ep = 35,
  Qp = 36,
  Fp = 38,
  Sp = 42,
  Gp = 43,
  Ux = 47;
function Np() {
  return this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !0);
}
function Bp() {
  return this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !1);
}
function yp() {
  let r = this.tokenIndex,
    t = this.Value();
  if (
  t.type !== "Raw" &&
  this.eof === !1 &&
  this.tokenType !== nr &&
  this.isDelim(Jx) === !1 &&
  this.isBalanceEdge(r) === !1)

  this.error();
  return t;
}
var Ap = "Declaration",
  Hp = "declaration",
  Rp = {
    important: [Boolean, String],
    property: String,
    value: ["Value", "Raw"]
  };
function oc() {
  let r = this.tokenStart,
    t = this.tokenIndex,
    i = Zp.call(this),
    o = no(i),
    n = o ? this.parseCustomProperty : this.parseValue,
    e = o ? Bp : Np,
    l = !1,
    u;
  this.skipSC(), this.eat(d);
  let g = this.tokenIndex;
  if (!o) this.skipSC();
  if (n) u = this.parseWithFallback(yp, e);else
  u = e.call(this, this.tokenIndex);
  if (o && u.type === "Value" && u.children.isEmpty) {
    for (let c = g - this.tokenIndex; c <= 0; c++)
    if (this.lookupType(c) === Y) {
      u.children.appendData({ type: "WhiteSpace", loc: null, value: " " });
      break;
    }
  }
  if (this.isDelim(Jx)) l = Cp.call(this), this.skipSC();
  if (this.eof === !1 && this.tokenType !== nr && this.isBalanceEdge(t) === !1)
  this.error();
  return {
    type: "Declaration",
    loc: this.getLocation(r, this.tokenStart),
    important: l,
    property: i,
    value: u
  };
}
function Mp(r) {
  if (
  this.token(w, r.property),
  this.token(d, ":"),
  this.node(r.value),
  r.important)

  this.token(P, "!"),
  this.token(w, r.important === !0 ? "important" : r.important);
}
function Zp() {
  let r = this.tokenStart;
  if (this.tokenType === P)
  switch (this.charCodeAt(this.tokenStart)) {
    case Sp:
    case Qp:
    case Gp:
    case Ep:
    case Fp:
      this.next();
      break;
    case Ux:
      if (this.next(), this.isDelim(Ux)) this.next();
      break;
  }
  if (this.tokenType === S) this.eat(S);else
  this.eat(w);
  return this.substrToCursor(r);
}
function Cp() {
  this.eat(P), this.skipSC();
  let r = this.consume(w);
  return r === "important" ? !0 : r;
}
var uc = {};
I(uc, {
  structure: () => sp,
  parse: () => cc,
  name: () => dp,
  generate: () => r2
});
var Tp = 38;
function lc() {
  return this.Raw(this.consumeUntilSemicolonIncluded, !0);
}
var dp = "DeclarationList",
  sp = { children: [["Declaration", "Atrule", "Rule"]] };
function cc() {
  let r = this.createList();
  r: while (!this.eof)
  switch (this.tokenType) {
    case Y:
    case A:
    case nr:
      this.next();
      break;
    case R:
      r.push(this.parseWithFallback(this.Atrule.bind(this, !0), lc));
      break;
    default:
      if (this.isDelim(Tp)) r.push(this.parseWithFallback(this.Rule, lc));else
      r.push(this.parseWithFallback(this.Declaration, lc));
  }
  return {
    type: "DeclarationList",
    loc: this.getLocationFromList(r),
    children: r
  };
}
function r2(r) {
  this.children(r, (t) => {
    if (t.type === "Declaration") this.token(nr, ";");
  });
}
var mc = {};
I(mc, {
  structure: () => n2,
  parse: () => gc,
  name: () => t2,
  generate: () => i2
});
var t2 = "Dimension",
  n2 = { value: String, unit: String };
function gc() {
  let r = this.tokenStart,
    t = this.consumeNumber(q);
  return {
    type: "Dimension",
    loc: this.getLocation(r, this.tokenStart),
    value: t,
    unit: this.substring(r + t.length, this.tokenStart)
  };
}
function i2(r) {
  this.token(q, r.value + r.unit);
}
var vc = {};
I(vc, {
  structure: () => l2,
  parse: () => bc,
  name: () => e2,
  generate: () => c2
});
var o2 = 47,
  e2 = "Feature",
  l2 = {
    kind: String,
    name: String,
    value: ["Identifier", "Number", "Dimension", "Ratio", "Function", null]
  };
function bc(r) {
  let t = this.tokenStart,
    i,
    o = null;
  if (
  this.eat(K),
  this.skipSC(),
  i = this.consume(w),
  this.skipSC(),
  this.tokenType !== j)
  {
    switch (this.eat(d), this.skipSC(), this.tokenType) {
      case U:
        if (this.lookupNonWSType(1) === P) o = this.Ratio();else
        o = this.Number();
        break;
      case q:
        o = this.Dimension();
        break;
      case w:
        o = this.Identifier();
        break;
      case k:
        o = this.parseWithFallback(
          () => {
            let n = this.Function(this.readSequence, this.scope.Value);
            if (this.skipSC(), this.isDelim(o2)) this.error();
            return n;
          },
          () => {
            return this.Ratio();
          }
        );
        break;
      default:
        this.error("Number, dimension, ratio or identifier is expected");
    }
    this.skipSC();
  }
  if (!this.eof) this.eat(j);
  return {
    type: "Feature",
    loc: this.getLocation(t, this.tokenStart),
    kind: r,
    name: i,
    value: o
  };
}
function c2(r) {
  if (this.token(K, "("), this.token(w, r.name), r.value !== null)
  this.token(d, ":"), this.node(r.value);
  this.token(j, ")");
}
var $c = {};
I($c, {
  structure: () => g2,
  parse: () => hc,
  name: () => u2,
  generate: () => b2
});
var u2 = "FeatureFunction",
  g2 = { kind: String, feature: String, value: ["Declaration", "Selector"] };
function m2(r, t) {
  let o = (this.features[r] || {})[t];
  if (typeof o !== "function") this.error(`Unknown feature ${t}()`);
  return o;
}
function hc(r = "unknown") {
  let t = this.tokenStart,
    i = this.consumeFunctionName(),
    o = m2.call(this, r, i.toLowerCase());
  this.skipSC();
  let n = this.parseWithFallback(
    () => {
      let e = this.tokenIndex,
        l = o.call(this);
      if (this.eof === !1 && this.isBalanceEdge(e) === !1) this.error();
      return l;
    },
    () => this.Raw(null, !1)
  );
  if (!this.eof) this.eat(j);
  return {
    type: "FeatureFunction",
    loc: this.getLocation(t, this.tokenStart),
    kind: r,
    feature: i,
    value: n
  };
}
function b2(r) {
  this.token(k, r.feature + "("), this.node(r.value), this.token(j, ")");
}
var wc = {};
I(wc, {
  structure: () => x2,
  parse: () => fc,
  name: () => $2,
  generate: () => f2
});
var Px = 47,
  v2 = 60,
  Xx = 61,
  h2 = 62,
  $2 = "FeatureRange",
  x2 = {
    kind: String,
    left: ["Identifier", "Number", "Dimension", "Ratio", "Function"],
    leftComparison: String,
    middle: ["Identifier", "Number", "Dimension", "Ratio", "Function"],
    rightComparison: [String, null],
    right: ["Identifier", "Number", "Dimension", "Ratio", "Function", null]
  };
function xc() {
  switch (this.skipSC(), this.tokenType) {
    case U:
      if (this.isDelim(Px, this.lookupOffsetNonSC(1))) return this.Ratio();else
      return this.Number();
    case q:
      return this.Dimension();
    case w:
      return this.Identifier();
    case k:
      return this.parseWithFallback(
        () => {
          let r = this.Function(this.readSequence, this.scope.Value);
          if (this.skipSC(), this.isDelim(Px)) this.error();
          return r;
        },
        () => {
          return this.Ratio();
        }
      );
    default:
      this.error("Number, dimension, ratio or identifier is expected");
  }
}
function qx(r) {
  if (this.skipSC(), this.isDelim(v2) || this.isDelim(h2)) {
    let t = this.source[this.tokenStart];
    if (this.next(), this.isDelim(Xx)) return this.next(), t + "=";
    return t;
  }
  if (this.isDelim(Xx)) return "=";
  this.error(`Expected ${r ? '":", ' : ""}"<", ">", "=" or ")"`);
}
function fc(r = "unknown") {
  let t = this.tokenStart;
  this.skipSC(), this.eat(K);
  let i = xc.call(this),
    o = qx.call(this, i.type === "Identifier"),
    n = xc.call(this),
    e = null,
    l = null;
  if (this.lookupNonWSType(0) !== j) e = qx.call(this), l = xc.call(this);
  return (
    this.skipSC(),
    this.eat(j),
    {
      type: "FeatureRange",
      loc: this.getLocation(t, this.tokenStart),
      kind: r,
      left: i,
      leftComparison: o,
      middle: n,
      rightComparison: e,
      right: l
    });

}
function f2(r) {
  if (
  this.token(K, "("),
  this.node(r.left),
  this.tokenize(r.leftComparison),
  this.node(r.middle),
  r.right)

  this.tokenize(r.rightComparison), this.node(r.right);
  this.token(j, ")");
}
var ac = {};
I(ac, {
  walkContext: () => z2,
  structure: () => a2,
  parse: () => zc,
  name: () => w2,
  generate: () => p2
});
var w2 = "Function",
  z2 = "function",
  a2 = { name: String, children: [[]] };
function zc(r, t) {
  let i = this.tokenStart,
    o = this.consumeFunctionName(),
    n = o.toLowerCase(),
    e;
  if (
  e = t.hasOwnProperty(n) ? t[n].call(this, t) : r.call(this, t),
  !this.eof)

  this.eat(j);
  return {
    type: "Function",
    loc: this.getLocation(i, this.tokenStart),
    name: o,
    children: e
  };
}
function p2(r) {
  this.token(k, r.name + "("), this.children(r), this.token(j, ")");
}
var _c = {};
I(_c, {
  structure: () => D2,
  parse: () => pc,
  name: () => _2,
  generate: () => j2
});
var _2 = "GeneralEnclosed",
  D2 = { kind: String, function: [String, null], children: [[]] };
function pc(r) {
  let t = this.tokenStart,
    i = null;
  if (this.tokenType === k) i = this.consumeFunctionName();else
  this.eat(K);
  let o = this.parseWithFallback(
    () => {
      let n = this.tokenIndex,
        e = this.readSequence(this.scope.Value);
      if (this.eof === !1 && this.isBalanceEdge(n) === !1) this.error();
      return e;
    },
    () => this.createSingleNodeList(this.Raw(null, !1))
  );
  if (!this.eof) this.eat(j);
  return {
    type: "GeneralEnclosed",
    loc: this.getLocation(t, this.tokenStart),
    kind: r,
    function: i,
    children: o
  };
}
function j2(r) {
  if (r.function) this.token(k, r.function + "(");else
  this.token(K, "(");
  this.children(r), this.token(j, ")");
}
var jc = {};
I(jc, {
  xxx: () => O2,
  structure: () => k2,
  parse: () => Dc,
  name: () => I2,
  generate: () => U2
});
var O2 = "XXX",
  I2 = "Hash",
  k2 = { value: String };
function Dc() {
  let r = this.tokenStart;
  return (
    this.eat(S),
    {
      type: "Hash",
      loc: this.getLocation(r, this.tokenStart),
      value: this.substrToCursor(r + 1)
    });

}
function U2(r) {
  this.token(S, "#" + r.value);
}
var Ic = {};
I(Ic, {
  structure: () => P2,
  parse: () => Oc,
  name: () => J2,
  generate: () => X2
});
var J2 = "Identifier",
  P2 = { name: String };
function Oc() {
  return {
    type: "Identifier",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    name: this.consume(w)
  };
}
function X2(r) {
  this.token(w, r.name);
}
var Uc = {};
I(Uc, {
  structure: () => W2,
  parse: () => kc,
  name: () => q2,
  generate: () => K2
});
var q2 = "IdSelector",
  W2 = { name: String };
function kc() {
  let r = this.tokenStart;
  return (
    this.eat(S),
    {
      type: "IdSelector",
      loc: this.getLocation(r, this.tokenStart),
      name: this.substrToCursor(r + 1)
    });

}
function K2(r) {
  this.token(P, "#" + r.name);
}
var Pc = {};
I(Pc, {
  structure: () => Y2,
  parse: () => Jc,
  name: () => V2,
  generate: () => E2
});
var L2 = 46,
  V2 = "Layer",
  Y2 = { name: String };
function Jc() {
  let r = this.tokenStart,
    t = this.consume(w);
  while (this.isDelim(L2)) this.eat(P), t += "." + this.consume(w);
  return { type: "Layer", loc: this.getLocation(r, this.tokenStart), name: t };
}
function E2(r) {
  this.tokenize(r.name);
}
var qc = {};
I(qc, {
  structure: () => F2,
  parse: () => Xc,
  name: () => Q2,
  generate: () => S2
});
var Q2 = "LayerList",
  F2 = { children: [["Layer"]] };
function Xc() {
  let r = this.createList();
  this.skipSC();
  while (!this.eof) {
    if (r.push(this.Layer()), this.lookupTypeNonSC(0) !== ir) break;
    this.skipSC(), this.next(), this.skipSC();
  }
  return { type: "LayerList", loc: this.getLocationFromList(r), children: r };
}
function S2(r) {
  this.children(r, () => this.token(ir, ","));
}
var Kc = {};
I(Kc, {
  structure: () => N2,
  parse: () => Wc,
  name: () => G2,
  generate: () => B2
});
var G2 = "MediaQuery",
  N2 = {
    modifier: [String, null],
    mediaType: [String, null],
    condition: ["Condition", null]
  };
function Wc() {
  let r = this.tokenStart,
    t = null,
    i = null,
    o = null;
  if (this.skipSC(), this.tokenType === w && this.lookupTypeNonSC(1) !== K) {
    let n = this.consume(w),
      e = n.toLowerCase();
    if (e === "not" || e === "only")
    this.skipSC(), t = e, i = this.consume(w);else
    i = n;
    switch (this.lookupTypeNonSC(0)) {
      case w:{
          this.skipSC(), this.eatIdent("and"), o = this.Condition("media");
          break;
        }
      case Z:
      case nr:
      case ir:
      case Qr:
        break;
      default:
        this.error("Identifier or parenthesis is expected");
    }
  } else
  switch (this.tokenType) {
    case w:
    case K:
    case k:{
        o = this.Condition("media");
        break;
      }
    case Z:
    case nr:
    case Qr:
      break;
    default:
      this.error("Identifier or parenthesis is expected");
  }
  return {
    type: "MediaQuery",
    loc: this.getLocation(r, this.tokenStart),
    modifier: t,
    mediaType: i,
    condition: o
  };
}
function B2(r) {
  if (r.mediaType) {
    if (r.modifier) this.token(w, r.modifier);
    if (this.token(w, r.mediaType), r.condition)
    this.token(w, "and"), this.node(r.condition);
  } else if (r.condition) this.node(r.condition);
}
var Vc = {};
I(Vc, {
  structure: () => A2,
  parse: () => Lc,
  name: () => y2,
  generate: () => H2
});
var y2 = "MediaQueryList",
  A2 = { children: [["MediaQuery"]] };
function Lc() {
  let r = this.createList();
  this.skipSC();
  while (!this.eof) {
    if (r.push(this.MediaQuery()), this.tokenType !== ir) break;
    this.next();
  }
  return {
    type: "MediaQueryList",
    loc: this.getLocationFromList(r),
    children: r
  };
}
function H2(r) {
  this.children(r, () => this.token(ir, ","));
}
var Ec = {};
I(Ec, {
  structure: () => Z2,
  parse: () => Yc,
  name: () => M2,
  generate: () => C2
});
var R2 = 38,
  M2 = "NestingSelector",
  Z2 = {};
function Yc() {
  let r = this.tokenStart;
  return (
    this.eatDelim(R2),
    { type: "NestingSelector", loc: this.getLocation(r, this.tokenStart) });

}
function C2() {
  this.token(P, "&");
}
var Fc = {};
I(Fc, {
  structure: () => d2,
  parse: () => Qc,
  name: () => T2,
  generate: () => s2
});
var T2 = "Nth",
  d2 = { nth: ["AnPlusB", "Identifier"], selector: ["SelectorList", null] };
function Qc() {
  this.skipSC();
  let r = this.tokenStart,
    t = r,
    i = null,
    o;
  if (this.lookupValue(0, "odd") || this.lookupValue(0, "even"))
  o = this.Identifier();else
  o = this.AnPlusB();
  if (t = this.tokenStart, this.skipSC(), this.lookupValue(0, "of"))
  this.next(), i = this.SelectorList(), t = this.tokenStart;
  return { type: "Nth", loc: this.getLocation(r, t), nth: o, selector: i };
}
function s2(r) {
  if (this.node(r.nth), r.selector !== null)
  this.token(w, "of"), this.node(r.selector);
}
var Gc = {};
I(Gc, {
  structure: () => t_,
  parse: () => Sc,
  name: () => r_,
  generate: () => n_
});
var r_ = "Number",
  t_ = { value: String };
function Sc() {
  return {
    type: "Number",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: this.consume(U)
  };
}
function n_(r) {
  this.token(U, r.value);
}
var Bc = {};
I(Bc, {
  structure: () => o_,
  parse: () => Nc,
  name: () => i_,
  generate: () => e_
});
var i_ = "Operator",
  o_ = { value: String };
function Nc() {
  let r = this.tokenStart;
  return (
    this.next(),
    {
      type: "Operator",
      loc: this.getLocation(r, this.tokenStart),
      value: this.substrToCursor(r)
    });

}
function e_(r) {
  this.tokenize(r.value);
}
var Ac = {};
I(Ac, {
  structure: () => c_,
  parse: () => yc,
  name: () => l_,
  generate: () => u_
});
var l_ = "Parentheses",
  c_ = { children: [[]] };
function yc(r, t) {
  let i = this.tokenStart,
    o = null;
  if (this.eat(K), o = r.call(this, t), !this.eof) this.eat(j);
  return {
    type: "Parentheses",
    loc: this.getLocation(i, this.tokenStart),
    children: o
  };
}
function u_(r) {
  this.token(K, "("), this.children(r), this.token(j, ")");
}
var Rc = {};
I(Rc, {
  structure: () => m_,
  parse: () => Hc,
  name: () => g_,
  generate: () => b_
});
var g_ = "Percentage",
  m_ = { value: String };
function Hc() {
  return {
    type: "Percentage",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: this.consumeNumber(y)
  };
}
function b_(r) {
  this.token(y, r.value + "%");
}
var Zc = {};
I(Zc, {
  walkContext: () => h_,
  structure: () => $_,
  parse: () => Mc,
  name: () => v_,
  generate: () => x_
});
var v_ = "PseudoClassSelector",
  h_ = "function",
  $_ = { name: String, children: [["Raw"], null] };
function Mc() {
  let r = this.tokenStart,
    t = null,
    i,
    o;
  if (this.eat(d), this.tokenType === k) {
    if (
    i = this.consumeFunctionName(),
    o = i.toLowerCase(),
    this.lookupNonWSType(0) == j)

    t = this.createList();else
    if (hasOwnProperty.call(this.pseudo, o))
    this.skipSC(), t = this.pseudo[o].call(this), this.skipSC();else
    t = this.createList(), t.push(this.Raw(null, !1));
    this.eat(j);
  } else i = this.consume(w);
  return {
    type: "PseudoClassSelector",
    loc: this.getLocation(r, this.tokenStart),
    name: i,
    children: t
  };
}
function x_(r) {
  if (this.token(d, ":"), r.children === null) this.token(w, r.name);else
  this.token(k, r.name + "("), this.children(r), this.token(j, ")");
}
var Tc = {};
I(Tc, {
  walkContext: () => w_,
  structure: () => z_,
  parse: () => Cc,
  name: () => f_,
  generate: () => a_
});
var f_ = "PseudoElementSelector",
  w_ = "function",
  z_ = { name: String, children: [["Raw"], null] };
function Cc() {
  let r = this.tokenStart,
    t = null,
    i,
    o;
  if (this.eat(d), this.eat(d), this.tokenType === k) {
    if (
    i = this.consumeFunctionName(),
    o = i.toLowerCase(),
    this.lookupNonWSType(0) == j)

    t = this.createList();else
    if (hasOwnProperty.call(this.pseudo, o))
    this.skipSC(), t = this.pseudo[o].call(this), this.skipSC();else
    t = this.createList(), t.push(this.Raw(null, !1));
    this.eat(j);
  } else i = this.consume(w);
  return {
    type: "PseudoElementSelector",
    loc: this.getLocation(r, this.tokenStart),
    name: i,
    children: t
  };
}
function a_(r) {
  if (this.token(d, ":"), this.token(d, ":"), r.children === null)
  this.token(w, r.name);else
  this.token(k, r.name + "("), this.children(r), this.token(j, ")");
}
var sc = {};
I(sc, {
  structure: () => __,
  parse: () => dc,
  name: () => p_,
  generate: () => D_
});
var Wx = 47;
function Kx() {
  switch (this.skipSC(), this.tokenType) {
    case U:
      return this.Number();
    case k:
      return this.Function(this.readSequence, this.scope.Value);
    default:
      this.error("Number of function is expected");
  }
}
var p_ = "Ratio",
  __ = { left: ["Number", "Function"], right: ["Number", "Function", null] };
function dc() {
  let r = this.tokenStart,
    t = Kx.call(this),
    i = null;
  if (this.skipSC(), this.isDelim(Wx))
  this.eatDelim(Wx), i = Kx.call(this);
  return {
    type: "Ratio",
    loc: this.getLocation(r, this.tokenStart),
    left: t,
    right: i
  };
}
function D_(r) {
  if (this.node(r.left), this.token(P, "/"), r.right) this.node(r.right);else
  this.node(U, 1);
}
var tu = {};
I(tu, {
  structure: () => I_,
  parse: () => ru,
  name: () => O_,
  generate: () => k_
});
function j_() {
  if (this.tokenIndex > 0) {
    if (this.lookupType(-1) === Y)
    return this.tokenIndex > 1 ?
    this.getTokenStart(this.tokenIndex - 1) :
    this.firstCharOffset;
  }
  return this.tokenStart;
}
var O_ = "Raw",
  I_ = { value: String };
function ru(r, t) {
  let i = this.getTokenStart(this.tokenIndex),
    o;
  if (
  this.skipUntilBalanced(this.tokenIndex, r || this.consumeUntilBalanceEnd),
  t && this.tokenStart > i)

  o = j_.call(this);else
  o = this.tokenStart;
  return {
    type: "Raw",
    loc: this.getLocation(i, o),
    value: this.substring(i, o)
  };
}
function k_(r) {
  this.tokenize(r.value);
}
var iu = {};
I(iu, {
  walkContext: () => P_,
  structure: () => X_,
  parse: () => nu,
  name: () => J_,
  generate: () => q_
});
function Lx() {
  return this.Raw(this.consumeUntilLeftCurlyBracket, !0);
}
function U_() {
  let r = this.SelectorList();
  if (r.type !== "Raw" && this.eof === !1 && this.tokenType !== Z) this.error();
  return r;
}
var J_ = "Rule",
  P_ = "rule",
  X_ = { prelude: ["SelectorList", "Raw"], block: ["Block"] };
function nu() {
  let r = this.tokenIndex,
    t = this.tokenStart,
    i,
    o;
  if (this.parseRulePrelude) i = this.parseWithFallback(U_, Lx);else
  i = Lx.call(this, r);
  return (
    o = this.Block(!0),
    {
      type: "Rule",
      loc: this.getLocation(t, this.tokenStart),
      prelude: i,
      block: o
    });

}
function q_(r) {
  this.node(r.prelude), this.node(r.block);
}
var eu = {};
I(eu, {
  structure: () => K_,
  parse: () => ou,
  name: () => W_,
  generate: () => L_
});
var W_ = "Scope",
  K_ = {
    root: ["SelectorList", "Raw", null],
    limit: ["SelectorList", "Raw", null]
  };
function ou() {
  let r = null,
    t = null;
  this.skipSC();
  let i = this.tokenStart;
  if (this.tokenType === K)
  this.next(),
  this.skipSC(),
  r = this.parseWithFallback(this.SelectorList, () => this.Raw(!1, !0)),
  this.skipSC(),
  this.eat(j);
  if (this.lookupNonWSType(0) === w)
  this.skipSC(),
  this.eatIdent("to"),
  this.skipSC(),
  this.eat(K),
  this.skipSC(),
  t = this.parseWithFallback(this.SelectorList, () => this.Raw(!1, !0)),
  this.skipSC(),
  this.eat(j);
  return {
    type: "Scope",
    loc: this.getLocation(i, this.tokenStart),
    root: r,
    limit: t
  };
}
function L_(r) {
  if (r.root) this.token(K, "("), this.node(r.root), this.token(j, ")");
  if (r.limit)
  this.token(w, "to"),
  this.token(K, "("),
  this.node(r.limit),
  this.token(j, ")");
}
var cu = {};
I(cu, {
  structure: () => Y_,
  parse: () => lu,
  name: () => V_,
  generate: () => E_
});
var V_ = "Selector",
  Y_ = {
    children: [
    [
    "TypeSelector",
    "IdSelector",
    "ClassSelector",
    "AttributeSelector",
    "PseudoClassSelector",
    "PseudoElementSelector",
    "Combinator"]]


  };
function lu() {
  let r = this.readSequence(this.scope.Selector);
  if (this.getFirstListNode(r) === null) this.error("Selector is expected");
  return { type: "Selector", loc: this.getLocationFromList(r), children: r };
}
function E_(r) {
  this.children(r);
}
var gu = {};
I(gu, {
  walkContext: () => F_,
  structure: () => S_,
  parse: () => uu,
  name: () => Q_,
  generate: () => G_
});
var Q_ = "SelectorList",
  F_ = "selector",
  S_ = { children: [["Selector", "Raw"]] };
function uu() {
  let r = this.createList();
  while (!this.eof) {
    if (r.push(this.Selector()), this.tokenType === ir) {
      this.next();
      continue;
    }
    break;
  }
  return {
    type: "SelectorList",
    loc: this.getLocationFromList(r),
    children: r
  };
}
function G_(r) {
  this.children(r, () => this.token(ir, ","));
}
var vu = {};
I(vu, {
  structure: () => B_,
  parse: () => bu,
  name: () => N_,
  generate: () => y_
});
var mu = 92,
  Vx = 34,
  Yx = 39;
function vo(r) {
  let t = r.length,
    i = r.charCodeAt(0),
    o = i === Vx || i === Yx ? 1 : 0,
    n = o === 1 && t > 1 && r.charCodeAt(t - 1) === i ? t - 2 : t - 1,
    e = "";
  for (let l = o; l <= n; l++) {
    let u = r.charCodeAt(l);
    if (u === mu) {
      if (l === n) {
        if (l !== t - 1) e = r.substr(l + 1);
        break;
      }
      if (u = r.charCodeAt(++l), Dr(mu, u)) {
        let g = l - 1,
          c = yr(r, g);
        l = c - 1, e += On(r.substring(g + 1, c));
      } else if (u === 13 && r.charCodeAt(l + 1) === 10) l++;
    } else e += r[l];
  }
  return e;
}
function Ex(r, t) {
  let i = t ? "'" : '"',
    o = t ? Yx : Vx,
    n = "",
    e = !1;
  for (let l = 0; l < r.length; l++) {
    let u = r.charCodeAt(l);
    if (u === 0) {
      n += "�";
      continue;
    }
    if (u <= 31 || u === 127) {
      n += "\\" + u.toString(16), e = !0;
      continue;
    }
    if (u === o || u === mu) n += "\\" + r.charAt(l), e = !1;else
    {
      if (e && (Or(u) || Br(u))) n += " ";
      n += r.charAt(l), e = !1;
    }
  }
  return i + n + i;
}
var N_ = "String",
  B_ = { value: String };
function bu() {
  return {
    type: "String",
    loc: this.getLocation(this.tokenStart, this.tokenEnd),
    value: vo(this.consume(gr))
  };
}
function y_(r) {
  this.token(gr, Ex(r.value));
}
var $u = {};
I($u, {
  walkContext: () => R_,
  structure: () => M_,
  parse: () => hu,
  name: () => H_,
  generate: () => Z_
});
var A_ = 33;
function Fx() {
  return this.Raw(null, !1);
}
var H_ = "StyleSheet",
  R_ = "stylesheet",
  M_ = { children: [["Comment", "CDO", "CDC", "Atrule", "Rule", "Raw"]] };
function hu() {
  let r = this.tokenStart,
    t = this.createList(),
    i;
  r: while (!this.eof) {
    switch (this.tokenType) {
      case Y:
        this.next();
        continue;
      case A:
        if (this.charCodeAt(this.tokenStart + 2) !== A_) {
          this.next();
          continue;
        }
        i = this.Comment();
        break;
      case dr:
        i = this.CDO();
        break;
      case hr:
        i = this.CDC();
        break;
      case R:
        i = this.parseWithFallback(this.Atrule, Fx);
        break;
      default:
        i = this.parseWithFallback(this.Rule, Fx);
    }
    t.push(i);
  }
  return {
    type: "StyleSheet",
    loc: this.getLocation(r, this.tokenStart),
    children: t
  };
}
function Z_(r) {
  this.children(r);
}
var fu = {};
I(fu, {
  structure: () => T_,
  parse: () => xu,
  name: () => C_,
  generate: () => d_
});
var C_ = "SupportsDeclaration",
  T_ = { declaration: "Declaration" };
function xu() {
  let r = this.tokenStart;
  this.eat(K), this.skipSC();
  let t = this.Declaration();
  if (!this.eof) this.eat(j);
  return {
    type: "SupportsDeclaration",
    loc: this.getLocation(r, this.tokenStart),
    declaration: t
  };
}
function d_(r) {
  this.token(K, "("), this.node(r.declaration), this.token(j, ")");
}
var au = {};
I(au, {
  structure: () => tD,
  parse: () => zu,
  name: () => rD,
  generate: () => nD
});
var s_ = 42,
  Sx = 124;
function wu() {
  if (this.tokenType !== w && this.isDelim(s_) === !1)
  this.error("Identifier or asterisk is expected");
  this.next();
}
var rD = "TypeSelector",
  tD = { name: String };
function zu() {
  let r = this.tokenStart;
  if (this.isDelim(Sx)) this.next(), wu.call(this);else
  if (wu.call(this), this.isDelim(Sx)) this.next(), wu.call(this);
  return {
    type: "TypeSelector",
    loc: this.getLocation(r, this.tokenStart),
    name: this.substrToCursor(r)
  };
}
function nD(r) {
  this.tokenize(r.name);
}
var Du = {};
I(Du, {
  structure: () => lD,
  parse: () => _u,
  name: () => eD,
  generate: () => cD
});
var Gx = 43,
  Nx = 45,
  pu = 63;
function Gn(r, t) {
  let i = 0;
  for (let o = this.tokenStart + r; o < this.tokenEnd; o++) {
    let n = this.charCodeAt(o);
    if (n === Nx && t && i !== 0) return Gn.call(this, r + i + 1, !1), -1;
    if (!Or(n))
    this.error(
      t && i !== 0 ?
      "Hyphen minus" + (i < 6 ? " or hex digit" : "") + " is expected" :
      i < 6 ?
      "Hex digit is expected" :
      "Unexpected input",
      o
    );
    if (++i > 6) this.error("Too many hex digits", o);
  }
  return this.next(), i;
}
function ho(r) {
  let t = 0;
  while (this.isDelim(pu)) {
    if (++t > r) this.error("Too many question marks");
    this.next();
  }
}
function iD(r) {
  if (this.charCodeAt(this.tokenStart) !== r)
  this.error((r === Gx ? "Plus sign" : "Hyphen minus") + " is expected");
}
function oD() {
  let r = 0;
  switch (this.tokenType) {
    case U:
      if (r = Gn.call(this, 1, !0), this.isDelim(pu)) {
        ho.call(this, 6 - r);
        break;
      }
      if (this.tokenType === q || this.tokenType === U) {
        iD.call(this, Nx), Gn.call(this, 1, !1);
        break;
      }
      break;
    case q:
      if (r = Gn.call(this, 1, !0), r > 0) ho.call(this, 6 - r);
      break;
    default:
      if (this.eatDelim(Gx), this.tokenType === w) {
        if (r = Gn.call(this, 0, !0), r > 0) ho.call(this, 6 - r);
        break;
      }
      if (this.isDelim(pu)) {
        this.next(), ho.call(this, 5);
        break;
      }
      this.error("Hex digit or question mark is expected");
  }
}
var eD = "UnicodeRange",
  lD = { value: String };
function _u() {
  let r = this.tokenStart;
  return (
    this.eatIdent("u"),
    oD.call(this),
    {
      type: "UnicodeRange",
      loc: this.getLocation(r, this.tokenStart),
      value: this.substrToCursor(r)
    });

}
function cD(r) {
  this.tokenize(r.value);
}
var Iu = {};
I(Iu, {
  structure: () => hD,
  parse: () => Ou,
  name: () => vD,
  generate: () => $D
});
var uD = 32,
  ju = 92,
  gD = 34,
  mD = 39,
  bD = 40,
  Bx = 41;
function yx(r) {
  let t = r.length,
    i = 4,
    o = r.charCodeAt(t - 1) === Bx ? t - 2 : t - 1,
    n = "";
  while (i < o && Br(r.charCodeAt(i))) i++;
  while (i < o && Br(r.charCodeAt(o))) o--;
  for (let e = i; e <= o; e++) {
    let l = r.charCodeAt(e);
    if (l === ju) {
      if (e === o) {
        if (e !== t - 1) n = r.substr(e + 1);
        break;
      }
      if (l = r.charCodeAt(++e), Dr(ju, l)) {
        let u = e - 1,
          g = yr(r, u);
        e = g - 1, n += On(r.substring(u + 1, g));
      } else if (l === 13 && r.charCodeAt(e + 1) === 10) e++;
    } else n += r[e];
  }
  return n;
}
function Ax(r) {
  let t = "",
    i = !1;
  for (let o = 0; o < r.length; o++) {
    let n = r.charCodeAt(o);
    if (n === 0) {
      t += "�";
      continue;
    }
    if (n <= 31 || n === 127) {
      t += "\\" + n.toString(16), i = !0;
      continue;
    }
    if (n === uD || n === ju || n === gD || n === mD || n === bD || n === Bx)
    t += "\\" + r.charAt(o), i = !1;else
    {
      if (i && Or(n)) t += " ";
      t += r.charAt(o), i = !1;
    }
  }
  return "url(" + t + ")";
}
var vD = "Url",
  hD = { value: String };
function Ou() {
  let r = this.tokenStart,
    t;
  switch (this.tokenType) {
    case er:
      t = yx(this.consume(er));
      break;
    case k:
      if (!this.cmpStr(this.tokenStart, this.tokenEnd, "url("))
      this.error("Function name must be `url`");
      if (
      this.eat(k),
      this.skipSC(),
      t = vo(this.consume(gr)),
      this.skipSC(),
      !this.eof)

      this.eat(j);
      break;
    default:
      this.error("Url or Function is expected");
  }
  return { type: "Url", loc: this.getLocation(r, this.tokenStart), value: t };
}
function $D(r) {
  this.token(er, Ax(r.value));
}
var Uu = {};
I(Uu, {
  structure: () => fD,
  parse: () => ku,
  name: () => xD,
  generate: () => wD
});
var xD = "Value",
  fD = { children: [[]] };
function ku() {
  let r = this.tokenStart,
    t = this.readSequence(this.scope.Value);
  return {
    type: "Value",
    loc: this.getLocation(r, this.tokenStart),
    children: t
  };
}
function wD(r) {
  this.children(r);
}
var Pu = {};
I(Pu, {
  structure: () => pD,
  parse: () => Ju,
  name: () => aD,
  generate: () => _D
});
var zD = Object.freeze({ type: "WhiteSpace", loc: null, value: " " }),
  aD = "WhiteSpace",
  pD = { value: String };
function Ju() {
  return this.eat(Y), zD;
}
function _D(r) {
  this.token(Y, r.value);
}
var Rx = { generic: !0, cssWideKeywords: Zt, ...ax, node: Nn };
var Wu = {};
I(Wu, { Value: () => sx, Selector: () => Tx, AtrulePrelude: () => Zx });
var DD = 35,
  jD = 42,
  Mx = 43,
  OD = 45,
  ID = 47,
  kD = 117;
function Bn(r) {
  switch (this.tokenType) {
    case S:
      return this.Hash();
    case ir:
      return this.Operator();
    case K:
      return this.Parentheses(this.readSequence, r.recognizer);
    case mr:
      return this.Brackets(this.readSequence, r.recognizer);
    case gr:
      return this.String();
    case q:
      return this.Dimension();
    case y:
      return this.Percentage();
    case U:
      return this.Number();
    case k:
      return this.cmpStr(this.tokenStart, this.tokenEnd, "url(") ?
      this.Url() :
      this.Function(this.readSequence, r.recognizer);
    case er:
      return this.Url();
    case w:
      if (
      this.cmpChar(this.tokenStart, kD) &&
      this.cmpChar(this.tokenStart + 1, Mx))

      return this.UnicodeRange();else
      return this.Identifier();
    case P:{
        let t = this.charCodeAt(this.tokenStart);
        if (t === ID || t === jD || t === Mx || t === OD) return this.Operator();
        if (t === DD)
        this.error("Hex or identifier is expected", this.tokenStart + 1);
        break;
      }
  }
}
var Zx = { getNode: Bn };
var UD = 35,
  JD = 38,
  PD = 42,
  XD = 43,
  qD = 47,
  Cx = 46,
  WD = 62,
  KD = 124,
  LD = 126;
function VD(r, t) {
  if (
  t.last !== null &&
  t.last.type !== "Combinator" &&
  r !== null &&
  r.type !== "Combinator")

  t.push({ type: "Combinator", loc: null, name: " " });
}
function YD() {
  switch (this.tokenType) {
    case mr:
      return this.AttributeSelector();
    case S:
      return this.IdSelector();
    case d:
      if (this.lookupType(1) === d) return this.PseudoElementSelector();else
      return this.PseudoClassSelector();
    case w:
      return this.TypeSelector();
    case U:
    case y:
      return this.Percentage();
    case q:
      if (this.charCodeAt(this.tokenStart) === Cx)
      this.error("Identifier is expected", this.tokenStart + 1);
      break;
    case P:{
        switch (this.charCodeAt(this.tokenStart)) {
          case XD:
          case WD:
          case LD:
          case qD:
            return this.Combinator();
          case Cx:
            return this.ClassSelector();
          case PD:
          case KD:
            return this.TypeSelector();
          case UD:
            return this.IdSelector();
          case JD:
            return this.NestingSelector();
        }
        break;
      }
  }
}
var Tx = { onWhiteSpace: VD, getNode: YD };
function Xu() {
  return this.createSingleNodeList(this.Raw(null, !1));
}
function qu() {
  let r = this.createList();
  if (
  this.skipSC(),
  r.push(this.Identifier()),
  this.skipSC(),
  this.tokenType === ir)
  {
    r.push(this.Operator());
    let t = this.tokenIndex,
      i = this.parseCustomProperty ?
      this.Value(null) :
      this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !1);
    if (i.type === "Value" && i.children.isEmpty) {
      for (let o = t - this.tokenIndex; o <= 0; o++)
      if (this.lookupType(o) === Y) {
        i.children.appendData({ type: "WhiteSpace", loc: null, value: " " });
        break;
      }
    }
    r.push(i);
  }
  return r;
}
function dx(r) {
  return (
    r !== null &&
    r.type === "Operator" && (
    r.value[r.value.length - 1] === "-" || r.value[r.value.length - 1] === "+"));

}
var sx = {
  getNode: Bn,
  onWhiteSpace(r, t) {
    if (dx(r)) r.value = " " + r.value;
    if (dx(t.last)) t.last.value += " ";
  },
  expression: Xu,
  var: qu
};
var ED = new Set(["none", "and", "not", "or"]),
  rf = {
    parse: {
      prelude() {
        let r = this.createList();
        if (this.tokenType === w) {
          let t = this.substring(this.tokenStart, this.tokenEnd);
          if (!ED.has(t.toLowerCase())) r.push(this.Identifier());
        }
        return r.push(this.Condition("container")), r;
      },
      block(r = !1) {
        return this.Block(r);
      }
    }
  };
var tf = {
  parse: {
    prelude: null,
    block() {
      return this.Block(!0);
    }
  }
};
function Ku(r, t) {
  return this.parseWithFallback(
    () => {
      try {
        return r.call(this);
      } finally {
        if (this.skipSC(), this.lookupNonWSType(0) !== j) this.error();
      }
    },
    t || (() => this.Raw(null, !0))
  );
}
var nf = {
    layer() {
      this.skipSC();
      let r = this.createList(),
        t = Ku.call(this, this.Layer);
      if (t.type !== "Raw" || t.value !== "") r.push(t);
      return r;
    },
    supports() {
      this.skipSC();
      let r = this.createList(),
        t = Ku.call(this, this.Declaration, () =>
        Ku.call(this, () => this.Condition("supports"))
        );
      if (t.type !== "Raw" || t.value !== "") r.push(t);
      return r;
    }
  },
  of = {
    parse: {
      prelude() {
        let r = this.createList();
        switch (this.tokenType) {
          case gr:
            r.push(this.String());
            break;
          case er:
          case k:
            r.push(this.Url());
            break;
          default:
            this.error("String or url() is expected");
        }
        if (
        this.skipSC(),
        this.tokenType === w &&
        this.cmpStr(this.tokenStart, this.tokenEnd, "layer"))

        r.push(this.Identifier());else
        if (
        this.tokenType === k &&
        this.cmpStr(this.tokenStart, this.tokenEnd, "layer("))

        r.push(this.Function(null, nf));
        if (
        this.skipSC(),
        this.tokenType === k &&
        this.cmpStr(this.tokenStart, this.tokenEnd, "supports("))

        r.push(this.Function(null, nf));
        if (this.lookupNonWSType(0) === w || this.lookupNonWSType(0) === K)
        r.push(this.MediaQueryList());
        return r;
      },
      block: null
    }
  };
var ef = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.LayerList());
    },
    block() {
      return this.Block(!1);
    }
  }
};
var lf = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.MediaQueryList());
    },
    block(r = !1) {
      return this.Block(r);
    }
  }
};
var cf = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.SelectorList());
    },
    block() {
      return this.Block(!0);
    }
  }
};
var uf = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.SelectorList());
    },
    block() {
      return this.Block(!0);
    }
  }
};
var gf = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.Scope());
    },
    block(r = !1) {
      return this.Block(r);
    }
  }
};
var mf = {
  parse: {
    prelude: null,
    block(r = !1) {
      return this.Block(r);
    }
  }
};
var bf = {
  parse: {
    prelude() {
      return this.createSingleNodeList(this.Condition("supports"));
    },
    block(r = !1) {
      return this.Block(r);
    }
  }
};
var vf = {
  container: rf,
  "font-face": tf,
  import: of,
  layer: ef,
  media: lf,
  nest: cf,
  page: uf,
  scope: gf,
  "starting-style": mf,
  supports: bf
};
function hf() {
  let r = this.createList();
  this.skipSC();
  r: while (!this.eof) {
    switch (this.tokenType) {
      case w:
        r.push(this.Identifier());
        break;
      case gr:
        r.push(this.String());
        break;
      case ir:
        r.push(this.Operator());
        break;
      case j:
        break r;
      default:
        this.error("Identifier, string or comma is expected");
    }
    this.skipSC();
  }
  return r;
}
var Jt = {
    parse() {
      return this.createSingleNodeList(this.SelectorList());
    }
  },
  Lu = {
    parse() {
      return this.createSingleNodeList(this.Selector());
    }
  },
  QD = {
    parse() {
      return this.createSingleNodeList(this.Identifier());
    }
  },
  FD = { parse: hf },
  $o = {
    parse() {
      return this.createSingleNodeList(this.Nth());
    }
  },
  $f = {
    dir: QD,
    has: Jt,
    lang: FD,
    matches: Jt,
    is: Jt,
    "-moz-any": Jt,
    "-webkit-any": Jt,
    where: Jt,
    not: Jt,
    "nth-child": $o,
    "nth-last-child": $o,
    "nth-last-of-type": $o,
    "nth-of-type": $o,
    slotted: Lu,
    host: Lu,
    "host-context": Lu
  };
var Vu = {};
I(Vu, {
  WhiteSpace: () => Ju,
  Value: () => ku,
  Url: () => Ou,
  UnicodeRange: () => _u,
  TypeSelector: () => zu,
  SupportsDeclaration: () => xu,
  StyleSheet: () => hu,
  String: () => bu,
  SelectorList: () => uu,
  Selector: () => lu,
  Scope: () => ou,
  Rule: () => nu,
  Raw: () => ru,
  Ratio: () => dc,
  PseudoElementSelector: () => Cc,
  PseudoClassSelector: () => Mc,
  Percentage: () => Hc,
  Parentheses: () => yc,
  Operator: () => Nc,
  Number: () => Sc,
  Nth: () => Qc,
  NestingSelector: () => Yc,
  MediaQueryList: () => Lc,
  MediaQuery: () => Wc,
  LayerList: () => Xc,
  Layer: () => Jc,
  Identifier: () => Oc,
  IdSelector: () => kc,
  Hash: () => Dc,
  GeneralEnclosed: () => pc,
  Function: () => zc,
  FeatureRange: () => fc,
  FeatureFunction: () => hc,
  Feature: () => bc,
  Dimension: () => gc,
  DeclarationList: () => cc,
  Declaration: () => oc,
  Condition: () => nc,
  Comment: () => rc,
  Combinator: () => dl,
  ClassSelector: () => Cl,
  CDO: () => Ml,
  CDC: () => Hl,
  Brackets: () => yl,
  Block: () => Nl,
  AttributeSelector: () => Sl,
  AtrulePrelude: () => El,
  Atrule: () => Vl,
  AnPlusB: () => Kl
});
var xf = {
  parseContext: {
    default: "StyleSheet",
    stylesheet: "StyleSheet",
    atrule: "Atrule",
    atrulePrelude(r) {
      return this.AtrulePrelude(r.atrule ? String(r.atrule) : null);
    },
    mediaQueryList: "MediaQueryList",
    mediaQuery: "MediaQuery",
    condition(r) {
      return this.Condition(r.kind);
    },
    rule: "Rule",
    selectorList: "SelectorList",
    selector: "Selector",
    block() {
      return this.Block(!0);
    },
    declarationList: "DeclarationList",
    declaration: "Declaration",
    value: "Value"
  },
  features: {
    supports: {
      selector() {
        return this.Selector();
      }
    },
    container: {
      style() {
        return this.Declaration();
      }
    }
  },
  scope: Wu,
  atrule: vf,
  pseudo: $f,
  node: Vu
};
var ff = { node: Nn };
var wf = ql({ ...Rx, ...xf, ...ff });
var {
  tokenize: yJ,
  parse: Yu,
  generate: Eu,
  lexer: AJ,
  createLexer: HJ,
  walk: xo,
  find: RJ,
  findLast: MJ,
  findAll: ZJ,
  toPlainObject: CJ,
  fromPlainObject: TJ,
  fork: dJ
} = wf;
class rn {
  static instance;
  constructor() {}
  injectDefaultStyles() {
    try {
      let r = document.createElement("style");
      r.id = "onlook-stylesheet",
      r.textContent = `
            [${"data-onlook-editing-text"}="true"] {
                opacity: 0;
            }
            nextjs-portal {
                display: none;
            }
        `,
      document.head.appendChild(r);
    } catch (r) {
      console.warn("Error injecting default styles", r);
    }
  }
  static getInstance() {
    if (!rn.instance) rn.instance = new rn();
    return rn.instance;
  }
  get stylesheet() {
    let r =
    document.getElementById("onlook-stylesheet") || this.createStylesheet();
    return r.textContent = r.textContent || "", Yu(r.textContent);
  }
  set stylesheet(r) {
    let t =
    document.getElementById("onlook-stylesheet") || this.createStylesheet();
    t.textContent = Eu(r);
  }
  createStylesheet() {
    let r = document.createElement("style");
    return r.id = "onlook-stylesheet", document.head.appendChild(r), r;
  }
  find(r, t) {
    let i = [];
    return (
      xo(r, {
        visit: "Rule",
        enter: (o) => {
          if (o.type === "Rule") {
            let n = o;
            if (n.prelude.type === "SelectorList")
            n.prelude.children.forEach((e) => {
              if (Eu(e) === t) i.push(o);
            });
          }
        }
      }),
      i);

  }
  updateStyle(r, t) {
    let i = Ye(r, !1),
      o = this.stylesheet;
    for (let [n, e] of Object.entries(t)) {
      let l = this.jsToCssProperty(n),
        u = this.find(o, i);
      if (!u.length) this.addRule(o, i, l, e.value);else

      u.forEach((g) => {
        if (g.type === "Rule") this.updateRule(g, l, e.value);
      });
    }
    this.stylesheet = o;
  }
  addRule(r, t, i, o) {
    let n = {
      type: "Rule",
      prelude: {
        type: "SelectorList",
        children: [
        { type: "Selector", children: [{ type: "TypeSelector", name: t }] }]

      },
      block: {
        type: "Block",
        children: [
        {
          type: "Declaration",
          property: i,
          value: { type: "Raw", value: o }
        }]

      }
    };
    if (r.type === "StyleSheet") r.children.push(n);
  }
  updateRule(r, t, i) {
    let o = !1;
    if (
    xo(r.block, {
      visit: "Declaration",
      enter: (n) => {
        if (n.property === t) {
          if (n.value = { type: "Raw", value: i }, i === "")
          r.block.children = r.block.children.filter(
            (e) => e.property !== t
          );
          o = !0;
        }
      }
    }),
    !o)

    if (i === "")
    r.block.children = r.block.children.filter((n) => n.property !== t);else

    r.block.children.push({
      type: "Declaration",
      property: t,
      value: { type: "Raw", value: i },
      important: !1
    });
  }
  getJsStyle(r) {
    let t = this.stylesheet,
      i = this.find(t, r),
      o = {};
    if (!i.length) return o;
    return (
      i.forEach((n) => {
        if (n.type === "Rule")
        xo(n, {
          visit: "Declaration",
          enter: (e) => {
            o[this.cssToJsProperty(e.property)] = e.value.value;
          }
        });
      }),
      o);

  }
  jsToCssProperty(r) {
    if (!r) return "";
    return r.replace(/([A-Z])/g, "-$1").toLowerCase();
  }
  cssToJsProperty(r) {
    if (!r) return "";
    return r.replace(/-([a-z])/g, (t) => t[1]?.toUpperCase() ?? "");
  }
  removeStyles(r, t) {
    let i = Ye(r, !1),
      o = this.stylesheet;
    this.find(o, i).forEach((e) => {
      if (e.type === "Rule") {
        let l = t.map((u) => this.jsToCssProperty(u));
        e.block.children = e.block.children.filter(
          (u) => !l.includes(u.property)
        );
      }
    }),
    this.stylesheet = o;
  }
  clear() {
    this.stylesheet = Yu("");
  }
}
var ot = rn.getInstance();
function zf(r, t) {
  return ot.updateStyle(r, t.updated), Vi(r, !0);
}
function af(r, t) {
  ot.updateStyle(r, { backgroundImage: { value: `url(${t})`, type: "value" } });
}
function pf(r) {
  ot.updateStyle(r, { backgroundImage: { value: "none", type: "value" } });
}
function GD(r, t) {
  let i = Array.from(r.children);
  if (i.length === 0) return 0;
  let o = 0,
    n = 1 / 0;
  i.forEach((u, g) => {
    let c = u.getBoundingClientRect(),
      m = c.top + c.height / 2,
      v = Math.abs(t - m);
    if (v < n) n = v, o = g;
  });
  let e = i[o]?.getBoundingClientRect();
  if (!e) return 0;
  let l = e.top + e.height / 2;
  return t > l ? o + 1 : o;
}
function _f(r, t) {
  let i = ND(r, t);
  if (!i) return null;
  let o = window.getComputedStyle(i).display;
  if (o === "flex" || o === "grid") {
    let e = GD(i, t);
    return {
      type: "index",
      targetDomId: Pr(i),
      targetOid: Nr(i) || Gr(i) || null,
      index: e,
      originalIndex: e
    };
  }
  return {
    type: "append",
    targetDomId: Pr(i),
    targetOid: Nr(i) || Gr(i) || null
  };
}
function ND(r, t) {
  let i = K$(r, t);
  if (!i) return null;
  let o = !0;
  while (i && o)
  if (o = j$.has(i.tagName.toLowerCase()), o) i = i.parentElement;
  return i;
}
function Df(r, t) {
  let i = G(t.targetDomId);
  if (!i) {
    console.warn(`Target element not found: ${t.targetDomId}`);
    return;
  }
  let o = jf(r);
  switch (t.type) {
    case "append":
      i.appendChild(o);
      break;
    case "prepend":
      i.prepend(o);
      break;
    case "index":
      if (t.index === void 0 || t.index < 0) {
        console.warn(`Invalid index: ${t.index}`);
        return;
      }
      if (t.index >= i.children.length) i.appendChild(o);else
      i.insertBefore(o, i.children.item(t.index));
      break;
    default:
      console.warn(`Invalid position: ${t}`), Qe(t);
  }
  let n = lr(o, !0),
    e = zr(o);
  return { domEl: n, newMap: e };
}
function jf(r) {
  let t = document.createElement(r.tagName);
  t.setAttribute("data-onlook-inserted", "true");
  for (let [i, o] of Object.entries(r.attributes)) t.setAttribute(i, o);
  if (r.textContent !== null && r.textContent !== void 0)
  t.textContent = r.textContent;
  for (let [i, o] of Object.entries(r.styles))
  t.style.setProperty(ot.jsToCssProperty(i), o);
  for (let i of r.children) {
    let o = jf(i);
    t.appendChild(o);
  }
  return t;
}
function Of(r) {
  let t = G(r.targetDomId);
  if (!t)
  return console.warn(`Target element not found: ${r.targetDomId}`), null;
  let i = null;
  switch (r.type) {
    case "append":
      i = t.lastElementChild;
      break;
    case "prepend":
      i = t.firstElementChild;
      break;
    case "index":
      if (r.index !== -1) i = t.children.item(r.index);else
      return console.warn(`Invalid index: ${r.index}`), null;
      break;
    default:
      console.warn(`Invalid position: ${r}`), Qe(r);
  }
  if (i) {
    let o = lr(i, !0);
    i.style.display = "none";
    let n = t.parentElement ? zr(t.parentElement) : null;
    return { domEl: o, newMap: n };
  } else
  return (
    console.warn("No element found to remove at the specified location"),
    null);

}
function If(r, t) {
  let i = G(r);
  if (!i) return console.warn("Element not found for domId:", r), null;
  let o = L$(i);
  if (!o) return console.warn("Failed to get location for element:", i), null;
  let n = Yi(r);
  if (!n)
  return console.warn("Failed to get action element for element:", i), null;
  return {
    type: "remove-element",
    targets: [{ frameId: t, domId: n.domId, oid: n.oid }],
    location: o,
    element: n,
    editText: !1,
    pasteParams: null,
    codeBlock: null
  };
}
function kf(r, t) {
  let i = G(r);
  if (!i) return console.warn(`Move element not found: ${r}`), null;
  let o = BD(i, t);
  if (!o) return console.warn(`Failed to move element: ${r}`), null;
  let n = lr(o, !0),
    e = o.parentElement ? zr(o.parentElement) : null;
  return { domEl: n, newMap: e };
}
function Uf(r) {
  let t = G(r);
  if (!t) return console.warn(`Element not found: ${r}`), -1;
  return Array.from(t.parentElement?.children || []).
  filter(Dt).
  indexOf(t);
}
function BD(r, t) {
  let i = r.parentElement;
  if (!i) {
    console.warn("Parent not found");
    return;
  }
  if (i.removeChild(r), t >= i.children.length) return i.appendChild(r), r;
  let o = i.children[t];
  return i.insertBefore(r, o ?? null), r;
}
function fo(r) {
  if (!r || !r.children || r.children.length < 2) return "vertical";
  let t = Array.from(r.children),
    i = t[0],
    o = t[1],
    n = i?.getBoundingClientRect(),
    e = o?.getBoundingClientRect();
  if (n && e && Math.abs(n.left - e.left) < Math.abs(n.top - e.top))
  return "vertical";else
  return "horizontal";
}
function Jf(r, t, i, o) {
  if (r.length === 0) return 0;
  let n = r.map((e) => {
    let l = e.getBoundingClientRect();
    return { x: l.left + l.width / 2, y: l.top + l.height / 2 };
  });
  if (o === "horizontal")
  for (let e = 0; e < n.length; e++) {
    let l = n[e];
    if (l && t < l.x) return e;
  } else

  for (let e = 0; e < n.length; e++) {
    let l = n[e];
    if (l && i < l.y) return e;
  }
  return r.length;
}
function Pf(r, t, i, o) {
  let n = r.getBoundingClientRect(),
    e = window.getComputedStyle(r),
    l = e.gridTemplateColumns.split(" ").length,
    u = e.gridTemplateRows.split(" ").length,
    g = n.width / l,
    c = n.height / u,
    m = Math.floor((i - n.left) / g),
    h = Math.floor((o - n.top) / c) * l + m;
  return Math.min(Math.max(h, 0), t.length);
}
function Xf(r) {
  let t = document.createElement("div"),
    i = window.getComputedStyle(r),
    o = r.className;
  t.id = "onlook-drag-stub",
  t.style.width = i.width,
  t.style.height = i.height,
  t.style.margin = i.margin,
  t.style.padding = i.padding,
  t.style.borderRadius = i.borderRadius,
  t.style.backgroundColor = "rgba(0, 0, 0, 0.2)",
  t.style.display = "none",
  t.className = o,
  document.body.appendChild(t);
}
function qf(r, t, i) {
  let o = document.getElementById("onlook-drag-stub");
  if (!o) return;
  let n = r.parentElement;
  if (!n) return;
  let e = r.getAttribute("data-onlook-drag-direction");
  if (!e) e = fo(n);
  let l = window.getComputedStyle(n),
    u = l.display === "grid";
  if (
  !u &&
  l.display === "flex" && (
  l.flexDirection === "row" || l.flexDirection === ""))

  e = "horizontal";
  let c = Array.from(n.children).filter((v) => v !== r && v !== o),
    m;
  if (u) m = Pf(n, c, t, i);else
  m = Jf(c, t, i, e);
  if (o.remove(), m >= c.length) n.appendChild(o);else
  n.insertBefore(o, c[m] ?? null);
  o.style.display = "block";
}
function Qu() {
  let r = document.getElementById("onlook-drag-stub");
  if (!r) return;
  r.remove();
}
function Wf(r, t) {
  let i = document.getElementById("onlook-drag-stub");
  if (!i) return -1;
  return Array.from(r.children).
  filter((n) => n !== t).
  indexOf(i);
}
function Kf(r) {
  let t = G(r);
  if (!t) return console.warn(`Start drag element not found: ${r}`), null;
  let i = t.parentElement;
  if (!i) return console.warn("Start drag parent not found"), null;
  let n = Array.from(i.children).filter(Dt).indexOf(t),
    e = window.getComputedStyle(t);
  if (yD(t), e.position !== "absolute") Xf(t);
  let l = AD(t),
    u = t.getBoundingClientRect(),
    g =
    e.position === "absolute" ?
    { x: l.left, y: l.top } :
    { x: l.left - u.left, y: l.top - u.top };
  return (
    t.setAttribute(
      "data-onlook-drag-start-position",
      JSON.stringify({ ...l, offset: g })
    ),
    n);

}
function Lf(r, t, i, o) {
  let n = G(r);
  if (!n) {
    console.warn("Dragging element not found");
    return;
  }
  let e = n.parentElement;
  if (e) {
    let l = JSON.parse(
        n.getAttribute("data-onlook-drag-start-position") || "{}"
      ),
      u = e.getBoundingClientRect(),
      g = t - u.left - (o.x - l.offset.x),
      c = i - u.top - (o.y - l.offset.y);
    n.style.left = `${g}px`, n.style.top = `${c}px`;
  }
  n.style.transform = "none";
}
function Vf(r, t, i, o, n) {
  let e = G(r);
  if (!e) {
    console.warn("Dragging element not found");
    return;
  }
  if (!e.style.transition)
  e.style.transition = "transform 0.05s cubic-bezier(0.2, 0, 0, 1)";
  let l = JSON.parse(e.getAttribute("data-onlook-drag-start-position") || "{}");
  if (e.style.position !== "fixed") {
    let g = window.getComputedStyle(e);
    e.style.position = "fixed",
    e.style.width = g.width,
    e.style.height = g.height,
    e.style.left = `${l.left}px`,
    e.style.top = `${l.top}px`;
  }
  if (e.style.transform = `translate(${t}px, ${i}px)`, e.parentElement)
  qf(e, o, n);
}
function Yf(r) {
  let t = G(r);
  if (!t) return console.warn("End drag element not found"), null;
  let i = window.getComputedStyle(t);
  return Qf(t), Pr(t), { left: i.left, top: i.top };
}
function Ef(r) {
  let t = G(r);
  if (!t) return console.warn("End drag element not found"), Su(), null;
  let i = t.parentElement;
  if (!i) return console.warn("End drag parent not found"), Fu(t), null;
  let o = Wf(i, t);
  if (Fu(t), Qu(), o === -1) return null;
  let n = Array.from(i.children).indexOf(t);
  if (o === n) return null;
  return { newIndex: o, child: lr(t, !1), parent: lr(i, !1) };
}
function yD(r) {
  if (r.getAttribute("data-onlook-drag-saved-style")) return;
  let i = {
    position: r.style.position,
    transform: r.style.transform,
    width: r.style.width,
    height: r.style.height,
    left: r.style.left,
    top: r.style.top
  };
  if (
  r.setAttribute("data-onlook-drag-saved-style", JSON.stringify(i)),
  r.setAttribute("data-onlook-dragging", "true"),
  r.style.zIndex = "1000",
  r.getAttribute("data-onlook-drag-direction") !== null)
  {
    let o = r.parentElement;
    if (o) {
      let n = fo(o);
      r.setAttribute("data-onlook-drag-direction", n);
    }
  }
}
function Fu(r) {
  Li(r), Qf(r), Pr(r);
}
function Qf(r) {
  r.removeAttribute("data-onlook-drag-saved-style"),
  r.removeAttribute("data-onlook-dragging"),
  r.removeAttribute("data-onlook-drag-direction"),
  r.removeAttribute("data-onlook-drag-start-position");
}
function AD(r) {
  let t = r.getBoundingClientRect();
  return { left: t.left + window.scrollX, top: t.top + window.scrollY };
}
function Su() {
  let r = document.querySelectorAll(`[${"data-onlook-dragging"}]`);
  for (let t of Array.from(r)) Fu(t);
  Qu();
}
function Ff(r) {
  let t = G(r);
  if (!t)
  return (
    console.warn("Start editing text failed. No element for selector:", r),
    null);

  let i = Array.from(t.childNodes).filter(
      (l) => l.nodeType !== Node.COMMENT_NODE
    ),
    o = null,
    n = i.every(
      (l) =>
      l.nodeType === Node.TEXT_NODE ||
      l.nodeType === Node.ELEMENT_NODE && l.tagName.toLowerCase() === "br"
    );
  if (i.length === 0) o = t;else
  if (i.length === 1 && i[0]?.nodeType === Node.TEXT_NODE) o = t;else
  if (n) o = t;
  if (!o)
  return (
    console.warn(
      "Start editing text failed. No target element found for selector:",
      r
    ),
    null);

  let e = Bf(t);
  return Nf(o), { originalContent: e };
}
function Sf(r, t) {
  let i = G(r);
  if (!i)
  return (
    console.warn("Edit text failed. No element for selector:", r),
    null);

  return Nf(i), MD(i, t), { domEl: lr(i, !0), newMap: zr(i) };
}
function Gf(r) {
  let t = G(r);
  if (!t)
  return (
    console.warn("Stop editing text failed. No element for selector:", r),
    null);

  return HD(t), { newContent: Bf(t), domEl: lr(t, !0) };
}
function Nf(r) {
  r.setAttribute("data-onlook-editing-text", "true");
}
function HD(r) {
  Li(r), RD(r);
}
function RD(r) {
  r.removeAttribute("data-onlook-editing-text");
}
function MD(r, t) {
  let i = t.replace(/\n/g, "<br>");
  r.innerHTML = i;
}
function Bf(r) {
  let t = r.innerHTML;
  t = t.replace(
    /<br\s*\/?>/gi,
    `
`
  ),
  t = t.replace(/<[^>]*>/g, "");
  let i = document.createElement("textarea");
  return i.innerHTML = t, i.value;
}
function yf(r) {
  return !0;
}
function Hf() {
  let r = document.body,
    t = { childList: !0, subtree: !0 };
  new MutationObserver((o) => {
    let n = new Map(),
      e = new Map();
    for (let l of o)
    if (l.type === "childList") {
      let u = l.target;
      l.addedNodes.forEach((g) => {
        let c = g;
        if (
        g.nodeType === Node.ELEMENT_NODE &&
        c.hasAttribute("data-odid") &&
        !Af(c))
        {
          if (ZD(c), u) {
            let m = zr(u);
            if (m) n = new Map([...n, ...m]);
          }
        }
      }),
      l.removedNodes.forEach((g) => {
        let c = g;
        if (
        g.nodeType === Node.ELEMENT_NODE &&
        c.hasAttribute("data-odid") &&
        !Af(c))
        {
          if (u) {
            let m = zr(u);
            if (m) e = new Map([...e, ...m]);
          }
        }
      });
    }
    if (n.size > 0 || e.size > 0) {
      if (_r)
      _r.onWindowMutated({
        added: Object.fromEntries(n),
        removed: Object.fromEntries(e)
      }).catch((l) => {
        console.error("Failed to send window mutation event:", l);
      });
    }
  }).observe(r, t);
}
function Rf() {
  function r() {
    if (_r)
    _r.onWindowResized().catch((t) => {
      console.error("Failed to send window resize event:", t);
    });
  }
  window.addEventListener("resize", r);
}
function Af(r) {
  if (r.id === "onlook-drag-stub") return !0;
  if (r.getAttribute("data-onlook-inserted")) return !0;
  return !1;
}
function ZD(r) {
  let t = r.getAttribute("data-oid");
  if (!t) return;
  document.
  querySelectorAll(`[${"data-oid"}="${t}"][${"data-onlook-inserted"}]`).
  forEach((i) => {
    [
    "data-odid",
    "data-onlook-drag-saved-style",
    "data-onlook-editing-text",
    "data-oiid"].
    forEach((n) => {
      let e = i.getAttribute(n);
      if (e) r.setAttribute(n, e);
    }),
    i.remove();
  });
}
function Mf() {
  Hf(), Rf();
}
function Gu() {
  Mf(), CD(), ot.injectDefaultStyles();
}
var tn = null;
function CD() {
  if (tn !== null) clearInterval(tn), tn = null;
  let r = setInterval(() => {
    try {
      if (Ki() !== null) clearInterval(r), tn = null;
    } catch (t) {
      clearInterval(r),
      tn = null,
      console.warn("Error in keepDomUpdated:", t);
    }
  }, 5000);
  tn = r;
}
var TD = setInterval(() => {
  if (
  window.onerror = function r(t, i, o) {
    console.log(`Unhandled error: ${t} ${i} ${o}`);
  },
  window?.document?.body)
  {
    clearInterval(TD);
    try {
      Gu();
    } catch (r) {
      console.log("Error in documentBodyInit:", r);
    }
  }
}, 300);
async function Cf() {
  try {
    let { innerWidth: r, innerHeight: t } = window,
      i = document.createElement("canvas"),
      o = i.getContext("2d");
    if (!o) throw new Error("Failed to get canvas context");
    if (
    i.width = r,
    i.height = t,
    navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)

    try {
      let e = await navigator.mediaDevices.getDisplayMedia({
          video: { width: r, height: t }
        }),
        l = document.createElement("video");
      l.srcObject = e,
      l.autoplay = !0,
      l.muted = !0,
      await new Promise((g) => {
        l.onloadedmetadata = () => {
          l.play(),
          l.oncanplay = () => {
            o.drawImage(l, 0, 0, r, t),
            e.getTracks().forEach((c) => c.stop()),
            g();
          };
        };
      });
      let u = await Zf(i);
      return (
        console.log(
          `Screenshot captured - Size: ~${Math.round(u.length * 0.75 / 1024)} KB`
        ),
        { mimeType: "image/jpeg", data: u });

    } catch (e) {
      console.log(
        "getDisplayMedia failed, falling back to DOM rendering:",
        e
      );
    }
    await dD(o, r, t);
    let n = await Zf(i);
    return (
      console.log(
        `DOM screenshot captured - Size: ~${Math.round(n.length * 0.75 / 1024)} KB`
      ),
      { mimeType: "image/jpeg", data: n });

  } catch (r) {
    console.error("Failed to capture screenshot:", r);
    let t = document.createElement("canvas"),
      i = t.getContext("2d");
    if (i)
    return (
      t.width = 400,
      t.height = 300,
      i.fillStyle = "#ffffff",
      i.fillRect(0, 0, 400, 300),
      i.fillStyle = "#ff0000",
      i.font = "14px Arial, sans-serif",
      i.textAlign = "center",
      i.fillText("Screenshot unavailable", 200, 150),
      { mimeType: "image/jpeg", data: t.toDataURL("image/jpeg", 0.8) });

    throw r;
  }
}
async function Zf(r) {
  let o = [0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3],
    n = [1, 0.8, 0.6, 0.5, 0.4, 0.3];
  for (let u of n) {
    let g = r;
    if (u < 1) {
      g = document.createElement("canvas");
      let c = g.getContext("2d");
      if (!c) continue;
      g.width = r.width * u,
      g.height = r.height * u,
      c.drawImage(r, 0, 0, g.width, g.height);
    }
    for (let c of o) {
      let m = g.toDataURL("image/jpeg", c);
      if (m.length <= 3932160) return m;
    }
  }
  let e = document.createElement("canvas"),
    l = e.getContext("2d");
  if (l)
  return (
    e.width = r.width * 0.2,
    e.height = r.height * 0.2,
    l.drawImage(r, 0, 0, e.width, e.height),
    e.toDataURL("image/jpeg", 0.2));

  return r.toDataURL("image/jpeg", 0.1);
}
async function dD(r, t, i) {
  r.fillStyle = "#ffffff", r.fillRect(0, 0, t, i);
  let o = document.querySelectorAll("*"),
    n = [];
  for (let e of o)
  if (e instanceof HTMLElement) {
    let l = e.getBoundingClientRect(),
      u = window.getComputedStyle(e);
    if (
    l.width > 0 &&
    l.height > 0 &&
    l.left < t &&
    l.top < i &&
    l.right > 0 &&
    l.bottom > 0 &&
    u.visibility !== "hidden" &&
    u.display !== "none" &&
    parseFloat(u.opacity) > 0)

    n.push({ element: e, rect: l, styles: u });
  }
  n.sort((e, l) => {
    let u = parseInt(e.styles.zIndex) || 0,
      g = parseInt(l.styles.zIndex) || 0;
    return u - g;
  });
  for (let { element: e, rect: l, styles: u } of n)
  try {
    await sD(r, e, l, u);
  } catch (g) {
    console.warn("Failed to render element:", e, g);
  }
}
async function sD(r, t, i, o) {
  let { left: n, top: e, width: l, height: u } = i;
  if (l < 1 || u < 1 || n > window.innerWidth || e > window.innerHeight) return;
  let g = o.backgroundColor;
  if (g && g !== "rgba(0, 0, 0, 0)" && g !== "transparent")
  r.fillStyle = g, r.fillRect(n, e, l, u);
  let c = parseFloat(o.borderWidth) || 0,
    m = o.borderColor;
  if (c > 0 && m && m !== "transparent")
  r.strokeStyle = m, r.lineWidth = c, r.strokeRect(n, e, l, u);
  if (t.textContent && t.children.length === 0) {
    let v = t.textContent.trim();
    if (v) {
      let h = parseFloat(o.fontSize) || 16,
        b = o.fontFamily || "Arial, sans-serif",
        f = o.color || "#000000";
      r.fillStyle = f,
      r.font = `${h}px ${b}`,
      r.textAlign = "left",
      r.textBaseline = "top";
      let D = v.split(" "),
        O = "",
        _ = e + 2,
        J = h * 1.2;
      for (let V of D) {
        let X = O + V + " ";
        if (r.measureText(X).width > l - 4 && O !== "") {
          if (r.fillText(O, n + 2, _), O = V + " ", _ += J, _ > e + u)
          break;
        } else O = X;
      }
      if (O && _ <= e + u) r.fillText(O, n + 2, _);
    }
  }
  if (t instanceof HTMLImageElement && t.complete && t.naturalWidth > 0)
  try {
    r.drawImage(t, n, e, l, u);
  } catch (v) {
    r.fillStyle = "#f0f0f0",
    r.fillRect(n, e, l, u),
    r.fillStyle = "#999999",
    r.font = "12px Arial, sans-serif",
    r.textAlign = "center",
    r.fillText("Image", n + l / 2, e + u / 2);
  }
}
var rr = {};
I(rr, {
  xid: () => SI,
  void: () => mk,
  uuidv7: () => WI,
  uuidv6: () => qI,
  uuidv4: () => XI,
  uuid: () => PI,
  util: () => p,
  url: () => KI,
  uppercase: () => fi,
  unknown: () => xn,
  union: () => _h,
  undefined: () => uk,
  ulid: () => FI,
  uint64: () => lk,
  uint32: () => ik,
  tuple: () => Hw,
  trim: () => Di,
  treeifyError: () => du,
  transform: () => Oh,
  toUpperCase: () => Oi,
  toLowerCase: () => ji,
  toJSONSchema: () => Yv,
  templateLiteral: () => Uk,
  symbol: () => ck,
  superRefine: () => w4,
  success: () => Ok,
  stringbool: () => Kk,
  stringFormat: () => CI,
  string: () => sv,
  strictObject: () => $k,
  startsWith: () => zi,
  size: () => hi,
  setErrorMap: () => Ek,
  set: () => ak,
  safeParseAsync: () => yv,
  safeParse: () => Bv,
  safeEncodeAsync: () => Tv,
  safeEncode: () => Zv,
  safeDecodeAsync: () => dv,
  safeDecode: () => Cv,
  registry: () => No,
  regexes: () => Yr,
  regex: () => $i,
  refine: () => f4,
  record: () => Rw,
  readonly: () => m4,
  property: () => Pv,
  promise: () => Jk,
  prettifyError: () => su,
  preprocess: () => Vk,
  prefault: () => i4,
  positive: () => Iv,
  pipe: () => ae,
  partialRecord: () => wk,
  parseAsync: () => Nv,
  parse: () => Gv,
  overwrite: () => ct,
  optional: () => we,
  object: () => hk,
  number: () => qw,
  nullish: () => jk,
  nullable: () => ze,
  null: () => Yw,
  normalize: () => _i,
  nonpositive: () => Uv,
  nonoptional: () => o4,
  nonnegative: () => Jv,
  never: () => ah,
  negative: () => kv,
  nativeEnum: () => pk,
  nanoid: () => YI,
  nan: () => Ik,
  multipleOf: () => Kt,
  minSize: () => Lt,
  minLength: () => _t,
  mime: () => pi,
  maxSize: () => bn,
  maxLength: () => vn,
  map: () => zk,
  lte: () => Er,
  lt: () => et,
  lowercase: () => xi,
  looseObject: () => xk,
  locales: () => gi,
  literal: () => _k,
  length: () => hn,
  lazy: () => h4,
  ksuid: () => GI,
  keyof: () => vk,
  jwt: () => ZI,
  json: () => Lk,
  iso: () => xe,
  ipv6: () => BI,
  ipv4: () => NI,
  intersection: () => yw,
  int64: () => ek,
  int32: () => nk,
  int: () => rh,
  instanceof: () => Wk,
  includes: () => wi,
  httpUrl: () => LI,
  hostname: () => TI,
  hex: () => dI,
  hash: () => sI,
  guid: () => JI,
  gte: () => kr,
  gt: () => lt,
  globalRegistry: () => Tr,
  getErrorMap: () => Qk,
  function: () => Pk,
  formatError: () => sn,
  float64: () => tk,
  float32: () => rk,
  flattenError: () => dn,
  file: () => Dk,
  enum: () => jh,
  endsWith: () => ai,
  encodeAsync: () => Rv,
  encode: () => Av,
  emoji: () => VI,
  email: () => UI,
  e164: () => MI,
  discriminatedUnion: () => fk,
  decodeAsync: () => Mv,
  decode: () => Hv,
  date: () => bk,
  custom: () => qk,
  cuid2: () => QI,
  cuid: () => EI,
  core: () => ut,
  config: () => br,
  coerce: () => Xh,
  codec: () => kk,
  clone: () => jr,
  cidrv6: () => AI,
  cidrv4: () => yI,
  check: () => Xk,
  catch: () => c4,
  boolean: () => Ww,
  bigint: () => ok,
  base64url: () => RI,
  base64: () => HI,
  array: () => De,
  any: () => gk,
  _function: () => Pk,
  _default: () => t4,
  _ZodString: () => th,
  ZodXID: () => uh,
  ZodVoid: () => Sw,
  ZodUnknown: () => Qw,
  ZodUnion: () => ph,
  ZodUndefined: () => Lw,
  ZodUUID: () => gt,
  ZodURL: () => pe,
  ZodULID: () => ch,
  ZodType: () => E,
  ZodTuple: () => Aw,
  ZodTransform: () => dw,
  ZodTemplateLiteral: () => b4,
  ZodSymbol: () => Kw,
  ZodSuccess: () => e4,
  ZodStringFormat: () => T,
  ZodString: () => ki,
  ZodSet: () => Zw,
  ZodRecord: () => Dh,
  ZodRealError: () => Ur,
  ZodReadonly: () => g4,
  ZodPromise: () => $4,
  ZodPrefault: () => n4,
  ZodPipe: () => Uh,
  ZodOptional: () => Ih,
  ZodObject: () => je,
  ZodNumberFormat: () => fn,
  ZodNumber: () => Ji,
  ZodNullable: () => sw,
  ZodNull: () => Vw,
  ZodNonOptional: () => kh,
  ZodNever: () => Fw,
  ZodNanoID: () => oh,
  ZodNaN: () => u4,
  ZodMap: () => Mw,
  ZodLiteral: () => Cw,
  ZodLazy: () => v4,
  ZodKSUID: () => gh,
  ZodJWT: () => wh,
  ZodIssueCode: () => Yk,
  ZodIntersection: () => Bw,
  ZodISOTime: () => he,
  ZodISODuration: () => $e,
  ZodISODateTime: () => be,
  ZodISODate: () => ve,
  ZodIPv6: () => bh,
  ZodIPv4: () => mh,
  ZodGUID: () => fe,
  ZodFunction: () => x4,
  ZodFirstPartyTypeKind: () => Ph,
  ZodFile: () => Tw,
  ZodError: () => II,
  ZodEnum: () => Ii,
  ZodEmoji: () => ih,
  ZodEmail: () => nh,
  ZodE164: () => fh,
  ZodDiscriminatedUnion: () => Nw,
  ZodDefault: () => r4,
  ZodDate: () => _e,
  ZodCustomStringFormat: () => Ui,
  ZodCustom: () => Oe,
  ZodCodec: () => Jh,
  ZodCatch: () => l4,
  ZodCUID2: () => lh,
  ZodCUID: () => eh,
  ZodCIDRv6: () => hh,
  ZodCIDRv4: () => vh,
  ZodBoolean: () => Pi,
  ZodBigIntFormat: () => zh,
  ZodBigInt: () => Xi,
  ZodBase64URL: () => xh,
  ZodBase64: () => $h,
  ZodArray: () => Gw,
  ZodAny: () => Ew,
  TimePrecision: () => Tb,
  NEVER: () => Nu,
  $output: () => Rb,
  $input: () => Mb,
  $brand: () => Bu
});
var ut = {};
I(ut, {
  version: () => Zg,
  util: () => p,
  treeifyError: () => du,
  toJSONSchema: () => Yv,
  toDotPath: () => nw,
  safeParseAsync: () => tg,
  safeParse: () => rg,
  safeEncodeAsync: () => Wj,
  safeEncode: () => Xj,
  safeDecodeAsync: () => Kj,
  safeDecode: () => qj,
  registry: () => No,
  regexes: () => Yr,
  prettifyError: () => su,
  parseAsync: () => po,
  parse: () => ao,
  locales: () => gi,
  isValidJWT: () => pw,
  isValidBase64URL: () => aw,
  isValidBase64: () => fm,
  globalRegistry: () => Tr,
  globalConfig: () => yn,
  formatError: () => sn,
  flattenError: () => dn,
  encodeAsync: () => Jj,
  encode: () => kj,
  decodeAsync: () => Pj,
  decode: () => Uj,
  config: () => br,
  clone: () => jr,
  _xid: () => re,
  _void: () => _v,
  _uuidv7: () => Ro,
  _uuidv6: () => Ho,
  _uuidv4: () => Ao,
  _uuid: () => yo,
  _url: () => vi,
  _uppercase: () => fi,
  _unknown: () => av,
  _union: () => nI,
  _undefined: () => fv,
  _ulid: () => so,
  _uint64: () => $v,
  _uint32: () => uv,
  _tuple: () => eI,
  _trim: () => Di,
  _transform: () => vI,
  _toUpperCase: () => Oi,
  _toLowerCase: () => ji,
  _templateLiteral: () => _I,
  _symbol: () => xv,
  _superRefine: () => Lv,
  _success: () => wI,
  _stringbool: () => Vv,
  _stringFormat: () => $n,
  _string: () => Zb,
  _startsWith: () => zi,
  _size: () => hi,
  _set: () => uI,
  _safeParseAsync: () => gn,
  _safeParse: () => un,
  _safeEncodeAsync: () => Uo,
  _safeEncode: () => Io,
  _safeDecodeAsync: () => Jo,
  _safeDecode: () => ko,
  _regex: () => $i,
  _refine: () => Kv,
  _record: () => lI,
  _readonly: () => pI,
  _property: () => Pv,
  _promise: () => jI,
  _positive: () => Iv,
  _pipe: () => aI,
  _parseAsync: () => cn,
  _parse: () => ln,
  _overwrite: () => ct,
  _optional: () => hI,
  _number: () => nv,
  _nullable: () => $I,
  _null: () => wv,
  _normalize: () => _i,
  _nonpositive: () => Uv,
  _nonoptional: () => fI,
  _nonnegative: () => Jv,
  _never: () => pv,
  _negative: () => kv,
  _nativeEnum: () => mI,
  _nanoid: () => Zo,
  _nan: () => Ov,
  _multipleOf: () => Kt,
  _minSize: () => Lt,
  _minLength: () => _t,
  _min: () => kr,
  _mime: () => pi,
  _maxSize: () => bn,
  _maxLength: () => vn,
  _max: () => Er,
  _map: () => cI,
  _lte: () => Er,
  _lt: () => et,
  _lowercase: () => xi,
  _literal: () => bI,
  _length: () => hn,
  _lazy: () => DI,
  _ksuid: () => te,
  _jwt: () => ge,
  _isoTime: () => rv,
  _isoDuration: () => tv,
  _isoDateTime: () => db,
  _isoDate: () => sb,
  _ipv6: () => ie,
  _ipv4: () => ne,
  _intersection: () => oI,
  _int64: () => hv,
  _int32: () => cv,
  _int: () => ov,
  _includes: () => wi,
  _guid: () => bi,
  _gte: () => kr,
  _gt: () => lt,
  _float64: () => lv,
  _float32: () => ev,
  _file: () => qv,
  _enum: () => gI,
  _endsWith: () => ai,
  _encodeAsync: () => jo,
  _encode: () => _o,
  _emoji: () => Mo,
  _email: () => Bo,
  _e164: () => ue,
  _discriminatedUnion: () => iI,
  _default: () => xI,
  _decodeAsync: () => Oo,
  _decode: () => Do,
  _date: () => Dv,
  _custom: () => Wv,
  _cuid2: () => To,
  _cuid: () => Co,
  _coercedString: () => Cb,
  _coercedNumber: () => iv,
  _coercedDate: () => jv,
  _coercedBoolean: () => mv,
  _coercedBigint: () => vv,
  _cidrv6: () => ee,
  _cidrv4: () => oe,
  _check: () => Uw,
  _catch: () => zI,
  _boolean: () => gv,
  _bigint: () => bv,
  _base64url: () => ce,
  _base64: () => le,
  _array: () => Xv,
  _any: () => zv,
  TimePrecision: () => Tb,
  NEVER: () => Nu,
  JSONSchemaGenerator: () => me,
  JSONSchema: () => Jw,
  Doc: () => Wo,
  $output: () => Rb,
  $input: () => Mb,
  $constructor: () => $,
  $brand: () => Bu,
  $ZodXID: () => lm,
  $ZodVoid: () => Xm,
  $ZodUnknown: () => Jm,
  $ZodUnion: () => So,
  $ZodUndefined: () => Im,
  $ZodUUID: () => dg,
  $ZodURL: () => rm,
  $ZodULID: () => em,
  $ZodType: () => L,
  $ZodTuple: () => Go,
  $ZodTransform: () => Nm,
  $ZodTemplateLiteral: () => sm,
  $ZodSymbol: () => Om,
  $ZodSuccess: () => Mm,
  $ZodStringFormat: () => M,
  $ZodString: () => Wt,
  $ZodSet: () => Qm,
  $ZodRegistry: () => mi,
  $ZodRecord: () => Ym,
  $ZodRealError: () => Ir,
  $ZodReadonly: () => dm,
  $ZodPromise: () => tb,
  $ZodPrefault: () => Hm,
  $ZodPipe: () => Tm,
  $ZodOptional: () => Bm,
  $ZodObjectJIT: () => Km,
  $ZodObject: () => jw,
  $ZodNumberFormat: () => Dm,
  $ZodNumber: () => Qo,
  $ZodNullable: () => ym,
  $ZodNull: () => km,
  $ZodNonOptional: () => Rm,
  $ZodNever: () => Pm,
  $ZodNanoID: () => nm,
  $ZodNaN: () => Cm,
  $ZodMap: () => Em,
  $ZodLiteral: () => Sm,
  $ZodLazy: () => nb,
  $ZodKSUID: () => cm,
  $ZodJWT: () => pm,
  $ZodIntersection: () => Vm,
  $ZodISOTime: () => mm,
  $ZodISODuration: () => bm,
  $ZodISODateTime: () => um,
  $ZodISODate: () => gm,
  $ZodIPv6: () => hm,
  $ZodIPv4: () => vm,
  $ZodGUID: () => Tg,
  $ZodFunction: () => rb,
  $ZodFile: () => Gm,
  $ZodError: () => Tn,
  $ZodEnum: () => Fm,
  $ZodEncodeError: () => Pt,
  $ZodEmoji: () => tm,
  $ZodEmail: () => sg,
  $ZodE164: () => am,
  $ZodDiscriminatedUnion: () => Lm,
  $ZodDefault: () => Am,
  $ZodDate: () => qm,
  $ZodCustomStringFormat: () => _m,
  $ZodCustom: () => ib,
  $ZodCodec: () => ii,
  $ZodCheckUpperCase: () => Ng,
  $ZodCheckStringFormat: () => mn,
  $ZodCheckStartsWith: () => yg,
  $ZodCheckSizeEquals: () => Yg,
  $ZodCheckRegex: () => Sg,
  $ZodCheckProperty: () => Hg,
  $ZodCheckOverwrite: () => Mg,
  $ZodCheckNumberFormat: () => Wg,
  $ZodCheckMultipleOf: () => qg,
  $ZodCheckMinSize: () => Vg,
  $ZodCheckMinLength: () => Qg,
  $ZodCheckMimeType: () => Rg,
  $ZodCheckMaxSize: () => Lg,
  $ZodCheckMaxLength: () => Eg,
  $ZodCheckLowerCase: () => Gg,
  $ZodCheckLessThan: () => Xo,
  $ZodCheckLengthEquals: () => Fg,
  $ZodCheckIncludes: () => Bg,
  $ZodCheckGreaterThan: () => qo,
  $ZodCheckEndsWith: () => Ag,
  $ZodCheckBigIntFormat: () => Kg,
  $ZodCheck: () => s,
  $ZodCatch: () => Zm,
  $ZodCUID2: () => om,
  $ZodCUID: () => im,
  $ZodCIDRv6: () => xm,
  $ZodCIDRv4: () => $m,
  $ZodBoolean: () => ni,
  $ZodBigIntFormat: () => jm,
  $ZodBigInt: () => Fo,
  $ZodBase64URL: () => zm,
  $ZodBase64: () => wm,
  $ZodAsyncError: () => Zr,
  $ZodArray: () => Wm,
  $ZodAny: () => Um
});
var Nu = Object.freeze({ status: "aborted" });
function $(r, t, i) {
  function o(u, g) {
    var c;
    Object.defineProperty(u, "_zod", { value: u._zod ?? {}, enumerable: !1 }),
    (c = u._zod).traits ?? (c.traits = new Set()),
    u._zod.traits.add(r),
    t(u, g);
    for (let m in l.prototype)
    if (!(m in u))
    Object.defineProperty(u, m, { value: l.prototype[m].bind(u) });
    u._zod.constr = l, u._zod.def = g;
  }
  let n = i?.Parent ?? Object;
  class e extends n {}
  Object.defineProperty(e, "name", { value: r });
  function l(u) {
    var g;
    let c = i?.Parent ? new e() : this;
    o(c, u), (g = c._zod).deferred ?? (g.deferred = []);
    for (let m of c._zod.deferred) m();
    return c;
  }
  return (
    Object.defineProperty(l, "init", { value: o }),
    Object.defineProperty(l, Symbol.hasInstance, {
      value: (u) => {
        if (i?.Parent && u instanceof i.Parent) return !0;
        return u?._zod?.traits?.has(r);
      }
    }),
    Object.defineProperty(l, "name", { value: r }),
    l);

}
var Bu = Symbol("zod_brand");
class Zr extends Error {
  constructor() {
    super(
      "Encountered Promise during synchronous parse. Use .parseAsync() instead."
    );
  }
}
class Pt extends Error {
  constructor(r) {
    super(`Encountered unidirectional transform during encode: ${r}`);
    this.name = "ZodEncodeError";
  }
}
var yn = {};
function br(r) {
  if (r) Object.assign(yn, r);
  return yn;
}
var p = {};
I(p, {
  unwrapMessage: () => An,
  uint8ArrayToHex: () => Oj,
  uint8ArrayToBase64url: () => Dj,
  uint8ArrayToBase64: () => sf,
  stringifyPrimitive: () => z,
  shallowClone: () => Ru,
  safeExtend: () => fj,
  required: () => aj,
  randomString: () => gj,
  propertyKeyTypes: () => Mn,
  promiseAllObject: () => uj,
  primitiveTypes: () => Mu,
  prefixIssues: () => qr,
  pick: () => hj,
  partial: () => zj,
  optionalKeys: () => Zu,
  omit: () => $j,
  objectClone: () => ej,
  numKeys: () => mj,
  nullish: () => ft,
  normalizeParams: () => a,
  mergeDefs: () => zt,
  merge: () => wj,
  jsonStringifyReplacer: () => nn,
  joinValues: () => x,
  issue: () => en,
  isPlainObject: () => at,
  isObject: () => Xt,
  hexToUint8Array: () => jj,
  getSizableOrigin: () => Zn,
  getParsedType: () => bj,
  getLengthableOrigin: () => Cn,
  getEnumValues: () => Hn,
  getElementAtPath: () => cj,
  floatSafeRemainder: () => Au,
  finalizeIssue: () => Wr,
  extend: () => xj,
  escapeRegex: () => Cr,
  esc: () => wo,
  defineLazy: () => F,
  createTransparentProxy: () => vj,
  cloneDef: () => lj,
  clone: () => jr,
  cleanRegex: () => Rn,
  cleanEnum: () => pj,
  captureStackTrace: () => zo,
  cached: () => on,
  base64urlToUint8Array: () => _j,
  base64ToUint8Array: () => df,
  assignProp: () => wt,
  assertNotEqual: () => tj,
  assertNever: () => ij,
  assertIs: () => nj,
  assertEqual: () => rj,
  assert: () => oj,
  allowsEval: () => Hu,
  aborted: () => pt,
  NUMBER_FORMAT_RANGES: () => Cu,
  Class: () => rw,
  BIGINT_FORMAT_RANGES: () => Tu
});
function rj(r) {
  return r;
}
function tj(r) {
  return r;
}
function nj(r) {}
function ij(r) {
  throw new Error();
}
function oj(r) {}
function Hn(r) {
  let t = Object.values(r).filter((o) => typeof o === "number");
  return Object.entries(r).
  filter(([o, n]) => t.indexOf(+o) === -1).
  map(([o, n]) => n);
}
function x(r, t = "|") {
  return r.map((i) => z(i)).join(t);
}
function nn(r, t) {
  if (typeof t === "bigint") return t.toString();
  return t;
}
function on(r) {
  return {
    get value() {
      {
        let i = r();
        return Object.defineProperty(this, "value", { value: i }), i;
      }
      throw new Error("cached value already set");
    }
  };
}
function ft(r) {
  return r === null || r === void 0;
}
function Rn(r) {
  let t = r.startsWith("^") ? 1 : 0,
    i = r.endsWith("$") ? r.length - 1 : r.length;
  return r.slice(t, i);
}
function Au(r, t) {
  let i = (r.toString().split(".")[1] || "").length,
    o = t.toString(),
    n = (o.split(".")[1] || "").length;
  if (n === 0 && /\d?e-\d?/.test(o)) {
    let g = o.match(/\d?e-(\d?)/);
    if (g?.[1]) n = Number.parseInt(g[1]);
  }
  let e = i > n ? i : n,
    l = Number.parseInt(r.toFixed(e).replace(".", "")),
    u = Number.parseInt(t.toFixed(e).replace(".", ""));
  return l % u / 10 ** e;
}
var Tf = Symbol("evaluating");
function F(r, t, i) {
  let o = void 0;
  Object.defineProperty(r, t, {
    get() {
      if (o === Tf) return;
      if (o === void 0) o = Tf, o = i();
      return o;
    },
    set(n) {
      Object.defineProperty(r, t, { value: n });
    },
    configurable: !0
  });
}
function ej(r) {
  return Object.create(
    Object.getPrototypeOf(r),
    Object.getOwnPropertyDescriptors(r)
  );
}
function wt(r, t, i) {
  Object.defineProperty(r, t, {
    value: i,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function zt(...r) {
  let t = {};
  for (let i of r) {
    let o = Object.getOwnPropertyDescriptors(i);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
function lj(r) {
  return zt(r._zod.def);
}
function cj(r, t) {
  if (!t) return r;
  return t.reduce((i, o) => i?.[o], r);
}
function uj(r) {
  let t = Object.keys(r),
    i = t.map((o) => r[o]);
  return Promise.all(i).then((o) => {
    let n = {};
    for (let e = 0; e < t.length; e++) n[t[e]] = o[e];
    return n;
  });
}
function gj(r = 10) {
  let i = "";
  for (let o = 0; o < r; o++)
  i += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)];
  return i;
}
function wo(r) {
  return JSON.stringify(r);
}
var zo = "captureStackTrace" in Error ? Error.captureStackTrace : (...r) => {};
function Xt(r) {
  return typeof r === "object" && r !== null && !Array.isArray(r);
}
var Hu = on(() => {
  if (
  typeof navigator !== "undefined" &&
  navigator?.userAgent?.includes("Cloudflare"))

  return !1;
  try {
    return new Function(""), !0;
  } catch (r) {
    return !1;
  }
});
function at(r) {
  if (Xt(r) === !1) return !1;
  let t = r.constructor;
  if (t === void 0) return !0;
  let i = t.prototype;
  if (Xt(i) === !1) return !1;
  if (Object.prototype.hasOwnProperty.call(i, "isPrototypeOf") === !1)
  return !1;
  return !0;
}
function Ru(r) {
  if (at(r)) return { ...r };
  if (Array.isArray(r)) return [...r];
  return r;
}
function mj(r) {
  let t = 0;
  for (let i in r) if (Object.prototype.hasOwnProperty.call(r, i)) t++;
  return t;
}
var bj = (r) => {
    let t = typeof r;
    switch (t) {
      case "undefined":
        return "undefined";
      case "string":
        return "string";
      case "number":
        return Number.isNaN(r) ? "nan" : "number";
      case "boolean":
        return "boolean";
      case "function":
        return "function";
      case "bigint":
        return "bigint";
      case "symbol":
        return "symbol";
      case "object":
        if (Array.isArray(r)) return "array";
        if (r === null) return "null";
        if (
        r.then &&
        typeof r.then === "function" &&
        r.catch &&
        typeof r.catch === "function")

        return "promise";
        if (typeof Map !== "undefined" && r instanceof Map) return "map";
        if (typeof Set !== "undefined" && r instanceof Set) return "set";
        if (typeof Date !== "undefined" && r instanceof Date) return "date";
        if (typeof File !== "undefined" && r instanceof File) return "file";
        return "object";
      default:
        throw new Error(`Unknown data type: ${t}`);
    }
  },
  Mn = new Set(["string", "number", "symbol"]),
  Mu = new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"]
  );
function Cr(r) {
  return r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function jr(r, t, i) {
  let o = new r._zod.constr(t ?? r._zod.def);
  if (!t || i?.parent) o._zod.parent = r;
  return o;
}
function a(r) {
  let t = r;
  if (!t) return {};
  if (typeof t === "string") return { error: () => t };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
    throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  if (delete t.message, typeof t.error === "string")
  return { ...t, error: () => t.error };
  return t;
}
function vj(r) {
  let t;
  return new Proxy(
    {},
    {
      get(i, o, n) {
        return t ?? (t = r()), Reflect.get(t, o, n);
      },
      set(i, o, n, e) {
        return t ?? (t = r()), Reflect.set(t, o, n, e);
      },
      has(i, o) {
        return t ?? (t = r()), Reflect.has(t, o);
      },
      deleteProperty(i, o) {
        return t ?? (t = r()), Reflect.deleteProperty(t, o);
      },
      ownKeys(i) {
        return t ?? (t = r()), Reflect.ownKeys(t);
      },
      getOwnPropertyDescriptor(i, o) {
        return t ?? (t = r()), Reflect.getOwnPropertyDescriptor(t, o);
      },
      defineProperty(i, o, n) {
        return t ?? (t = r()), Reflect.defineProperty(t, o, n);
      }
    }
  );
}
function z(r) {
  if (typeof r === "bigint") return r.toString() + "n";
  if (typeof r === "string") return `"${r}"`;
  return `${r}`;
}
function Zu(r) {
  return Object.keys(r).filter((t) => {
    return r[t]._zod.optin === "optional" && r[t]._zod.optout === "optional";
  });
}
var Cu = {
    safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
    int32: [-2147483648, 2147483647],
    uint32: [0, 4294967295],
    float32: [
    -340282346638528860000000000000000000000,
    340282346638528860000000000000000000000],

    float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
  },
  Tu = {
    int64: [BigInt("-9223372036854775808"), BigInt("9223372036854775807")],
    uint64: [BigInt(0), BigInt("18446744073709551615")]
  };
function hj(r, t) {
  let i = r._zod.def,
    o = zt(r._zod.def, {
      get shape() {
        let n = {};
        for (let e in t) {
          if (!(e in i.shape)) throw new Error(`Unrecognized key: "${e}"`);
          if (!t[e]) continue;
          n[e] = i.shape[e];
        }
        return wt(this, "shape", n), n;
      },
      checks: []
    });
  return jr(r, o);
}
function $j(r, t) {
  let i = r._zod.def,
    o = zt(r._zod.def, {
      get shape() {
        let n = { ...r._zod.def.shape };
        for (let e in t) {
          if (!(e in i.shape)) throw new Error(`Unrecognized key: "${e}"`);
          if (!t[e]) continue;
          delete n[e];
        }
        return wt(this, "shape", n), n;
      },
      checks: []
    });
  return jr(r, o);
}
function xj(r, t) {
  if (!at(t))
  throw new Error("Invalid input to extend: expected a plain object");
  let i = r._zod.def.checks;
  if (i && i.length > 0)
  throw new Error(
    "Object schemas containing refinements cannot be extended. Use `.safeExtend()` instead."
  );
  let n = zt(r._zod.def, {
    get shape() {
      let e = { ...r._zod.def.shape, ...t };
      return wt(this, "shape", e), e;
    },
    checks: []
  });
  return jr(r, n);
}
function fj(r, t) {
  if (!at(t))
  throw new Error("Invalid input to safeExtend: expected a plain object");
  let i = {
    ...r._zod.def,
    get shape() {
      let o = { ...r._zod.def.shape, ...t };
      return wt(this, "shape", o), o;
    },
    checks: r._zod.def.checks
  };
  return jr(r, i);
}
function wj(r, t) {
  let i = zt(r._zod.def, {
    get shape() {
      let o = { ...r._zod.def.shape, ...t._zod.def.shape };
      return wt(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: []
  });
  return jr(r, i);
}
function zj(r, t, i) {
  let o = zt(t._zod.def, {
    get shape() {
      let n = t._zod.def.shape,
        e = { ...n };
      if (i)
      for (let l in i) {
        if (!(l in n)) throw new Error(`Unrecognized key: "${l}"`);
        if (!i[l]) continue;
        e[l] = r ? new r({ type: "optional", innerType: n[l] }) : n[l];
      } else

      for (let l in n)
      e[l] = r ? new r({ type: "optional", innerType: n[l] }) : n[l];
      return wt(this, "shape", e), e;
    },
    checks: []
  });
  return jr(t, o);
}
function aj(r, t, i) {
  let o = zt(t._zod.def, {
    get shape() {
      let n = t._zod.def.shape,
        e = { ...n };
      if (i)
      for (let l in i) {
        if (!(l in e)) throw new Error(`Unrecognized key: "${l}"`);
        if (!i[l]) continue;
        e[l] = new r({ type: "nonoptional", innerType: n[l] });
      } else

      for (let l in n) e[l] = new r({ type: "nonoptional", innerType: n[l] });
      return wt(this, "shape", e), e;
    },
    checks: []
  });
  return jr(t, o);
}
function pt(r, t = 0) {
  if (r.aborted === !0) return !0;
  for (let i = t; i < r.issues.length; i++)
  if (r.issues[i]?.continue !== !0) return !0;
  return !1;
}
function qr(r, t) {
  return t.map((i) => {
    var o;
    return (o = i).path ?? (o.path = []), i.path.unshift(r), i;
  });
}
function An(r) {
  return typeof r === "string" ? r : r?.message;
}
function Wr(r, t, i) {
  let o = { ...r, path: r.path ?? [] };
  if (!r.message) {
    let n =
    An(r.inst?._zod.def?.error?.(r)) ??
    An(t?.error?.(r)) ??
    An(i.customError?.(r)) ??
    An(i.localeError?.(r)) ??
    "Invalid input";
    o.message = n;
  }
  if (delete o.inst, delete o.continue, !t?.reportInput) delete o.input;
  return o;
}
function Zn(r) {
  if (r instanceof Set) return "set";
  if (r instanceof Map) return "map";
  if (r instanceof File) return "file";
  return "unknown";
}
function Cn(r) {
  if (Array.isArray(r)) return "array";
  if (typeof r === "string") return "string";
  return "unknown";
}
function en(...r) {
  let [t, i, o] = r;
  if (typeof t === "string")
  return { message: t, code: "custom", input: i, inst: o };
  return { ...t };
}
function pj(r) {
  return Object.entries(r).
  filter(([t, i]) => {
    return Number.isNaN(Number.parseInt(t, 10));
  }).
  map((t) => t[1]);
}
function df(r) {
  let t = atob(r),
    i = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++) i[o] = t.charCodeAt(o);
  return i;
}
function sf(r) {
  let t = "";
  for (let i = 0; i < r.length; i++) t += String.fromCharCode(r[i]);
  return btoa(t);
}
function _j(r) {
  let t = r.replace(/-/g, "+").replace(/_/g, "/"),
    i = "=".repeat((4 - t.length % 4) % 4);
  return df(t + i);
}
function Dj(r) {
  return sf(r).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
function jj(r) {
  let t = r.replace(/^0x/, "");
  if (t.length % 2 !== 0) throw new Error("Invalid hex string length");
  let i = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
  i[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return i;
}
function Oj(r) {
  return Array.from(r).
  map((t) => t.toString(16).padStart(2, "0")).
  join("");
}
class rw {
  constructor(...r) {}
}
var tw = (r, t) => {
    r.name = "$ZodError",
    Object.defineProperty(r, "_zod", { value: r._zod, enumerable: !1 }),
    Object.defineProperty(r, "issues", { value: t, enumerable: !1 }),
    r.message = JSON.stringify(t, nn, 2),
    Object.defineProperty(r, "toString", {
      value: () => r.message,
      enumerable: !1
    });
  },
  Tn = $("$ZodError", tw),
  Ir = $("$ZodError", tw, { Parent: Error });
function dn(r, t = (i) => i.message) {
  let i = {},
    o = [];
  for (let n of r.issues)
  if (n.path.length > 0)
  i[n.path[0]] = i[n.path[0]] || [], i[n.path[0]].push(t(n));else
  o.push(t(n));
  return { formErrors: o, fieldErrors: i };
}
function sn(r, t) {
  let i =
    t ||
    function (e) {
      return e.message;
    },
    o = { _errors: [] },
    n = (e) => {
      for (let l of e.issues)
      if (l.code === "invalid_union" && l.errors.length)
      l.errors.map((u) => n({ issues: u }));else
      if (l.code === "invalid_key") n({ issues: l.issues });else
      if (l.code === "invalid_element") n({ issues: l.issues });else
      if (l.path.length === 0) o._errors.push(i(l));else
      {
        let u = o,
          g = 0;
        while (g < l.path.length) {
          let c = l.path[g];
          if (g !== l.path.length - 1) u[c] = u[c] || { _errors: [] };else
          u[c] = u[c] || { _errors: [] }, u[c]._errors.push(i(l));
          u = u[c], g++;
        }
      }
    };
  return n(r), o;
}
function du(r, t) {
  let i =
    t ||
    function (e) {
      return e.message;
    },
    o = { errors: [] },
    n = (e, l = []) => {
      var u, g;
      for (let c of e.issues)
      if (c.code === "invalid_union" && c.errors.length)
      c.errors.map((m) => n({ issues: m }, c.path));else
      if (c.code === "invalid_key") n({ issues: c.issues }, c.path);else
      if (c.code === "invalid_element") n({ issues: c.issues }, c.path);else
      {
        let m = [...l, ...c.path];
        if (m.length === 0) {
          o.errors.push(i(c));
          continue;
        }
        let v = o,
          h = 0;
        while (h < m.length) {
          let b = m[h],
            f = h === m.length - 1;
          if (typeof b === "string")
          v.properties ?? (v.properties = {}),
          (u = v.properties)[b] ?? (u[b] = { errors: [] }),
          v = v.properties[b];else

          v.items ?? (v.items = []),
          (g = v.items)[b] ?? (g[b] = { errors: [] }),
          v = v.items[b];
          if (f) v.errors.push(i(c));
          h++;
        }
      }
    };
  return n(r), o;
}
function nw(r) {
  let t = [],
    i = r.map((o) => typeof o === "object" ? o.key : o);
  for (let o of i)
  if (typeof o === "number") t.push(`[${o}]`);else
  if (typeof o === "symbol") t.push(`[${JSON.stringify(String(o))}]`);else
  if (/[^\w$]/.test(o)) t.push(`[${JSON.stringify(o)}]`);else
  {
    if (t.length) t.push(".");
    t.push(o);
  }
  return t.join("");
}
function su(r) {
  let t = [],
    i = [...r.issues].sort(
      (o, n) => (o.path ?? []).length - (n.path ?? []).length
    );
  for (let o of i)
  if (t.push(`✖ ${o.message}`), o.path?.length)
  t.push(`  → at ${nw(o.path)}`);
  return t.join(`
`);
}
var ln = (r) => (t, i, o, n) => {
    let e = o ? Object.assign(o, { async: !1 }) : { async: !1 },
      l = t._zod.run({ value: i, issues: [] }, e);
    if (l instanceof Promise) throw new Zr();
    if (l.issues.length) {
      let u = new (n?.Err ?? r)(l.issues.map((g) => Wr(g, e, br())));
      throw zo(u, n?.callee), u;
    }
    return l.value;
  },
  ao = ln(Ir),
  cn = (r) => async (t, i, o, n) => {
    let e = o ? Object.assign(o, { async: !0 }) : { async: !0 },
      l = t._zod.run({ value: i, issues: [] }, e);
    if (l instanceof Promise) l = await l;
    if (l.issues.length) {
      let u = new (n?.Err ?? r)(l.issues.map((g) => Wr(g, e, br())));
      throw zo(u, n?.callee), u;
    }
    return l.value;
  },
  po = cn(Ir),
  un = (r) => (t, i, o) => {
    let n = o ? { ...o, async: !1 } : { async: !1 },
      e = t._zod.run({ value: i, issues: [] }, n);
    if (e instanceof Promise) throw new Zr();
    return e.issues.length ?
    {
      success: !1,
      error: new (r ?? Tn)(e.issues.map((l) => Wr(l, n, br())))
    } :
    { success: !0, data: e.value };
  },
  rg = un(Ir),
  gn = (r) => async (t, i, o) => {
    let n = o ? Object.assign(o, { async: !0 }) : { async: !0 },
      e = t._zod.run({ value: i, issues: [] }, n);
    if (e instanceof Promise) e = await e;
    return e.issues.length ?
    { success: !1, error: new r(e.issues.map((l) => Wr(l, n, br()))) } :
    { success: !0, data: e.value };
  },
  tg = gn(Ir),
  _o = (r) => (t, i, o) => {
    let n = o ?
    Object.assign(o, { direction: "backward" }) :
    { direction: "backward" };
    return ln(r)(t, i, n);
  },
  kj = _o(Ir),
  Do = (r) => (t, i, o) => {
    return ln(r)(t, i, o);
  },
  Uj = Do(Ir),
  jo = (r) => async (t, i, o) => {
    let n = o ?
    Object.assign(o, { direction: "backward" }) :
    { direction: "backward" };
    return cn(r)(t, i, n);
  },
  Jj = jo(Ir),
  Oo = (r) => async (t, i, o) => {
    return cn(r)(t, i, o);
  },
  Pj = Oo(Ir),
  Io = (r) => (t, i, o) => {
    let n = o ?
    Object.assign(o, { direction: "backward" }) :
    { direction: "backward" };
    return un(r)(t, i, n);
  },
  Xj = Io(Ir),
  ko = (r) => (t, i, o) => {
    return un(r)(t, i, o);
  },
  qj = ko(Ir),
  Uo = (r) => async (t, i, o) => {
    let n = o ?
    Object.assign(o, { direction: "backward" }) :
    { direction: "backward" };
    return gn(r)(t, i, n);
  },
  Wj = Uo(Ir),
  Jo = (r) => async (t, i, o) => {
    return gn(r)(t, i, o);
  },
  Kj = Jo(Ir);
var Yr = {};
I(Yr, {
  xid: () => eg,
  uuid7: () => Ej,
  uuid6: () => Yj,
  uuid4: () => Vj,
  uuid: () => qt,
  uppercase: () => Xg,
  unicodeEmail: () => iw,
  undefined: () => Jg,
  ulid: () => og,
  time: () => pg,
  string: () => Dg,
  sha512_hex: () => nO,
  sha512_base64url: () => oO,
  sha512_base64: () => iO,
  sha384_hex: () => sj,
  sha384_base64url: () => tO,
  sha384_base64: () => rO,
  sha256_hex: () => Cj,
  sha256_base64url: () => dj,
  sha256_base64: () => Tj,
  sha1_hex: () => Rj,
  sha1_base64url: () => Zj,
  sha1_base64: () => Mj,
  rfc5322Email: () => Fj,
  number: () => Ig,
  null: () => Ug,
  nanoid: () => cg,
  md5_hex: () => yj,
  md5_base64url: () => Hj,
  md5_base64: () => Aj,
  lowercase: () => Pg,
  ksuid: () => lg,
  ipv6: () => hg,
  ipv4: () => vg,
  integer: () => Og,
  idnEmail: () => Sj,
  html5Email: () => Qj,
  hostname: () => wg,
  hex: () => Bj,
  guid: () => gg,
  extendedDuration: () => Lj,
  emoji: () => bg,
  email: () => mg,
  e164: () => zg,
  duration: () => ug,
  domain: () => Nj,
  datetime: () => _g,
  date: () => ag,
  cuid2: () => ig,
  cuid: () => ng,
  cidrv6: () => xg,
  cidrv4: () => $g,
  browserEmail: () => Gj,
  boolean: () => kg,
  bigint: () => jg,
  base64url: () => Po,
  base64: () => fg
});
var ng = /^[cC][^\s-]{8,}$/,
  ig = /^[0-9a-z]+$/,
  og = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,
  eg = /^[0-9a-vA-V]{20}$/,
  lg = /^[A-Za-z0-9]{27}$/,
  cg = /^[a-zA-Z0-9_-]{21}$/,
  ug =
  /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,
  Lj =
  /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/,
  gg =
  /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,
  qt = (r) => {
    if (!r)
    return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
    return new RegExp(
      `^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${r}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`
    );
  },
  Vj = qt(4),
  Yj = qt(6),
  Ej = qt(7),
  mg =
  /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,
  Qj =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
  Fj =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  iw = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u,
  Sj = iw,
  Gj =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
function bg() {
  return new RegExp(
    "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$",
    "u"
  );
}
var vg =
  /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
  hg =
  /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,
  $g =
  /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,
  xg =
  /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
  fg =
  /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,
  Po = /^[A-Za-z0-9_-]*$/,
  wg =
  /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/,
  Nj = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/,
  zg = /^\+(?:[0-9]){6,14}[0-9]$/,
  ow =
  "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",
  ag = new RegExp(`^${ow}$`);
function ew(r) {
  return typeof r.precision === "number" ?
  r.precision === -1 ?
  "(?:[01]\\d|2[0-3]):[0-5]\\d" :
  r.precision === 0 ?
  "(?:[01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d" :
  `(?:[01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d\\.\\d{${r.precision}}` :
  "(?:[01]\\d|2[0-3]):[0-5]\\d(?::[0-5]\\d(?:\\.\\d+)?)?";
}
function pg(r) {
  return new RegExp(`^${ew(r)}$`);
}
function _g(r) {
  let t = ew({ precision: r.precision }),
    i = ["Z"];
  if (r.local) i.push("");
  if (r.offset) i.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let o = `${t}(?:${i.join("|")})`;
  return new RegExp(`^${ow}T(?:${o})$`);
}
var Dg = (r) => {
    let t = r ?
    `[\\s\\S]{${r?.minimum ?? 0},${r?.maximum ?? ""}}` :
    "[\\s\\S]*";
    return new RegExp(`^${t}$`);
  },
  jg = /^-?\d+n?$/,
  Og = /^-?\d+$/,
  Ig = /^-?\d+(?:\.\d+)?/,
  kg = /^(?:true|false)$/i,
  Ug = /^null$/i;
var Jg = /^undefined$/i;
var Pg = /^[^A-Z]*$/,
  Xg = /^[^a-z]*$/,
  Bj = /^[0-9a-fA-F]*$/;
function ri(r, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${r}}${t}$`);
}
function ti(r) {
  return new RegExp(`^[A-Za-z0-9_-]{${r}}$`);
}
var yj = /^[0-9a-fA-F]{32}$/,
  Aj = ri(22, "=="),
  Hj = ti(22),
  Rj = /^[0-9a-fA-F]{40}$/,
  Mj = ri(27, "="),
  Zj = ti(27),
  Cj = /^[0-9a-fA-F]{64}$/,
  Tj = ri(43, "="),
  dj = ti(43),
  sj = /^[0-9a-fA-F]{96}$/,
  rO = ri(64, ""),
  tO = ti(64),
  nO = /^[0-9a-fA-F]{128}$/,
  iO = ri(86, "=="),
  oO = ti(86);
var s = $("$ZodCheck", (r, t) => {
    var i;
    r._zod ?? (r._zod = {}),
    r._zod.def = t,
    (i = r._zod).onattach ?? (i.onattach = []);
  }),
  cw = { number: "number", bigint: "bigint", object: "date" },
  Xo = $("$ZodCheckLessThan", (r, t) => {
    s.init(r, t);
    let i = cw[typeof t.value];
    r._zod.onattach.push((o) => {
      let n = o._zod.bag,
        e =
        (t.inclusive ? n.maximum : n.exclusiveMaximum) ??
        Number.POSITIVE_INFINITY;
      if (t.value < e)
      if (t.inclusive) n.maximum = t.value;else
      n.exclusiveMaximum = t.value;
    }),
    r._zod.check = (o) => {
      if (t.inclusive ? o.value <= t.value : o.value < t.value) return;
      o.issues.push({
        origin: i,
        code: "too_big",
        maximum: t.value,
        input: o.value,
        inclusive: t.inclusive,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  qo = $("$ZodCheckGreaterThan", (r, t) => {
    s.init(r, t);
    let i = cw[typeof t.value];
    r._zod.onattach.push((o) => {
      let n = o._zod.bag,
        e =
        (t.inclusive ? n.minimum : n.exclusiveMinimum) ??
        Number.NEGATIVE_INFINITY;
      if (t.value > e)
      if (t.inclusive) n.minimum = t.value;else
      n.exclusiveMinimum = t.value;
    }),
    r._zod.check = (o) => {
      if (t.inclusive ? o.value >= t.value : o.value > t.value) return;
      o.issues.push({
        origin: i,
        code: "too_small",
        minimum: t.value,
        input: o.value,
        inclusive: t.inclusive,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  qg = $("$ZodCheckMultipleOf", (r, t) => {
    s.init(r, t),
    r._zod.onattach.push((i) => {
      var o;
      (o = i._zod.bag).multipleOf ?? (o.multipleOf = t.value);
    }),
    r._zod.check = (i) => {
      if (typeof i.value !== typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
      if (
      typeof i.value === "bigint" ?
      i.value % t.value === BigInt(0) :
      Au(i.value, t.value) === 0)

      return;
      i.issues.push({
        origin: typeof i.value,
        code: "not_multiple_of",
        divisor: t.value,
        input: i.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Wg = $("$ZodCheckNumberFormat", (r, t) => {
    s.init(r, t), t.format = t.format || "float64";
    let i = t.format?.includes("int"),
      o = i ? "int" : "number",
      [n, e] = Cu[t.format];
    r._zod.onattach.push((l) => {
      let u = l._zod.bag;
      if (u.format = t.format, u.minimum = n, u.maximum = e, i)
      u.pattern = Og;
    }),
    r._zod.check = (l) => {
      let u = l.value;
      if (i) {
        if (!Number.isInteger(u)) {
          l.issues.push({
            expected: o,
            format: t.format,
            code: "invalid_type",
            continue: !1,
            input: u,
            inst: r
          });
          return;
        }
        if (!Number.isSafeInteger(u)) {
          if (u > 0)
          l.issues.push({
            input: u,
            code: "too_big",
            maximum: Number.MAX_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst: r,
            origin: o,
            continue: !t.abort
          });else

          l.issues.push({
            input: u,
            code: "too_small",
            minimum: Number.MIN_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst: r,
            origin: o,
            continue: !t.abort
          });
          return;
        }
      }
      if (u < n)
      l.issues.push({
        origin: "number",
        input: u,
        code: "too_small",
        minimum: n,
        inclusive: !0,
        inst: r,
        continue: !t.abort
      });
      if (u > e)
      l.issues.push({
        origin: "number",
        input: u,
        code: "too_big",
        maximum: e,
        inst: r
      });
    };
  }),
  Kg = $("$ZodCheckBigIntFormat", (r, t) => {
    s.init(r, t);
    let [i, o] = Tu[t.format];
    r._zod.onattach.push((n) => {
      let e = n._zod.bag;
      e.format = t.format, e.minimum = i, e.maximum = o;
    }),
    r._zod.check = (n) => {
      let e = n.value;
      if (e < i)
      n.issues.push({
        origin: "bigint",
        input: e,
        code: "too_small",
        minimum: i,
        inclusive: !0,
        inst: r,
        continue: !t.abort
      });
      if (e > o)
      n.issues.push({
        origin: "bigint",
        input: e,
        code: "too_big",
        maximum: o,
        inst: r
      });
    };
  }),
  Lg = $("$ZodCheckMaxSize", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.size !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
      if (t.maximum < n) o._zod.bag.maximum = t.maximum;
    }),
    r._zod.check = (o) => {
      let n = o.value;
      if (n.size <= t.maximum) return;
      o.issues.push({
        origin: Zn(n),
        code: "too_big",
        maximum: t.maximum,
        inclusive: !0,
        input: n,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Vg = $("$ZodCheckMinSize", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.size !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
      if (t.minimum > n) o._zod.bag.minimum = t.minimum;
    }),
    r._zod.check = (o) => {
      let n = o.value;
      if (n.size >= t.minimum) return;
      o.issues.push({
        origin: Zn(n),
        code: "too_small",
        minimum: t.minimum,
        inclusive: !0,
        input: n,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Yg = $("$ZodCheckSizeEquals", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.size !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag;
      n.minimum = t.size, n.maximum = t.size, n.size = t.size;
    }),
    r._zod.check = (o) => {
      let n = o.value,
        e = n.size;
      if (e === t.size) return;
      let l = e > t.size;
      o.issues.push({
        origin: Zn(n),
        ...(l ?
        { code: "too_big", maximum: t.size } :
        { code: "too_small", minimum: t.size }),
        inclusive: !0,
        exact: !0,
        input: o.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Eg = $("$ZodCheckMaxLength", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.length !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
      if (t.maximum < n) o._zod.bag.maximum = t.maximum;
    }),
    r._zod.check = (o) => {
      let n = o.value;
      if (n.length <= t.maximum) return;
      let l = Cn(n);
      o.issues.push({
        origin: l,
        code: "too_big",
        maximum: t.maximum,
        inclusive: !0,
        input: n,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Qg = $("$ZodCheckMinLength", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.length !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
      if (t.minimum > n) o._zod.bag.minimum = t.minimum;
    }),
    r._zod.check = (o) => {
      let n = o.value;
      if (n.length >= t.minimum) return;
      let l = Cn(n);
      o.issues.push({
        origin: l,
        code: "too_small",
        minimum: t.minimum,
        inclusive: !0,
        input: n,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Fg = $("$ZodCheckLengthEquals", (r, t) => {
    var i;
    s.init(r, t),
    (i = r._zod.def).when ?? (
    i.when = (o) => {
      let n = o.value;
      return !ft(n) && n.length !== void 0;
    }),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag;
      n.minimum = t.length, n.maximum = t.length, n.length = t.length;
    }),
    r._zod.check = (o) => {
      let n = o.value,
        e = n.length;
      if (e === t.length) return;
      let l = Cn(n),
        u = e > t.length;
      o.issues.push({
        origin: l,
        ...(u ?
        { code: "too_big", maximum: t.length } :
        { code: "too_small", minimum: t.length }),
        inclusive: !0,
        exact: !0,
        input: o.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  mn = $("$ZodCheckStringFormat", (r, t) => {
    var i, o;
    if (
    s.init(r, t),
    r._zod.onattach.push((n) => {
      let e = n._zod.bag;
      if (e.format = t.format, t.pattern)
      e.patterns ?? (e.patterns = new Set()), e.patterns.add(t.pattern);
    }),
    t.pattern)

    (i = r._zod).check ?? (
    i.check = (n) => {
      if (t.pattern.lastIndex = 0, t.pattern.test(n.value)) return;
      n.issues.push({
        origin: "string",
        code: "invalid_format",
        format: t.format,
        input: n.value,
        ...(t.pattern ? { pattern: t.pattern.toString() } : {}),
        inst: r,
        continue: !t.abort
      });
    });else
    (o = r._zod).check ?? (o.check = () => {});
  }),
  Sg = $("$ZodCheckRegex", (r, t) => {
    mn.init(r, t),
    r._zod.check = (i) => {
      if (t.pattern.lastIndex = 0, t.pattern.test(i.value)) return;
      i.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "regex",
        input: i.value,
        pattern: t.pattern.toString(),
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Gg = $("$ZodCheckLowerCase", (r, t) => {
    t.pattern ?? (t.pattern = Pg), mn.init(r, t);
  }),
  Ng = $("$ZodCheckUpperCase", (r, t) => {
    t.pattern ?? (t.pattern = Xg), mn.init(r, t);
  }),
  Bg = $("$ZodCheckIncludes", (r, t) => {
    s.init(r, t);
    let i = Cr(t.includes),
      o = new RegExp(
        typeof t.position === "number" ? `^.{${t.position}}${i}` : i
      );
    t.pattern = o,
    r._zod.onattach.push((n) => {
      let e = n._zod.bag;
      e.patterns ?? (e.patterns = new Set()), e.patterns.add(o);
    }),
    r._zod.check = (n) => {
      if (n.value.includes(t.includes, t.position)) return;
      n.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "includes",
        includes: t.includes,
        input: n.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  yg = $("$ZodCheckStartsWith", (r, t) => {
    s.init(r, t);
    let i = new RegExp(`^${Cr(t.prefix)}.*`);
    t.pattern ?? (t.pattern = i),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag;
      n.patterns ?? (n.patterns = new Set()), n.patterns.add(i);
    }),
    r._zod.check = (o) => {
      if (o.value.startsWith(t.prefix)) return;
      o.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "starts_with",
        prefix: t.prefix,
        input: o.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Ag = $("$ZodCheckEndsWith", (r, t) => {
    s.init(r, t);
    let i = new RegExp(`.*${Cr(t.suffix)}$`);
    t.pattern ?? (t.pattern = i),
    r._zod.onattach.push((o) => {
      let n = o._zod.bag;
      n.patterns ?? (n.patterns = new Set()), n.patterns.add(i);
    }),
    r._zod.check = (o) => {
      if (o.value.endsWith(t.suffix)) return;
      o.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "ends_with",
        suffix: t.suffix,
        input: o.value,
        inst: r,
        continue: !t.abort
      });
    };
  });
function lw(r, t, i) {
  if (r.issues.length) t.issues.push(...qr(i, r.issues));
}
var Hg = $("$ZodCheckProperty", (r, t) => {
    s.init(r, t),
    r._zod.check = (i) => {
      let o = t.schema._zod.run(
        { value: i.value[t.property], issues: [] },
        {}
      );
      if (o instanceof Promise) return o.then((n) => lw(n, i, t.property));
      lw(o, i, t.property);
      return;
    };
  }),
  Rg = $("$ZodCheckMimeType", (r, t) => {
    s.init(r, t);
    let i = new Set(t.mime);
    r._zod.onattach.push((o) => {
      o._zod.bag.mime = t.mime;
    }),
    r._zod.check = (o) => {
      if (i.has(o.value.type)) return;
      o.issues.push({
        code: "invalid_value",
        values: t.mime,
        input: o.value.type,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Mg = $("$ZodCheckOverwrite", (r, t) => {
    s.init(r, t),
    r._zod.check = (i) => {
      i.value = t.tx(i.value);
    };
  });
class Wo {
  constructor(r = []) {
    if (this.content = [], this.indent = 0, this) this.args = r;
  }
  indented(r) {
    this.indent += 1, r(this), this.indent -= 1;
  }
  write(r) {
    if (typeof r === "function") {
      r(this, { execution: "sync" }), r(this, { execution: "async" });
      return;
    }
    let i = r.
      split(
        `
`
      ).
      filter((e) => e),
      o = Math.min(...i.map((e) => e.length - e.trimStart().length)),
      n = i.map((e) => e.slice(o)).map((e) => " ".repeat(this.indent * 2) + e);
    for (let e of n) this.content.push(e);
  }
  compile() {
    let r = Function,
      t = this?.args,
      o = [...(this?.content ?? [""]).map((n) => `  ${n}`)];
    return new r(
      ...t,
      o.join(`
`)
    );
  }
}
var Zg = { major: 4, minor: 1, patch: 11 };
var L = $("$ZodType", (r, t) => {
    var i;
    r ?? (r = {}),
    r._zod.def = t,
    r._zod.bag = r._zod.bag || {},
    r._zod.version = Zg;
    let o = [...(r._zod.def.checks ?? [])];
    if (r._zod.traits.has("$ZodCheck")) o.unshift(r);
    for (let n of o) for (let e of n._zod.onattach) e(r);
    if (o.length === 0)
    (i = r._zod).deferred ?? (i.deferred = []),
    r._zod.deferred?.push(() => {
      r._zod.run = r._zod.parse;
    });else
    {
      let n = (l, u, g) => {
          let c = pt(l),
            m;
          for (let v of u) {
            if (v._zod.def.when) {
              if (!v._zod.def.when(l)) continue;
            } else if (c) continue;
            let h = l.issues.length,
              b = v._zod.check(l);
            if (b instanceof Promise && g?.async === !1) throw new Zr();
            if (m || b instanceof Promise)
            m = (m ?? Promise.resolve()).then(async () => {
              if (await b, l.issues.length === h) return;
              if (!c) c = pt(l, h);
            });else
            {
              if (l.issues.length === h) continue;
              if (!c) c = pt(l, h);
            }
          }
          if (m)
          return m.then(() => {
            return l;
          });
          return l;
        },
        e = (l, u, g) => {
          if (pt(l)) return l.aborted = !0, l;
          let c = n(u, o, g);
          if (c instanceof Promise) {
            if (g.async === !1) throw new Zr();
            return c.then((m) => r._zod.parse(m, g));
          }
          return r._zod.parse(c, g);
        };
      r._zod.run = (l, u) => {
        if (u.skipChecks) return r._zod.parse(l, u);
        if (u.direction === "backward") {
          let c = r._zod.parse(
            { value: l.value, issues: [] },
            { ...u, skipChecks: !0 }
          );
          if (c instanceof Promise)
          return c.then((m) => {
            return e(m, l, u);
          });
          return e(c, l, u);
        }
        let g = r._zod.parse(l, u);
        if (g instanceof Promise) {
          if (u.async === !1) throw new Zr();
          return g.then((c) => n(c, o, u));
        }
        return n(g, o, u);
      };
    }
    r["~standard"] = {
      validate: (n) => {
        try {
          let e = rg(r, n);
          return e.success ? { value: e.data } : { issues: e.error?.issues };
        } catch (e) {
          return tg(r, n).then((l) =>
          l.success ? { value: l.data } : { issues: l.error?.issues }
          );
        }
      },
      vendor: "zod",
      version: 1
    };
  }),
  Wt = $("$ZodString", (r, t) => {
    L.init(r, t),
    r._zod.pattern =
    [...(r?._zod.bag?.patterns ?? [])].pop() ?? Dg(r._zod.bag),
    r._zod.parse = (i, o) => {
      if (t.coerce)
      try {
        i.value = String(i.value);
      } catch (n) {}
      if (typeof i.value === "string") return i;
      return (
        i.issues.push({
          expected: "string",
          code: "invalid_type",
          input: i.value,
          inst: r
        }),
        i);

    };
  }),
  M = $("$ZodStringFormat", (r, t) => {
    mn.init(r, t), Wt.init(r, t);
  }),
  Tg = $("$ZodGUID", (r, t) => {
    t.pattern ?? (t.pattern = gg), M.init(r, t);
  }),
  dg = $("$ZodUUID", (r, t) => {
    if (t.version) {
      let o = { v1: 1, v2: 2, v3: 3, v4: 4, v5: 5, v6: 6, v7: 7, v8: 8 }[
      t.version];

      if (o === void 0) throw new Error(`Invalid UUID version: "${t.version}"`);
      t.pattern ?? (t.pattern = qt(o));
    } else t.pattern ?? (t.pattern = qt());
    M.init(r, t);
  }),
  sg = $("$ZodEmail", (r, t) => {
    t.pattern ?? (t.pattern = mg), M.init(r, t);
  }),
  rm = $("$ZodURL", (r, t) => {
    M.init(r, t),
    r._zod.check = (i) => {
      try {
        let o = i.value.trim(),
          n = new URL(o);
        if (t.hostname) {
          if (t.hostname.lastIndex = 0, !t.hostname.test(n.hostname))
          i.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid hostname",
            pattern: wg.source,
            input: i.value,
            inst: r,
            continue: !t.abort
          });
        }
        if (t.protocol) {
          if (
          t.protocol.lastIndex = 0,
          !t.protocol.test(
            n.protocol.endsWith(":") ? n.protocol.slice(0, -1) : n.protocol
          ))

          i.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid protocol",
            pattern: t.protocol.source,
            input: i.value,
            inst: r,
            continue: !t.abort
          });
        }
        if (t.normalize) i.value = n.href;else
        i.value = o;
        return;
      } catch (o) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          input: i.value,
          inst: r,
          continue: !t.abort
        });
      }
    };
  }),
  tm = $("$ZodEmoji", (r, t) => {
    t.pattern ?? (t.pattern = bg()), M.init(r, t);
  }),
  nm = $("$ZodNanoID", (r, t) => {
    t.pattern ?? (t.pattern = cg), M.init(r, t);
  }),
  im = $("$ZodCUID", (r, t) => {
    t.pattern ?? (t.pattern = ng), M.init(r, t);
  }),
  om = $("$ZodCUID2", (r, t) => {
    t.pattern ?? (t.pattern = ig), M.init(r, t);
  }),
  em = $("$ZodULID", (r, t) => {
    t.pattern ?? (t.pattern = og), M.init(r, t);
  }),
  lm = $("$ZodXID", (r, t) => {
    t.pattern ?? (t.pattern = eg), M.init(r, t);
  }),
  cm = $("$ZodKSUID", (r, t) => {
    t.pattern ?? (t.pattern = lg), M.init(r, t);
  }),
  um = $("$ZodISODateTime", (r, t) => {
    t.pattern ?? (t.pattern = _g(t)), M.init(r, t);
  }),
  gm = $("$ZodISODate", (r, t) => {
    t.pattern ?? (t.pattern = ag), M.init(r, t);
  }),
  mm = $("$ZodISOTime", (r, t) => {
    t.pattern ?? (t.pattern = pg(t)), M.init(r, t);
  }),
  bm = $("$ZodISODuration", (r, t) => {
    t.pattern ?? (t.pattern = ug), M.init(r, t);
  }),
  vm = $("$ZodIPv4", (r, t) => {
    t.pattern ?? (t.pattern = vg),
    M.init(r, t),
    r._zod.onattach.push((i) => {
      let o = i._zod.bag;
      o.format = "ipv4";
    });
  }),
  hm = $("$ZodIPv6", (r, t) => {
    t.pattern ?? (t.pattern = hg),
    M.init(r, t),
    r._zod.onattach.push((i) => {
      let o = i._zod.bag;
      o.format = "ipv6";
    }),
    r._zod.check = (i) => {
      try {
        new URL(`http://[${i.value}]`);
      } catch {
        i.issues.push({
          code: "invalid_format",
          format: "ipv6",
          input: i.value,
          inst: r,
          continue: !t.abort
        });
      }
    };
  }),
  $m = $("$ZodCIDRv4", (r, t) => {
    t.pattern ?? (t.pattern = $g), M.init(r, t);
  }),
  xm = $("$ZodCIDRv6", (r, t) => {
    t.pattern ?? (t.pattern = xg),
    M.init(r, t),
    r._zod.check = (i) => {
      let o = i.value.split("/");
      try {
        if (o.length !== 2) throw new Error();
        let [n, e] = o;
        if (!e) throw new Error();
        let l = Number(e);
        if (`${l}` !== e) throw new Error();
        if (l < 0 || l > 128) throw new Error();
        new URL(`http://[${n}]`);
      } catch {
        i.issues.push({
          code: "invalid_format",
          format: "cidrv6",
          input: i.value,
          inst: r,
          continue: !t.abort
        });
      }
    };
  });
function fm(r) {
  if (r === "") return !0;
  if (r.length % 4 !== 0) return !1;
  try {
    return atob(r), !0;
  } catch {
    return !1;
  }
}
var wm = $("$ZodBase64", (r, t) => {
  t.pattern ?? (t.pattern = fg),
  M.init(r, t),
  r._zod.onattach.push((i) => {
    i._zod.bag.contentEncoding = "base64";
  }),
  r._zod.check = (i) => {
    if (fm(i.value)) return;
    i.issues.push({
      code: "invalid_format",
      format: "base64",
      input: i.value,
      inst: r,
      continue: !t.abort
    });
  };
});
function aw(r) {
  if (!Po.test(r)) return !1;
  let t = r.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"),
    i = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return fm(i);
}
var zm = $("$ZodBase64URL", (r, t) => {
    t.pattern ?? (t.pattern = Po),
    M.init(r, t),
    r._zod.onattach.push((i) => {
      i._zod.bag.contentEncoding = "base64url";
    }),
    r._zod.check = (i) => {
      if (aw(i.value)) return;
      i.issues.push({
        code: "invalid_format",
        format: "base64url",
        input: i.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  am = $("$ZodE164", (r, t) => {
    t.pattern ?? (t.pattern = zg), M.init(r, t);
  });
function pw(r, t = null) {
  try {
    let i = r.split(".");
    if (i.length !== 3) return !1;
    let [o] = i;
    if (!o) return !1;
    let n = JSON.parse(atob(o));
    if ("typ" in n && n?.typ !== "JWT") return !1;
    if (!n.alg) return !1;
    if (t && (!("alg" in n) || n.alg !== t)) return !1;
    return !0;
  } catch {
    return !1;
  }
}
var pm = $("$ZodJWT", (r, t) => {
    M.init(r, t),
    r._zod.check = (i) => {
      if (pw(i.value, t.alg)) return;
      i.issues.push({
        code: "invalid_format",
        format: "jwt",
        input: i.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  _m = $("$ZodCustomStringFormat", (r, t) => {
    M.init(r, t),
    r._zod.check = (i) => {
      if (t.fn(i.value)) return;
      i.issues.push({
        code: "invalid_format",
        format: t.format,
        input: i.value,
        inst: r,
        continue: !t.abort
      });
    };
  }),
  Qo = $("$ZodNumber", (r, t) => {
    L.init(r, t),
    r._zod.pattern = r._zod.bag.pattern ?? Ig,
    r._zod.parse = (i, o) => {
      if (t.coerce)
      try {
        i.value = Number(i.value);
      } catch (l) {}
      let n = i.value;
      if (typeof n === "number" && !Number.isNaN(n) && Number.isFinite(n))
      return i;
      let e =
      typeof n === "number" ?
      Number.isNaN(n) ?
      "NaN" :
      !Number.isFinite(n) ?
      "Infinity" :
      void 0 :
      void 0;
      return (
        i.issues.push({
          expected: "number",
          code: "invalid_type",
          input: n,
          inst: r,
          ...(e ? { received: e } : {})
        }),
        i);

    };
  }),
  Dm = $("$ZodNumber", (r, t) => {
    Wg.init(r, t), Qo.init(r, t);
  }),
  ni = $("$ZodBoolean", (r, t) => {
    L.init(r, t),
    r._zod.pattern = kg,
    r._zod.parse = (i, o) => {
      if (t.coerce)
      try {
        i.value = Boolean(i.value);
      } catch (e) {}
      let n = i.value;
      if (typeof n === "boolean") return i;
      return (
        i.issues.push({
          expected: "boolean",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  Fo = $("$ZodBigInt", (r, t) => {
    L.init(r, t),
    r._zod.pattern = jg,
    r._zod.parse = (i, o) => {
      if (t.coerce)
      try {
        i.value = BigInt(i.value);
      } catch (n) {}
      if (typeof i.value === "bigint") return i;
      return (
        i.issues.push({
          expected: "bigint",
          code: "invalid_type",
          input: i.value,
          inst: r
        }),
        i);

    };
  }),
  jm = $("$ZodBigInt", (r, t) => {
    Kg.init(r, t), Fo.init(r, t);
  }),
  Om = $("$ZodSymbol", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (typeof n === "symbol") return i;
      return (
        i.issues.push({
          expected: "symbol",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  Im = $("$ZodUndefined", (r, t) => {
    L.init(r, t),
    r._zod.pattern = Jg,
    r._zod.values = new Set([void 0]),
    r._zod.optin = "optional",
    r._zod.optout = "optional",
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (typeof n === "undefined") return i;
      return (
        i.issues.push({
          expected: "undefined",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  km = $("$ZodNull", (r, t) => {
    L.init(r, t),
    r._zod.pattern = Ug,
    r._zod.values = new Set([null]),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (n === null) return i;
      return (
        i.issues.push({
          expected: "null",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  Um = $("$ZodAny", (r, t) => {
    L.init(r, t), r._zod.parse = (i) => i;
  }),
  Jm = $("$ZodUnknown", (r, t) => {
    L.init(r, t), r._zod.parse = (i) => i;
  }),
  Pm = $("$ZodNever", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      return (
        i.issues.push({
          expected: "never",
          code: "invalid_type",
          input: i.value,
          inst: r
        }),
        i);

    };
  }),
  Xm = $("$ZodVoid", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (typeof n === "undefined") return i;
      return (
        i.issues.push({
          expected: "void",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  qm = $("$ZodDate", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      if (t.coerce)
      try {
        i.value = new Date(i.value);
      } catch (u) {}
      let n = i.value,
        e = n instanceof Date;
      if (e && !Number.isNaN(n.getTime())) return i;
      return (
        i.issues.push({
          expected: "date",
          code: "invalid_type",
          input: n,
          ...(e ? { received: "Invalid Date" } : {}),
          inst: r
        }),
        i);

    };
  });
function gw(r, t, i) {
  if (r.issues.length) t.issues.push(...qr(i, r.issues));
  t.value[i] = r.value;
}
var Wm = $("$ZodArray", (r, t) => {
  L.init(r, t),
  r._zod.parse = (i, o) => {
    let n = i.value;
    if (!Array.isArray(n))
    return (
      i.issues.push({
        expected: "array",
        code: "invalid_type",
        input: n,
        inst: r
      }),
      i);

    i.value = Array(n.length);
    let e = [];
    for (let l = 0; l < n.length; l++) {
      let u = n[l],
        g = t.element._zod.run({ value: u, issues: [] }, o);
      if (g instanceof Promise) e.push(g.then((c) => gw(c, i, l)));else
      gw(g, i, l);
    }
    if (e.length) return Promise.all(e).then(() => i);
    return i;
  };
});
function Eo(r, t, i, o) {
  if (r.issues.length) t.issues.push(...qr(i, r.issues));
  if (r.value === void 0) {
    if (i in o) t.value[i] = void 0;
  } else t.value[i] = r.value;
}
function _w(r) {
  let t = Object.keys(r.shape);
  for (let o of t)
  if (!r.shape?.[o]?._zod?.traits?.has("$ZodType"))
  throw new Error(`Invalid element at key "${o}": expected a Zod schema`);
  let i = Zu(r.shape);
  return {
    ...r,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(i)
  };
}
function Dw(r, t, i, o, n, e) {
  let l = [],
    u = n.keySet,
    g = n.catchall._zod,
    c = g.def.type;
  for (let m of Object.keys(t)) {
    if (u.has(m)) continue;
    if (c === "never") {
      l.push(m);
      continue;
    }
    let v = g.run({ value: t[m], issues: [] }, o);
    if (v instanceof Promise) r.push(v.then((h) => Eo(h, i, m, t)));else
    Eo(v, i, m, t);
  }
  if (l.length)
  i.issues.push({ code: "unrecognized_keys", keys: l, input: t, inst: e });
  if (!r.length) return i;
  return Promise.all(r).then(() => {
    return i;
  });
}
var jw = $("$ZodObject", (r, t) => {
    if (L.init(r, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
      let u = t.shape;
      Object.defineProperty(t, "shape", {
        get: () => {
          let g = { ...u };
          return Object.defineProperty(t, "shape", { value: g }), g;
        }
      });
    }
    let o = on(() => _w(t));
    F(r._zod, "propValues", () => {
      let u = t.shape,
        g = {};
      for (let c in u) {
        let m = u[c]._zod;
        if (m.values) {
          g[c] ?? (g[c] = new Set());
          for (let v of m.values) g[c].add(v);
        }
      }
      return g;
    });
    let n = Xt,
      e = t.catchall,
      l;
    r._zod.parse = (u, g) => {
      l ?? (l = o.value);
      let c = u.value;
      if (!n(c))
      return (
        u.issues.push({
          expected: "object",
          code: "invalid_type",
          input: c,
          inst: r
        }),
        u);

      u.value = {};
      let m = [],
        v = l.shape;
      for (let h of l.keys) {
        let f = v[h]._zod.run({ value: c[h], issues: [] }, g);
        if (f instanceof Promise) m.push(f.then((D) => Eo(D, u, h, c)));else
        Eo(f, u, h, c);
      }
      if (!e) return m.length ? Promise.all(m).then(() => u) : u;
      return Dw(m, c, u, g, o.value, r);
    };
  }),
  Km = $("$ZodObjectJIT", (r, t) => {
    jw.init(r, t);
    let i = r._zod.parse,
      o = on(() => _w(t)),
      n = (h) => {
        let b = new Wo(["shape", "payload", "ctx"]),
          f = o.value,
          D = (V) => {
            let X = wo(V);
            return `shape[${X}]._zod.run({ value: input[${X}], issues: [] }, ctx)`;
          };
        b.write("const input = payload.value;");
        let O = Object.create(null),
          _ = 0;
        for (let V of f.keys) O[V] = `key_${_++}`;
        b.write("const newResult = {};");
        for (let V of f.keys) {
          let X = O[V],
            W = wo(V);
          b.write(`const ${X} = ${D(V)};`),
          b.write(`
        if (${X}.issues.length) {
          payload.issues = payload.issues.concat(${X}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${W}, ...iss.path] : [${W}]
          })));
        }
        
        
        if (${X}.value === undefined) {
          if (${W} in input) {
            newResult[${W}] = undefined;
          }
        } else {
          newResult[${W}] = ${X}.value;
        }
        
      `);
        }
        b.write("payload.value = newResult;"), b.write("return payload;");
        let J = b.compile();
        return (V, X) => J(h, V, X);
      },
      e,
      l = Xt,
      u = !yn.jitless,
      c = u && Hu.value,
      m = t.catchall,
      v;
    r._zod.parse = (h, b) => {
      v ?? (v = o.value);
      let f = h.value;
      if (!l(f))
      return (
        h.issues.push({
          expected: "object",
          code: "invalid_type",
          input: f,
          inst: r
        }),
        h);

      if (u && c && b?.async === !1 && b.jitless !== !0) {
        if (!e) e = n(t.shape);
        if (h = e(h, b), !m) return h;
        return Dw([], f, h, b, v, r);
      }
      return i(h, b);
    };
  });
function mw(r, t, i, o) {
  for (let e of r) if (e.issues.length === 0) return t.value = e.value, t;
  let n = r.filter((e) => !pt(e));
  if (n.length === 1) return t.value = n[0].value, n[0];
  return (
    t.issues.push({
      code: "invalid_union",
      input: t.value,
      inst: i,
      errors: r.map((e) => e.issues.map((l) => Wr(l, o, br())))
    }),
    t);

}
var So = $("$ZodUnion", (r, t) => {
    L.init(r, t),
    F(r._zod, "optin", () =>
    t.options.some((n) => n._zod.optin === "optional") ?
    "optional" :
    void 0
    ),
    F(r._zod, "optout", () =>
    t.options.some((n) => n._zod.optout === "optional") ?
    "optional" :
    void 0
    ),
    F(r._zod, "values", () => {
      if (t.options.every((n) => n._zod.values))
      return new Set(t.options.flatMap((n) => Array.from(n._zod.values)));
      return;
    }),
    F(r._zod, "pattern", () => {
      if (t.options.every((n) => n._zod.pattern)) {
        let n = t.options.map((e) => e._zod.pattern);
        return new RegExp(`^(${n.map((e) => Rn(e.source)).join("|")})$`);
      }
      return;
    });
    let i = t.options.length === 1,
      o = t.options[0]._zod.run;
    r._zod.parse = (n, e) => {
      if (i) return o(n, e);
      let l = !1,
        u = [];
      for (let g of t.options) {
        let c = g._zod.run({ value: n.value, issues: [] }, e);
        if (c instanceof Promise) u.push(c), l = !0;else
        {
          if (c.issues.length === 0) return c;
          u.push(c);
        }
      }
      if (!l) return mw(u, n, r, e);
      return Promise.all(u).then((g) => {
        return mw(g, n, r, e);
      });
    };
  }),
  Lm = $("$ZodDiscriminatedUnion", (r, t) => {
    So.init(r, t);
    let i = r._zod.parse;
    F(r._zod, "propValues", () => {
      let n = {};
      for (let e of t.options) {
        let l = e._zod.propValues;
        if (!l || Object.keys(l).length === 0)
        throw new Error(
          `Invalid discriminated union option at index "${t.options.indexOf(e)}"`
        );
        for (let [u, g] of Object.entries(l)) {
          if (!n[u]) n[u] = new Set();
          for (let c of g) n[u].add(c);
        }
      }
      return n;
    });
    let o = on(() => {
      let n = t.options,
        e = new Map();
      for (let l of n) {
        let u = l._zod.propValues?.[t.discriminator];
        if (!u || u.size === 0)
        throw new Error(
          `Invalid discriminated union option at index "${t.options.indexOf(l)}"`
        );
        for (let g of u) {
          if (e.has(g))
          throw new Error(`Duplicate discriminator value "${String(g)}"`);
          e.set(g, l);
        }
      }
      return e;
    });
    r._zod.parse = (n, e) => {
      let l = n.value;
      if (!Xt(l))
      return (
        n.issues.push({
          code: "invalid_type",
          expected: "object",
          input: l,
          inst: r
        }),
        n);

      let u = o.value.get(l?.[t.discriminator]);
      if (u) return u._zod.run(n, e);
      if (t.unionFallback) return i(n, e);
      return (
        n.issues.push({
          code: "invalid_union",
          errors: [],
          note: "No matching discriminator",
          discriminator: t.discriminator,
          input: l,
          path: [t.discriminator],
          inst: r
        }),
        n);

    };
  }),
  Vm = $("$ZodIntersection", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value,
        e = t.left._zod.run({ value: n, issues: [] }, o),
        l = t.right._zod.run({ value: n, issues: [] }, o);
      if (e instanceof Promise || l instanceof Promise)
      return Promise.all([e, l]).then(([g, c]) => {
        return bw(i, g, c);
      });
      return bw(i, e, l);
    };
  });
function Cg(r, t) {
  if (r === t) return { valid: !0, data: r };
  if (r instanceof Date && t instanceof Date && +r === +t)
  return { valid: !0, data: r };
  if (at(r) && at(t)) {
    let i = Object.keys(t),
      o = Object.keys(r).filter((e) => i.indexOf(e) !== -1),
      n = { ...r, ...t };
    for (let e of o) {
      let l = Cg(r[e], t[e]);
      if (!l.valid)
      return { valid: !1, mergeErrorPath: [e, ...l.mergeErrorPath] };
      n[e] = l.data;
    }
    return { valid: !0, data: n };
  }
  if (Array.isArray(r) && Array.isArray(t)) {
    if (r.length !== t.length) return { valid: !1, mergeErrorPath: [] };
    let i = [];
    for (let o = 0; o < r.length; o++) {
      let n = r[o],
        e = t[o],
        l = Cg(n, e);
      if (!l.valid)
      return { valid: !1, mergeErrorPath: [o, ...l.mergeErrorPath] };
      i.push(l.data);
    }
    return { valid: !0, data: i };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function bw(r, t, i) {
  if (t.issues.length) r.issues.push(...t.issues);
  if (i.issues.length) r.issues.push(...i.issues);
  if (pt(r)) return r;
  let o = Cg(t.value, i.value);
  if (!o.valid)
  throw new Error(
    `Unmergable intersection. Error path: ${JSON.stringify(o.mergeErrorPath)}`
  );
  return r.value = o.data, r;
}
var Go = $("$ZodTuple", (r, t) => {
  L.init(r, t);
  let i = t.items,
    o =
    i.length - [...i].reverse().findIndex((n) => n._zod.optin !== "optional");
  r._zod.parse = (n, e) => {
    let l = n.value;
    if (!Array.isArray(l))
    return (
      n.issues.push({
        input: l,
        inst: r,
        expected: "tuple",
        code: "invalid_type"
      }),
      n);

    n.value = [];
    let u = [];
    if (!t.rest) {
      let c = l.length > i.length,
        m = l.length < o - 1;
      if (c || m)
      return (
        n.issues.push({
          ...(c ?
          { code: "too_big", maximum: i.length } :
          { code: "too_small", minimum: i.length }),
          input: l,
          inst: r,
          origin: "array"
        }),
        n);

    }
    let g = -1;
    for (let c of i) {
      if (g++, g >= l.length) {
        if (g >= o) continue;
      }
      let m = c._zod.run({ value: l[g], issues: [] }, e);
      if (m instanceof Promise) u.push(m.then((v) => Ko(v, n, g)));else
      Ko(m, n, g);
    }
    if (t.rest) {
      let c = l.slice(i.length);
      for (let m of c) {
        g++;
        let v = t.rest._zod.run({ value: m, issues: [] }, e);
        if (v instanceof Promise) u.push(v.then((h) => Ko(h, n, g)));else
        Ko(v, n, g);
      }
    }
    if (u.length) return Promise.all(u).then(() => n);
    return n;
  };
});
function Ko(r, t, i) {
  if (r.issues.length) t.issues.push(...qr(i, r.issues));
  t.value[i] = r.value;
}
var Ym = $("$ZodRecord", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (!at(n))
      return (
        i.issues.push({
          expected: "record",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

      let e = [];
      if (t.keyType._zod.values) {
        let l = t.keyType._zod.values;
        i.value = {};
        for (let g of l)
        if (
        typeof g === "string" ||
        typeof g === "number" ||
        typeof g === "symbol")
        {
          let c = t.valueType._zod.run({ value: n[g], issues: [] }, o);
          if (c instanceof Promise)
          e.push(
            c.then((m) => {
              if (m.issues.length) i.issues.push(...qr(g, m.issues));
              i.value[g] = m.value;
            })
          );else
          {
            if (c.issues.length) i.issues.push(...qr(g, c.issues));
            i.value[g] = c.value;
          }
        }
        let u;
        for (let g in n) if (!l.has(g)) u = u ?? [], u.push(g);
        if (u && u.length > 0)
        i.issues.push({
          code: "unrecognized_keys",
          input: n,
          inst: r,
          keys: u
        });
      } else {
        i.value = {};
        for (let l of Reflect.ownKeys(n)) {
          if (l === "__proto__") continue;
          let u = t.keyType._zod.run({ value: l, issues: [] }, o);
          if (u instanceof Promise)
          throw new Error(
            "Async schemas not supported in object keys currently"
          );
          if (u.issues.length) {
            i.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: u.issues.map((c) => Wr(c, o, br())),
              input: l,
              path: [l],
              inst: r
            }),
            i.value[u.value] = u.value;
            continue;
          }
          let g = t.valueType._zod.run({ value: n[l], issues: [] }, o);
          if (g instanceof Promise)
          e.push(
            g.then((c) => {
              if (c.issues.length) i.issues.push(...qr(l, c.issues));
              i.value[u.value] = c.value;
            })
          );else
          {
            if (g.issues.length) i.issues.push(...qr(l, g.issues));
            i.value[u.value] = g.value;
          }
        }
      }
      if (e.length) return Promise.all(e).then(() => i);
      return i;
    };
  }),
  Em = $("$ZodMap", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (!(n instanceof Map))
      return (
        i.issues.push({
          expected: "map",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

      let e = [];
      i.value = new Map();
      for (let [l, u] of n) {
        let g = t.keyType._zod.run({ value: l, issues: [] }, o),
          c = t.valueType._zod.run({ value: u, issues: [] }, o);
        if (g instanceof Promise || c instanceof Promise)
        e.push(
          Promise.all([g, c]).then(([m, v]) => {
            vw(m, v, i, l, n, r, o);
          })
        );else
        vw(g, c, i, l, n, r, o);
      }
      if (e.length) return Promise.all(e).then(() => i);
      return i;
    };
  });
function vw(r, t, i, o, n, e, l) {
  if (r.issues.length)
  if (Mn.has(typeof o)) i.issues.push(...qr(o, r.issues));else

  i.issues.push({
    code: "invalid_key",
    origin: "map",
    input: n,
    inst: e,
    issues: r.issues.map((u) => Wr(u, l, br()))
  });
  if (t.issues.length)
  if (Mn.has(typeof o)) i.issues.push(...qr(o, t.issues));else

  i.issues.push({
    origin: "map",
    code: "invalid_element",
    input: n,
    inst: e,
    key: o,
    issues: t.issues.map((u) => Wr(u, l, br()))
  });
  i.value.set(r.value, t.value);
}
var Qm = $("$ZodSet", (r, t) => {
  L.init(r, t),
  r._zod.parse = (i, o) => {
    let n = i.value;
    if (!(n instanceof Set))
    return (
      i.issues.push({
        input: n,
        inst: r,
        expected: "set",
        code: "invalid_type"
      }),
      i);

    let e = [];
    i.value = new Set();
    for (let l of n) {
      let u = t.valueType._zod.run({ value: l, issues: [] }, o);
      if (u instanceof Promise) e.push(u.then((g) => hw(g, i)));else
      hw(u, i);
    }
    if (e.length) return Promise.all(e).then(() => i);
    return i;
  };
});
function hw(r, t) {
  if (r.issues.length) t.issues.push(...r.issues);
  t.value.add(r.value);
}
var Fm = $("$ZodEnum", (r, t) => {
    L.init(r, t);
    let i = Hn(t.entries),
      o = new Set(i);
    r._zod.values = o,
    r._zod.pattern = new RegExp(
      `^(${i.
      filter((n) => Mn.has(typeof n)).
      map((n) => typeof n === "string" ? Cr(n) : n.toString()).
      join("|")})$`
    ),
    r._zod.parse = (n, e) => {
      let l = n.value;
      if (o.has(l)) return n;
      return (
        n.issues.push({
          code: "invalid_value",
          values: i,
          input: l,
          inst: r
        }),
        n);

    };
  }),
  Sm = $("$ZodLiteral", (r, t) => {
    if (L.init(r, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
    r._zod.values = new Set(t.values),
    r._zod.pattern = new RegExp(
      `^(${t.values.map((i) => typeof i === "string" ? Cr(i) : i ? Cr(i.toString()) : String(i)).join("|")})$`
    ),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (r._zod.values.has(n)) return i;
      return (
        i.issues.push({
          code: "invalid_value",
          values: t.values,
          input: n,
          inst: r
        }),
        i);

    };
  }),
  Gm = $("$ZodFile", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      let n = i.value;
      if (n instanceof File) return i;
      return (
        i.issues.push({
          expected: "file",
          code: "invalid_type",
          input: n,
          inst: r
        }),
        i);

    };
  }),
  Nm = $("$ZodTransform", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") throw new Pt(r.constructor.name);
      let n = t.transform(i.value, i);
      if (o.async)
      return (n instanceof Promise ? n : Promise.resolve(n)).then((l) => {
        return i.value = l, i;
      });
      if (n instanceof Promise) throw new Zr();
      return i.value = n, i;
    };
  });
function $w(r, t) {
  if (r.issues.length && t === void 0) return { issues: [], value: void 0 };
  return r;
}
var Bm = $("$ZodOptional", (r, t) => {
    L.init(r, t),
    r._zod.optin = "optional",
    r._zod.optout = "optional",
    F(r._zod, "values", () => {
      return t.innerType._zod.values ?
      new Set([...t.innerType._zod.values, void 0]) :
      void 0;
    }),
    F(r._zod, "pattern", () => {
      let i = t.innerType._zod.pattern;
      return i ? new RegExp(`^(${Rn(i.source)})?$`) : void 0;
    }),
    r._zod.parse = (i, o) => {
      if (t.innerType._zod.optin === "optional") {
        let n = t.innerType._zod.run(i, o);
        if (n instanceof Promise) return n.then((e) => $w(e, i.value));
        return $w(n, i.value);
      }
      if (i.value === void 0) return i;
      return t.innerType._zod.run(i, o);
    };
  }),
  ym = $("$ZodNullable", (r, t) => {
    L.init(r, t),
    F(r._zod, "optin", () => t.innerType._zod.optin),
    F(r._zod, "optout", () => t.innerType._zod.optout),
    F(r._zod, "pattern", () => {
      let i = t.innerType._zod.pattern;
      return i ? new RegExp(`^(${Rn(i.source)}|null)$`) : void 0;
    }),
    F(r._zod, "values", () => {
      return t.innerType._zod.values ?
      new Set([...t.innerType._zod.values, null]) :
      void 0;
    }),
    r._zod.parse = (i, o) => {
      if (i.value === null) return i;
      return t.innerType._zod.run(i, o);
    };
  }),
  Am = $("$ZodDefault", (r, t) => {
    L.init(r, t),
    r._zod.optin = "optional",
    F(r._zod, "values", () => t.innerType._zod.values),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") return t.innerType._zod.run(i, o);
      if (i.value === void 0) return i.value = t.defaultValue, i;
      let n = t.innerType._zod.run(i, o);
      if (n instanceof Promise) return n.then((e) => xw(e, t));
      return xw(n, t);
    };
  });
function xw(r, t) {
  if (r.value === void 0) r.value = t.defaultValue;
  return r;
}
var Hm = $("$ZodPrefault", (r, t) => {
    L.init(r, t),
    r._zod.optin = "optional",
    F(r._zod, "values", () => t.innerType._zod.values),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") return t.innerType._zod.run(i, o);
      if (i.value === void 0) i.value = t.defaultValue;
      return t.innerType._zod.run(i, o);
    };
  }),
  Rm = $("$ZodNonOptional", (r, t) => {
    L.init(r, t),
    F(r._zod, "values", () => {
      let i = t.innerType._zod.values;
      return i ? new Set([...i].filter((o) => o !== void 0)) : void 0;
    }),
    r._zod.parse = (i, o) => {
      let n = t.innerType._zod.run(i, o);
      if (n instanceof Promise) return n.then((e) => fw(e, r));
      return fw(n, r);
    };
  });
function fw(r, t) {
  if (!r.issues.length && r.value === void 0)
  r.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: r.value,
    inst: t
  });
  return r;
}
var Mm = $("$ZodSuccess", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") throw new Pt("ZodSuccess");
      let n = t.innerType._zod.run(i, o);
      if (n instanceof Promise)
      return n.then((e) => {
        return i.value = e.issues.length === 0, i;
      });
      return i.value = n.issues.length === 0, i;
    };
  }),
  Zm = $("$ZodCatch", (r, t) => {
    L.init(r, t),
    F(r._zod, "optin", () => t.innerType._zod.optin),
    F(r._zod, "optout", () => t.innerType._zod.optout),
    F(r._zod, "values", () => t.innerType._zod.values),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") return t.innerType._zod.run(i, o);
      let n = t.innerType._zod.run(i, o);
      if (n instanceof Promise)
      return n.then((e) => {
        if (i.value = e.value, e.issues.length)
        i.value = t.catchValue({
          ...i,
          error: { issues: e.issues.map((l) => Wr(l, o, br())) },
          input: i.value
        }),
        i.issues = [];
        return i;
      });
      if (i.value = n.value, n.issues.length)
      i.value = t.catchValue({
        ...i,
        error: { issues: n.issues.map((e) => Wr(e, o, br())) },
        input: i.value
      }),
      i.issues = [];
      return i;
    };
  }),
  Cm = $("$ZodNaN", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      if (typeof i.value !== "number" || !Number.isNaN(i.value))
      return (
        i.issues.push({
          input: i.value,
          inst: r,
          expected: "nan",
          code: "invalid_type"
        }),
        i);

      return i;
    };
  }),
  Tm = $("$ZodPipe", (r, t) => {
    L.init(r, t),
    F(r._zod, "values", () => t.in._zod.values),
    F(r._zod, "optin", () => t.in._zod.optin),
    F(r._zod, "optout", () => t.out._zod.optout),
    F(r._zod, "propValues", () => t.in._zod.propValues),
    r._zod.parse = (i, o) => {
      if (o.direction === "backward") {
        let e = t.out._zod.run(i, o);
        if (e instanceof Promise) return e.then((l) => Lo(l, t.in, o));
        return Lo(e, t.in, o);
      }
      let n = t.in._zod.run(i, o);
      if (n instanceof Promise) return n.then((e) => Lo(e, t.out, o));
      return Lo(n, t.out, o);
    };
  });
function Lo(r, t, i) {
  if (r.issues.length) return r.aborted = !0, r;
  return t._zod.run({ value: r.value, issues: r.issues }, i);
}
var ii = $("$ZodCodec", (r, t) => {
  L.init(r, t),
  F(r._zod, "values", () => t.in._zod.values),
  F(r._zod, "optin", () => t.in._zod.optin),
  F(r._zod, "optout", () => t.out._zod.optout),
  F(r._zod, "propValues", () => t.in._zod.propValues),
  r._zod.parse = (i, o) => {
    if ((o.direction || "forward") === "forward") {
      let e = t.in._zod.run(i, o);
      if (e instanceof Promise) return e.then((l) => Vo(l, t, o));
      return Vo(e, t, o);
    } else {
      let e = t.out._zod.run(i, o);
      if (e instanceof Promise) return e.then((l) => Vo(l, t, o));
      return Vo(e, t, o);
    }
  };
});
function Vo(r, t, i) {
  if (r.issues.length) return r.aborted = !0, r;
  if ((i.direction || "forward") === "forward") {
    let n = t.transform(r.value, r);
    if (n instanceof Promise) return n.then((e) => Yo(r, e, t.out, i));
    return Yo(r, n, t.out, i);
  } else {
    let n = t.reverseTransform(r.value, r);
    if (n instanceof Promise) return n.then((e) => Yo(r, e, t.in, i));
    return Yo(r, n, t.in, i);
  }
}
function Yo(r, t, i, o) {
  if (r.issues.length) return r.aborted = !0, r;
  return i._zod.run({ value: t, issues: r.issues }, o);
}
var dm = $("$ZodReadonly", (r, t) => {
  L.init(r, t),
  F(r._zod, "propValues", () => t.innerType._zod.propValues),
  F(r._zod, "values", () => t.innerType._zod.values),
  F(r._zod, "optin", () => t.innerType._zod.optin),
  F(r._zod, "optout", () => t.innerType._zod.optout),
  r._zod.parse = (i, o) => {
    if (o.direction === "backward") return t.innerType._zod.run(i, o);
    let n = t.innerType._zod.run(i, o);
    if (n instanceof Promise) return n.then(ww);
    return ww(n);
  };
});
function ww(r) {
  return r.value = Object.freeze(r.value), r;
}
var sm = $("$ZodTemplateLiteral", (r, t) => {
    L.init(r, t);
    let i = [];
    for (let o of t.parts)
    if (typeof o === "object" && o !== null) {
      if (!o._zod.pattern)
      throw new Error(
        `Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`
      );
      let n =
      o._zod.pattern instanceof RegExp ?
      o._zod.pattern.source :
      o._zod.pattern;
      if (!n)
      throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let e = n.startsWith("^") ? 1 : 0,
        l = n.endsWith("$") ? n.length - 1 : n.length;
      i.push(n.slice(e, l));
    } else if (o === null || Mu.has(typeof o)) i.push(Cr(`${o}`));else
    throw new Error(`Invalid template literal part: ${o}`);
    r._zod.pattern = new RegExp(`^${i.join("")}$`),
    r._zod.parse = (o, n) => {
      if (typeof o.value !== "string")
      return (
        o.issues.push({
          input: o.value,
          inst: r,
          expected: "template_literal",
          code: "invalid_type"
        }),
        o);

      if (r._zod.pattern.lastIndex = 0, !r._zod.pattern.test(o.value))
      return (
        o.issues.push({
          input: o.value,
          inst: r,
          code: "invalid_format",
          format: t.format ?? "template_literal",
          pattern: r._zod.pattern.source
        }),
        o);

      return o;
    };
  }),
  rb = $("$ZodFunction", (r, t) => {
    return (
      L.init(r, t),
      r._def = t,
      r._zod.def = t,
      r.implement = (i) => {
        if (typeof i !== "function")
        throw new Error("implement() must be called with a function");
        return function (...o) {
          let n = r._def.input ? ao(r._def.input, o) : o,
            e = Reflect.apply(i, this, n);
          if (r._def.output) return ao(r._def.output, e);
          return e;
        };
      },
      r.implementAsync = (i) => {
        if (typeof i !== "function")
        throw new Error("implementAsync() must be called with a function");
        return async function (...o) {
          let n = r._def.input ? await po(r._def.input, o) : o,
            e = await Reflect.apply(i, this, n);
          if (r._def.output) return await po(r._def.output, e);
          return e;
        };
      },
      r._zod.parse = (i, o) => {
        if (typeof i.value !== "function")
        return (
          i.issues.push({
            code: "invalid_type",
            expected: "function",
            input: i.value,
            inst: r
          }),
          i);

        if (r._def.output && r._def.output._zod.def.type === "promise")
        i.value = r.implementAsync(i.value);else
        i.value = r.implement(i.value);
        return i;
      },
      r.input = (...i) => {
        let o = r.constructor;
        if (Array.isArray(i[0]))
        return new o({
          type: "function",
          input: new Go({ type: "tuple", items: i[0], rest: i[1] }),
          output: r._def.output
        });
        return new o({ type: "function", input: i[0], output: r._def.output });
      },
      r.output = (i) => {
        return new r.constructor({
          type: "function",
          input: r._def.input,
          output: i
        });
      },
      r);

  }),
  tb = $("$ZodPromise", (r, t) => {
    L.init(r, t),
    r._zod.parse = (i, o) => {
      return Promise.resolve(i.value).then((n) =>
      t.innerType._zod.run({ value: n, issues: [] }, o)
      );
    };
  }),
  nb = $("$ZodLazy", (r, t) => {
    L.init(r, t),
    F(r._zod, "innerType", () => t.getter()),
    F(r._zod, "pattern", () => r._zod.innerType._zod.pattern),
    F(r._zod, "propValues", () => r._zod.innerType._zod.propValues),
    F(r._zod, "optin", () => r._zod.innerType._zod.optin ?? void 0),
    F(r._zod, "optout", () => r._zod.innerType._zod.optout ?? void 0),
    r._zod.parse = (i, o) => {
      return r._zod.innerType._zod.run(i, o);
    };
  }),
  ib = $("$ZodCustom", (r, t) => {
    s.init(r, t),
    L.init(r, t),
    r._zod.parse = (i, o) => {
      return i;
    },
    r._zod.check = (i) => {
      let o = i.value,
        n = t.fn(o);
      if (n instanceof Promise) return n.then((e) => zw(e, i, o, r));
      zw(n, i, o, r);
      return;
    };
  });
function zw(r, t, i, o) {
  if (!r) {
    let n = {
      code: "custom",
      input: i,
      inst: o,
      path: [...(o._zod.def.path ?? [])],
      continue: !o._zod.def.abort
    };
    if (o._zod.def.params) n.params = o._zod.def.params;
    t.issues.push(en(n));
  }
}
var gi = {};
I(gi, {
  zhTW: () => Ab,
  zhCN: () => yb,
  yo: () => Hb,
  vi: () => Bb,
  ur: () => Nb,
  uk: () => ui,
  ua: () => Gb,
  tr: () => Sb,
  th: () => Fb,
  ta: () => Qb,
  sv: () => Eb,
  sl: () => Yb,
  ru: () => Vb,
  pt: () => Lb,
  ps: () => Wb,
  pl: () => Kb,
  ota: () => qb,
  no: () => Xb,
  nl: () => Pb,
  ms: () => Jb,
  mk: () => Ub,
  lt: () => kb,
  ko: () => Ib,
  km: () => ei,
  kh: () => Ob,
  ka: () => jb,
  ja: () => Db,
  it: () => _b,
  is: () => pb,
  id: () => ab,
  hu: () => zb,
  he: () => wb,
  frCA: () => fb,
  fr: () => xb,
  fi: () => $b,
  fa: () => hb,
  es: () => vb,
  eo: () => bb,
  en: () => oi,
  de: () => mb,
  da: () => gb,
  cs: () => ub,
  ca: () => cb,
  be: () => lb,
  az: () => eb,
  ar: () => ob
});
var lO = () => {
  let r = {
    string: { unit: "حرف", verb: "أن يحوي" },
    file: { unit: "بايت", verb: "أن يحوي" },
    array: { unit: "عنصر", verb: "أن يحوي" },
    set: { unit: "عنصر", verb: "أن يحوي" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "مدخل",
      email: "بريد إلكتروني",
      url: "رابط",
      emoji: "إيموجي",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "تاريخ ووقت بمعيار ISO",
      date: "تاريخ بمعيار ISO",
      time: "وقت بمعيار ISO",
      duration: "مدة بمعيار ISO",
      ipv4: "عنوان IPv4",
      ipv6: "عنوان IPv6",
      cidrv4: "مدى عناوين بصيغة IPv4",
      cidrv6: "مدى عناوين بصيغة IPv6",
      base64: "نَص بترميز base64-encoded",
      base64url: "نَص بترميز base64url-encoded",
      json_string: "نَص على هيئة JSON",
      e164: "رقم هاتف بمعيار E.164",
      jwt: "JWT",
      template_literal: "مدخل"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `مدخلات غير مقبولة: يفترض إدخال ${n.expected}، ولكن تم إدخال ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `مدخلات غير مقبولة: يفترض إدخال ${z(n.values[0])}`;
        return `اختيار غير مقبول: يتوقع انتقاء أحد هذه الخيارات: ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return ` أكبر من اللازم: يفترض أن تكون ${n.origin ?? "القيمة"} ${e} ${n.maximum.toString()} ${l.unit ?? "عنصر"}`;
          return `أكبر من اللازم: يفترض أن تكون ${n.origin ?? "القيمة"} ${e} ${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `أصغر من اللازم: يفترض لـ ${n.origin} أن يكون ${e} ${n.minimum.toString()} ${l.unit}`;
          return `أصغر من اللازم: يفترض لـ ${n.origin} أن يكون ${e} ${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `نَص غير مقبول: يجب أن يبدأ بـ "${n.prefix}"`;
          if (e.format === "ends_with")
          return `نَص غير مقبول: يجب أن ينتهي بـ "${e.suffix}"`;
          if (e.format === "includes")
          return `نَص غير مقبول: يجب أن يتضمَّن "${e.includes}"`;
          if (e.format === "regex")
          return `نَص غير مقبول: يجب أن يطابق النمط ${e.pattern}`;
          return `${o[e.format] ?? n.format} غير مقبول`;
        }
      case "not_multiple_of":
        return `رقم غير مقبول: يجب أن يكون من مضاعفات ${n.divisor}`;
      case "unrecognized_keys":
        return `معرف${n.keys.length > 1 ? "ات" : ""} غريب${n.keys.length > 1 ? "ة" : ""}: ${x(n.keys, "، ")}`;
      case "invalid_key":
        return `معرف غير مقبول في ${n.origin}`;
      case "invalid_union":
        return "مدخل غير مقبول";
      case "invalid_element":
        return `مدخل غير مقبول في ${n.origin}`;
      default:
        return "مدخل غير مقبول";
    }
  };
};
function ob() {
  return { localeError: lO() };
}
var cO = () => {
  let r = {
    string: { unit: "simvol", verb: "olmalıdır" },
    file: { unit: "bayt", verb: "olmalıdır" },
    array: { unit: "element", verb: "olmalıdır" },
    set: { unit: "element", verb: "olmalıdır" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "input",
      email: "email address",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datetime",
      date: "ISO date",
      time: "ISO time",
      duration: "ISO duration",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded string",
      base64url: "base64url-encoded string",
      json_string: "JSON string",
      e164: "E.164 number",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Yanlış dəyər: gözlənilən ${n.expected}, daxil olan ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Yanlış dəyər: gözlənilən ${z(n.values[0])}`;
        return `Yanlış seçim: aşağıdakılardan biri olmalıdır: ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Çox böyük: gözlənilən ${n.origin ?? "dəyər"} ${e}${n.maximum.toString()} ${l.unit ?? "element"}`;
          return `Çox böyük: gözlənilən ${n.origin ?? "dəyər"} ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Çox kiçik: gözlənilən ${n.origin} ${e}${n.minimum.toString()} ${l.unit}`;
          return `Çox kiçik: gözlənilən ${n.origin} ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Yanlış mətn: "${e.prefix}" ilə başlamalıdır`;
          if (e.format === "ends_with")
          return `Yanlış mətn: "${e.suffix}" ilə bitməlidir`;
          if (e.format === "includes")
          return `Yanlış mətn: "${e.includes}" daxil olmalıdır`;
          if (e.format === "regex")
          return `Yanlış mətn: ${e.pattern} şablonuna uyğun olmalıdır`;
          return `Yanlış ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Yanlış ədəd: ${n.divisor} ilə bölünə bilən olmalıdır`;
      case "unrecognized_keys":
        return `Tanınmayan açar${n.keys.length > 1 ? "lar" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} daxilində yanlış açar`;
      case "invalid_union":
        return "Yanlış dəyər";
      case "invalid_element":
        return `${n.origin} daxilində yanlış dəyər`;
      default:
        return "Yanlış dəyər";
    }
  };
};
function eb() {
  return { localeError: cO() };
}
function Ow(r, t, i, o) {
  let n = Math.abs(r),
    e = n % 10,
    l = n % 100;
  if (l >= 11 && l <= 19) return o;
  if (e === 1) return t;
  if (e >= 2 && e <= 4) return i;
  return o;
}
var uO = () => {
  let r = {
    string: {
      unit: { one: "сімвал", few: "сімвалы", many: "сімвалаў" },
      verb: "мець"
    },
    array: {
      unit: { one: "элемент", few: "элементы", many: "элементаў" },
      verb: "мець"
    },
    set: {
      unit: { one: "элемент", few: "элементы", many: "элементаў" },
      verb: "мець"
    },
    file: { unit: { one: "байт", few: "байты", many: "байтаў" }, verb: "мець" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "лік";
        case "object":{
            if (Array.isArray(n)) return "масіў";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "увод",
      email: "email адрас",
      url: "URL",
      emoji: "эмодзі",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO дата і час",
      date: "ISO дата",
      time: "ISO час",
      duration: "ISO працягласць",
      ipv4: "IPv4 адрас",
      ipv6: "IPv6 адрас",
      cidrv4: "IPv4 дыяпазон",
      cidrv6: "IPv6 дыяпазон",
      base64: "радок у фармаце base64",
      base64url: "радок у фармаце base64url",
      json_string: "JSON радок",
      e164: "нумар E.164",
      jwt: "JWT",
      template_literal: "увод"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Няправільны ўвод: чакаўся ${n.expected}, атрымана ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Няправільны ўвод: чакалася ${z(n.values[0])}`;
        return `Няправільны варыянт: чакаўся адзін з ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l) {
            let u = Number(n.maximum),
              g = Ow(u, l.unit.one, l.unit.few, l.unit.many);
            return `Занадта вялікі: чакалася, што ${n.origin ?? "значэнне"} павінна ${l.verb} ${e}${n.maximum.toString()} ${g}`;
          }
          return `Занадта вялікі: чакалася, што ${n.origin ?? "значэнне"} павінна быць ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l) {
            let u = Number(n.minimum),
              g = Ow(u, l.unit.one, l.unit.few, l.unit.many);
            return `Занадта малы: чакалася, што ${n.origin} павінна ${l.verb} ${e}${n.minimum.toString()} ${g}`;
          }
          return `Занадта малы: чакалася, што ${n.origin} павінна быць ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Няправільны радок: павінен пачынацца з "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Няправільны радок: павінен заканчвацца на "${e.suffix}"`;
          if (e.format === "includes")
          return `Няправільны радок: павінен змяшчаць "${e.includes}"`;
          if (e.format === "regex")
          return `Няправільны радок: павінен адпавядаць шаблону ${e.pattern}`;
          return `Няправільны ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Няправільны лік: павінен быць кратным ${n.divisor}`;
      case "unrecognized_keys":
        return `Нераспазнаны ${n.keys.length > 1 ? "ключы" : "ключ"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Няправільны ключ у ${n.origin}`;
      case "invalid_union":
        return "Няправільны ўвод";
      case "invalid_element":
        return `Няправільнае значэнне ў ${n.origin}`;
      default:
        return "Няправільны ўвод";
    }
  };
};
function lb() {
  return { localeError: uO() };
}
var gO = () => {
  let r = {
    string: { unit: "caràcters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "entrada",
      email: "adreça electrònica",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data i hora ISO",
      date: "data ISO",
      time: "hora ISO",
      duration: "durada ISO",
      ipv4: "adreça IPv4",
      ipv6: "adreça IPv6",
      cidrv4: "rang IPv4",
      cidrv6: "rang IPv6",
      base64: "cadena codificada en base64",
      base64url: "cadena codificada en base64url",
      json_string: "cadena JSON",
      e164: "número E.164",
      jwt: "JWT",
      template_literal: "entrada"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Tipus invàlid: s'esperava ${n.expected}, s'ha rebut ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Valor invàlid: s'esperava ${z(n.values[0])}`;
        return `Opció invàlida: s'esperava una de ${x(n.values, " o ")}`;
      case "too_big":{
          let e = n.inclusive ? "com a màxim" : "menys de",
            l = t(n.origin);
          if (l)
          return `Massa gran: s'esperava que ${n.origin ?? "el valor"} contingués ${e} ${n.maximum.toString()} ${l.unit ?? "elements"}`;
          return `Massa gran: s'esperava que ${n.origin ?? "el valor"} fos ${e} ${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? "com a mínim" : "més de",
            l = t(n.origin);
          if (l)
          return `Massa petit: s'esperava que ${n.origin} contingués ${e} ${n.minimum.toString()} ${l.unit}`;
          return `Massa petit: s'esperava que ${n.origin} fos ${e} ${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Format invàlid: ha de començar amb "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Format invàlid: ha d'acabar amb "${e.suffix}"`;
          if (e.format === "includes")
          return `Format invàlid: ha d'incloure "${e.includes}"`;
          if (e.format === "regex")
          return `Format invàlid: ha de coincidir amb el patró ${e.pattern}`;
          return `Format invàlid per a ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Número invàlid: ha de ser múltiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Clau${n.keys.length > 1 ? "s" : ""} no reconeguda${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Clau invàlida a ${n.origin}`;
      case "invalid_union":
        return "Entrada invàlida";
      case "invalid_element":
        return `Element invàlid a ${n.origin}`;
      default:
        return "Entrada invàlida";
    }
  };
};
function cb() {
  return { localeError: gO() };
}
var mO = () => {
  let r = {
    string: { unit: "znaků", verb: "mít" },
    file: { unit: "bajtů", verb: "mít" },
    array: { unit: "prvků", verb: "mít" },
    set: { unit: "prvků", verb: "mít" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "číslo";
        case "string":
          return "řetězec";
        case "boolean":
          return "boolean";
        case "bigint":
          return "bigint";
        case "function":
          return "funkce";
        case "symbol":
          return "symbol";
        case "undefined":
          return "undefined";
        case "object":{
            if (Array.isArray(n)) return "pole";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "regulární výraz",
      email: "e-mailová adresa",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "datum a čas ve formátu ISO",
      date: "datum ve formátu ISO",
      time: "čas ve formátu ISO",
      duration: "doba trvání ISO",
      ipv4: "IPv4 adresa",
      ipv6: "IPv6 adresa",
      cidrv4: "rozsah IPv4",
      cidrv6: "rozsah IPv6",
      base64: "řetězec zakódovaný ve formátu base64",
      base64url: "řetězec zakódovaný ve formátu base64url",
      json_string: "řetězec ve formátu JSON",
      e164: "číslo E.164",
      jwt: "JWT",
      template_literal: "vstup"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Neplatný vstup: očekáváno ${n.expected}, obdrženo ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Neplatný vstup: očekáváno ${z(n.values[0])}`;
        return `Neplatná možnost: očekávána jedna z hodnot ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Hodnota je příliš velká: ${n.origin ?? "hodnota"} musí mít ${e}${n.maximum.toString()} ${l.unit ?? "prvků"}`;
          return `Hodnota je příliš velká: ${n.origin ?? "hodnota"} musí být ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Hodnota je příliš malá: ${n.origin ?? "hodnota"} musí mít ${e}${n.minimum.toString()} ${l.unit ?? "prvků"}`;
          return `Hodnota je příliš malá: ${n.origin ?? "hodnota"} musí být ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Neplatný řetězec: musí začínat na "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Neplatný řetězec: musí končit na "${e.suffix}"`;
          if (e.format === "includes")
          return `Neplatný řetězec: musí obsahovat "${e.includes}"`;
          if (e.format === "regex")
          return `Neplatný řetězec: musí odpovídat vzoru ${e.pattern}`;
          return `Neplatný formát ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Neplatné číslo: musí být násobkem ${n.divisor}`;
      case "unrecognized_keys":
        return `Neznámé klíče: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Neplatný klíč v ${n.origin}`;
      case "invalid_union":
        return "Neplatný vstup";
      case "invalid_element":
        return `Neplatná hodnota v ${n.origin}`;
      default:
        return "Neplatný vstup";
    }
  };
};
function ub() {
  return { localeError: mO() };
}
var bO = () => {
  let r = {
      string: { unit: "tegn", verb: "havde" },
      file: { unit: "bytes", verb: "havde" },
      array: { unit: "elementer", verb: "indeholdt" },
      set: { unit: "elementer", verb: "indeholdt" }
    },
    t = {
      string: "streng",
      number: "tal",
      boolean: "boolean",
      array: "liste",
      object: "objekt",
      set: "sæt",
      file: "fil"
    };
  function i(l) {
    return r[l] ?? null;
  }
  function o(l) {
    return t[l] ?? l;
  }
  let n = (l) => {
      let u = typeof l;
      switch (u) {
        case "number":
          return Number.isNaN(l) ? "NaN" : "tal";
        case "object":{
            if (Array.isArray(l)) return "liste";
            if (l === null) return "null";
            if (Object.getPrototypeOf(l) !== Object.prototype && l.constructor)
            return l.constructor.name;
            return "objekt";
          }
      }
      return u;
    },
    e = {
      regex: "input",
      email: "e-mailadresse",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dato- og klokkeslæt",
      date: "ISO-dato",
      time: "ISO-klokkeslæt",
      duration: "ISO-varighed",
      ipv4: "IPv4-område",
      ipv6: "IPv6-område",
      cidrv4: "IPv4-spektrum",
      cidrv6: "IPv6-spektrum",
      base64: "base64-kodet streng",
      base64url: "base64url-kodet streng",
      json_string: "JSON-streng",
      e164: "E.164-nummer",
      jwt: "JWT",
      template_literal: "input"
    };
  return (l) => {
    switch (l.code) {
      case "invalid_type":
        return `Ugyldigt input: forventede ${o(l.expected)}, fik ${o(n(l.input))}`;
      case "invalid_value":
        if (l.values.length === 1)
        return `Ugyldig værdi: forventede ${z(l.values[0])}`;
        return `Ugyldigt valg: forventede en af følgende ${x(l.values, "|")}`;
      case "too_big":{
          let u = l.inclusive ? "<=" : "<",
            g = i(l.origin),
            c = o(l.origin);
          if (g)
          return `For stor: forventede ${c ?? "value"} ${g.verb} ${u} ${l.maximum.toString()} ${g.unit ?? "elementer"}`;
          return `For stor: forventede ${c ?? "value"} havde ${u} ${l.maximum.toString()}`;
        }
      case "too_small":{
          let u = l.inclusive ? ">=" : ">",
            g = i(l.origin),
            c = o(l.origin);
          if (g)
          return `For lille: forventede ${c} ${g.verb} ${u} ${l.minimum.toString()} ${g.unit}`;
          return `For lille: forventede ${c} havde ${u} ${l.minimum.toString()}`;
        }
      case "invalid_format":{
          let u = l;
          if (u.format === "starts_with")
          return `Ugyldig streng: skal starte med "${u.prefix}"`;
          if (u.format === "ends_with")
          return `Ugyldig streng: skal ende med "${u.suffix}"`;
          if (u.format === "includes")
          return `Ugyldig streng: skal indeholde "${u.includes}"`;
          if (u.format === "regex")
          return `Ugyldig streng: skal matche mønsteret ${u.pattern}`;
          return `Ugyldig ${e[u.format] ?? l.format}`;
        }
      case "not_multiple_of":
        return `Ugyldigt tal: skal være deleligt med ${l.divisor}`;
      case "unrecognized_keys":
        return `${l.keys.length > 1 ? "Ukendte nøgler" : "Ukendt nøgle"}: ${x(l.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig nøgle i ${l.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig værdi i ${l.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
};
function gb() {
  return { localeError: bO() };
}
var vO = () => {
  let r = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "Zahl";
        case "object":{
            if (Array.isArray(n)) return "Array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "Eingabe",
      email: "E-Mail-Adresse",
      url: "URL",
      emoji: "Emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-Datum und -Uhrzeit",
      date: "ISO-Datum",
      time: "ISO-Uhrzeit",
      duration: "ISO-Dauer",
      ipv4: "IPv4-Adresse",
      ipv6: "IPv6-Adresse",
      cidrv4: "IPv4-Bereich",
      cidrv6: "IPv6-Bereich",
      base64: "Base64-codierter String",
      base64url: "Base64-URL-codierter String",
      json_string: "JSON-String",
      e164: "E.164-Nummer",
      jwt: "JWT",
      template_literal: "Eingabe"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Ungültige Eingabe: erwartet ${n.expected}, erhalten ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Ungültige Eingabe: erwartet ${z(n.values[0])}`;
        return `Ungültige Option: erwartet eine von ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Zu groß: erwartet, dass ${n.origin ?? "Wert"} ${e}${n.maximum.toString()} ${l.unit ?? "Elemente"} hat`;
          return `Zu groß: erwartet, dass ${n.origin ?? "Wert"} ${e}${n.maximum.toString()} ist`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Zu klein: erwartet, dass ${n.origin} ${e}${n.minimum.toString()} ${l.unit} hat`;
          return `Zu klein: erwartet, dass ${n.origin} ${e}${n.minimum.toString()} ist`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Ungültiger String: muss mit "${e.prefix}" beginnen`;
          if (e.format === "ends_with")
          return `Ungültiger String: muss mit "${e.suffix}" enden`;
          if (e.format === "includes")
          return `Ungültiger String: muss "${e.includes}" enthalten`;
          if (e.format === "regex")
          return `Ungültiger String: muss dem Muster ${e.pattern} entsprechen`;
          return `Ungültig: ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Ungültige Zahl: muss ein Vielfaches von ${n.divisor} sein`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Unbekannte Schlüssel" : "Unbekannter Schlüssel"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Ungültiger Schlüssel in ${n.origin}`;
      case "invalid_union":
        return "Ungültige Eingabe";
      case "invalid_element":
        return `Ungültiger Wert in ${n.origin}`;
      default:
        return "Ungültige Eingabe";
    }
  };
};
function mb() {
  return { localeError: vO() };
}
var hO = (r) => {
    let t = typeof r;
    switch (t) {
      case "number":
        return Number.isNaN(r) ? "NaN" : "number";
      case "object":{
          if (Array.isArray(r)) return "array";
          if (r === null) return "null";
          if (Object.getPrototypeOf(r) !== Object.prototype && r.constructor)
          return r.constructor.name;
        }
    }
    return t;
  },
  $O = () => {
    let r = {
      string: { unit: "characters", verb: "to have" },
      file: { unit: "bytes", verb: "to have" },
      array: { unit: "items", verb: "to have" },
      set: { unit: "items", verb: "to have" }
    };
    function t(o) {
      return r[o] ?? null;
    }
    let i = {
      regex: "input",
      email: "email address",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datetime",
      date: "ISO date",
      time: "ISO time",
      duration: "ISO duration",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded string",
      base64url: "base64url-encoded string",
      json_string: "JSON string",
      e164: "E.164 number",
      jwt: "JWT",
      template_literal: "input"
    };
    return (o) => {
      switch (o.code) {
        case "invalid_type":
          return `Invalid input: expected ${o.expected}, received ${hO(o.input)}`;
        case "invalid_value":
          if (o.values.length === 1)
          return `Invalid input: expected ${z(o.values[0])}`;
          return `Invalid option: expected one of ${x(o.values, "|")}`;
        case "too_big":{
            let n = o.inclusive ? "<=" : "<",
              e = t(o.origin);
            if (e)
            return `Too big: expected ${o.origin ?? "value"} to have ${n}${o.maximum.toString()} ${e.unit ?? "elements"}`;
            return `Too big: expected ${o.origin ?? "value"} to be ${n}${o.maximum.toString()}`;
          }
        case "too_small":{
            let n = o.inclusive ? ">=" : ">",
              e = t(o.origin);
            if (e)
            return `Too small: expected ${o.origin} to have ${n}${o.minimum.toString()} ${e.unit}`;
            return `Too small: expected ${o.origin} to be ${n}${o.minimum.toString()}`;
          }
        case "invalid_format":{
            let n = o;
            if (n.format === "starts_with")
            return `Invalid string: must start with "${n.prefix}"`;
            if (n.format === "ends_with")
            return `Invalid string: must end with "${n.suffix}"`;
            if (n.format === "includes")
            return `Invalid string: must include "${n.includes}"`;
            if (n.format === "regex")
            return `Invalid string: must match pattern ${n.pattern}`;
            return `Invalid ${i[n.format] ?? o.format}`;
          }
        case "not_multiple_of":
          return `Invalid number: must be a multiple of ${o.divisor}`;
        case "unrecognized_keys":
          return `Unrecognized key${o.keys.length > 1 ? "s" : ""}: ${x(o.keys, ", ")}`;
        case "invalid_key":
          return `Invalid key in ${o.origin}`;
        case "invalid_union":
          return "Invalid input";
        case "invalid_element":
          return `Invalid value in ${o.origin}`;
        default:
          return "Invalid input";
      }
    };
  };
function oi() {
  return { localeError: $O() };
}
var xO = (r) => {
    let t = typeof r;
    switch (t) {
      case "number":
        return Number.isNaN(r) ? "NaN" : "nombro";
      case "object":{
          if (Array.isArray(r)) return "tabelo";
          if (r === null) return "senvalora";
          if (Object.getPrototypeOf(r) !== Object.prototype && r.constructor)
          return r.constructor.name;
        }
    }
    return t;
  },
  fO = () => {
    let r = {
      string: { unit: "karaktrojn", verb: "havi" },
      file: { unit: "bajtojn", verb: "havi" },
      array: { unit: "elementojn", verb: "havi" },
      set: { unit: "elementojn", verb: "havi" }
    };
    function t(o) {
      return r[o] ?? null;
    }
    let i = {
      regex: "enigo",
      email: "retadreso",
      url: "URL",
      emoji: "emoĝio",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-datotempo",
      date: "ISO-dato",
      time: "ISO-tempo",
      duration: "ISO-daŭro",
      ipv4: "IPv4-adreso",
      ipv6: "IPv6-adreso",
      cidrv4: "IPv4-rango",
      cidrv6: "IPv6-rango",
      base64: "64-ume kodita karaktraro",
      base64url: "URL-64-ume kodita karaktraro",
      json_string: "JSON-karaktraro",
      e164: "E.164-nombro",
      jwt: "JWT",
      template_literal: "enigo"
    };
    return (o) => {
      switch (o.code) {
        case "invalid_type":
          return `Nevalida enigo: atendiĝis ${o.expected}, riceviĝis ${xO(o.input)}`;
        case "invalid_value":
          if (o.values.length === 1)
          return `Nevalida enigo: atendiĝis ${z(o.values[0])}`;
          return `Nevalida opcio: atendiĝis unu el ${x(o.values, "|")}`;
        case "too_big":{
            let n = o.inclusive ? "<=" : "<",
              e = t(o.origin);
            if (e)
            return `Tro granda: atendiĝis ke ${o.origin ?? "valoro"} havu ${n}${o.maximum.toString()} ${e.unit ?? "elementojn"}`;
            return `Tro granda: atendiĝis ke ${o.origin ?? "valoro"} havu ${n}${o.maximum.toString()}`;
          }
        case "too_small":{
            let n = o.inclusive ? ">=" : ">",
              e = t(o.origin);
            if (e)
            return `Tro malgranda: atendiĝis ke ${o.origin} havu ${n}${o.minimum.toString()} ${e.unit}`;
            return `Tro malgranda: atendiĝis ke ${o.origin} estu ${n}${o.minimum.toString()}`;
          }
        case "invalid_format":{
            let n = o;
            if (n.format === "starts_with")
            return `Nevalida karaktraro: devas komenciĝi per "${n.prefix}"`;
            if (n.format === "ends_with")
            return `Nevalida karaktraro: devas finiĝi per "${n.suffix}"`;
            if (n.format === "includes")
            return `Nevalida karaktraro: devas inkluzivi "${n.includes}"`;
            if (n.format === "regex")
            return `Nevalida karaktraro: devas kongrui kun la modelo ${n.pattern}`;
            return `Nevalida ${i[n.format] ?? o.format}`;
          }
        case "not_multiple_of":
          return `Nevalida nombro: devas esti oblo de ${o.divisor}`;
        case "unrecognized_keys":
          return `Nekonata${o.keys.length > 1 ? "j" : ""} ŝlosilo${o.keys.length > 1 ? "j" : ""}: ${x(o.keys, ", ")}`;
        case "invalid_key":
          return `Nevalida ŝlosilo en ${o.origin}`;
        case "invalid_union":
          return "Nevalida enigo";
        case "invalid_element":
          return `Nevalida valoro en ${o.origin}`;
        default:
          return "Nevalida enigo";
      }
    };
  };
function bb() {
  return { localeError: fO() };
}
var wO = () => {
  let r = {
      string: { unit: "caracteres", verb: "tener" },
      file: { unit: "bytes", verb: "tener" },
      array: { unit: "elementos", verb: "tener" },
      set: { unit: "elementos", verb: "tener" }
    },
    t = {
      string: "texto",
      number: "número",
      boolean: "booleano",
      array: "arreglo",
      object: "objeto",
      set: "conjunto",
      file: "archivo",
      date: "fecha",
      bigint: "número grande",
      symbol: "símbolo",
      undefined: "indefinido",
      null: "nulo",
      function: "función",
      map: "mapa",
      record: "registro",
      tuple: "tupla",
      enum: "enumeración",
      union: "unión",
      literal: "literal",
      promise: "promesa",
      void: "vacío",
      never: "nunca",
      unknown: "desconocido",
      any: "cualquiera"
    };
  function i(l) {
    return r[l] ?? null;
  }
  function o(l) {
    return t[l] ?? l;
  }
  let n = (l) => {
      let u = typeof l;
      switch (u) {
        case "number":
          return Number.isNaN(l) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(l)) return "array";
            if (l === null) return "null";
            if (Object.getPrototypeOf(l) !== Object.prototype)
            return l.constructor.name;
            return "object";
          }
      }
      return u;
    },
    e = {
      regex: "entrada",
      email: "dirección de correo electrónico",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "fecha y hora ISO",
      date: "fecha ISO",
      time: "hora ISO",
      duration: "duración ISO",
      ipv4: "dirección IPv4",
      ipv6: "dirección IPv6",
      cidrv4: "rango IPv4",
      cidrv6: "rango IPv6",
      base64: "cadena codificada en base64",
      base64url: "URL codificada en base64",
      json_string: "cadena JSON",
      e164: "número E.164",
      jwt: "JWT",
      template_literal: "entrada"
    };
  return (l) => {
    switch (l.code) {
      case "invalid_type":
        return `Entrada inválida: se esperaba ${o(l.expected)}, recibido ${o(n(l.input))}`;
      case "invalid_value":
        if (l.values.length === 1)
        return `Entrada inválida: se esperaba ${z(l.values[0])}`;
        return `Opción inválida: se esperaba una de ${x(l.values, "|")}`;
      case "too_big":{
          let u = l.inclusive ? "<=" : "<",
            g = i(l.origin),
            c = o(l.origin);
          if (g)
          return `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${u}${l.maximum.toString()} ${g.unit ?? "elementos"}`;
          return `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${u}${l.maximum.toString()}`;
        }
      case "too_small":{
          let u = l.inclusive ? ">=" : ">",
            g = i(l.origin),
            c = o(l.origin);
          if (g)
          return `Demasiado pequeño: se esperaba que ${c} tuviera ${u}${l.minimum.toString()} ${g.unit}`;
          return `Demasiado pequeño: se esperaba que ${c} fuera ${u}${l.minimum.toString()}`;
        }
      case "invalid_format":{
          let u = l;
          if (u.format === "starts_with")
          return `Cadena inválida: debe comenzar con "${u.prefix}"`;
          if (u.format === "ends_with")
          return `Cadena inválida: debe terminar en "${u.suffix}"`;
          if (u.format === "includes")
          return `Cadena inválida: debe incluir "${u.includes}"`;
          if (u.format === "regex")
          return `Cadena inválida: debe coincidir con el patrón ${u.pattern}`;
          return `Inválido ${e[u.format] ?? l.format}`;
        }
      case "not_multiple_of":
        return `Número inválido: debe ser múltiplo de ${l.divisor}`;
      case "unrecognized_keys":
        return `Llave${l.keys.length > 1 ? "s" : ""} desconocida${l.keys.length > 1 ? "s" : ""}: ${x(l.keys, ", ")}`;
      case "invalid_key":
        return `Llave inválida en ${o(l.origin)}`;
      case "invalid_union":
        return "Entrada inválida";
      case "invalid_element":
        return `Valor inválido en ${o(l.origin)}`;
      default:
        return "Entrada inválida";
    }
  };
};
function vb() {
  return { localeError: wO() };
}
var zO = () => {
  let r = {
    string: { unit: "کاراکتر", verb: "داشته باشد" },
    file: { unit: "بایت", verb: "داشته باشد" },
    array: { unit: "آیتم", verb: "داشته باشد" },
    set: { unit: "آیتم", verb: "داشته باشد" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "عدد";
        case "object":{
            if (Array.isArray(n)) return "آرایه";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ورودی",
      email: "آدرس ایمیل",
      url: "URL",
      emoji: "ایموجی",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "تاریخ و زمان ایزو",
      date: "تاریخ ایزو",
      time: "زمان ایزو",
      duration: "مدت زمان ایزو",
      ipv4: "IPv4 آدرس",
      ipv6: "IPv6 آدرس",
      cidrv4: "IPv4 دامنه",
      cidrv6: "IPv6 دامنه",
      base64: "base64-encoded رشته",
      base64url: "base64url-encoded رشته",
      json_string: "JSON رشته",
      e164: "E.164 عدد",
      jwt: "JWT",
      template_literal: "ورودی"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `ورودی نامعتبر: می‌بایست ${n.expected} می‌بود، ${i(n.input)} دریافت شد`;
      case "invalid_value":
        if (n.values.length === 1)
        return `ورودی نامعتبر: می‌بایست ${z(n.values[0])} می‌بود`;
        return `گزینه نامعتبر: می‌بایست یکی از ${x(n.values, "|")} می‌بود`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `خیلی بزرگ: ${n.origin ?? "مقدار"} باید ${e}${n.maximum.toString()} ${l.unit ?? "عنصر"} باشد`;
          return `خیلی بزرگ: ${n.origin ?? "مقدار"} باید ${e}${n.maximum.toString()} باشد`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `خیلی کوچک: ${n.origin} باید ${e}${n.minimum.toString()} ${l.unit} باشد`;
          return `خیلی کوچک: ${n.origin} باید ${e}${n.minimum.toString()} باشد`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `رشته نامعتبر: باید با "${e.prefix}" شروع شود`;
          if (e.format === "ends_with")
          return `رشته نامعتبر: باید با "${e.suffix}" تمام شود`;
          if (e.format === "includes")
          return `رشته نامعتبر: باید شامل "${e.includes}" باشد`;
          if (e.format === "regex")
          return `رشته نامعتبر: باید با الگوی ${e.pattern} مطابقت داشته باشد`;
          return `${o[e.format] ?? n.format} نامعتبر`;
        }
      case "not_multiple_of":
        return `عدد نامعتبر: باید مضرب ${n.divisor} باشد`;
      case "unrecognized_keys":
        return `کلید${n.keys.length > 1 ? "های" : ""} ناشناس: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `کلید ناشناس در ${n.origin}`;
      case "invalid_union":
        return "ورودی نامعتبر";
      case "invalid_element":
        return `مقدار نامعتبر در ${n.origin}`;
      default:
        return "ورودی نامعتبر";
    }
  };
};
function hb() {
  return { localeError: zO() };
}
var aO = () => {
  let r = {
    string: { unit: "merkkiä", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "päivämäärän" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "säännöllinen lauseke",
      email: "sähköpostiosoite",
      url: "URL-osoite",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-aikaleima",
      date: "ISO-päivämäärä",
      time: "ISO-aika",
      duration: "ISO-kesto",
      ipv4: "IPv4-osoite",
      ipv6: "IPv6-osoite",
      cidrv4: "IPv4-alue",
      cidrv6: "IPv6-alue",
      base64: "base64-koodattu merkkijono",
      base64url: "base64url-koodattu merkkijono",
      json_string: "JSON-merkkijono",
      e164: "E.164-luku",
      jwt: "JWT",
      template_literal: "templaattimerkkijono"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Virheellinen tyyppi: odotettiin ${n.expected}, oli ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Virheellinen syöte: täytyy olla ${z(n.values[0])}`;
        return `Virheellinen valinta: täytyy olla yksi seuraavista: ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Liian suuri: ${l.subject} täytyy olla ${e}${n.maximum.toString()} ${l.unit}`.trim();
          return `Liian suuri: arvon täytyy olla ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Liian pieni: ${l.subject} täytyy olla ${e}${n.minimum.toString()} ${l.unit}`.trim();
          return `Liian pieni: arvon täytyy olla ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Virheellinen syöte: täytyy alkaa "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Virheellinen syöte: täytyy loppua "${e.suffix}"`;
          if (e.format === "includes")
          return `Virheellinen syöte: täytyy sisältää "${e.includes}"`;
          if (e.format === "regex")
          return `Virheellinen syöte: täytyy vastata säännöllistä lauseketta ${e.pattern}`;
          return `Virheellinen ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Virheellinen luku: täytyy olla luvun ${n.divisor} monikerta`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen syöte";
    }
  };
};
function $b() {
  return { localeError: aO() };
}
var pO = () => {
  let r = {
    string: { unit: "caractères", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "éléments", verb: "avoir" },
    set: { unit: "éléments", verb: "avoir" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "nombre";
        case "object":{
            if (Array.isArray(n)) return "tableau";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "entrée",
      email: "adresse e-mail",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "date et heure ISO",
      date: "date ISO",
      time: "heure ISO",
      duration: "durée ISO",
      ipv4: "adresse IPv4",
      ipv6: "adresse IPv6",
      cidrv4: "plage IPv4",
      cidrv6: "plage IPv6",
      base64: "chaîne encodée en base64",
      base64url: "chaîne encodée en base64url",
      json_string: "chaîne JSON",
      e164: "numéro E.164",
      jwt: "JWT",
      template_literal: "entrée"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Entrée invalide : ${n.expected} attendu, ${i(n.input)} reçu`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Entrée invalide : ${z(n.values[0])} attendu`;
        return `Option invalide : une valeur parmi ${x(n.values, "|")} attendue`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Trop grand : ${n.origin ?? "valeur"} doit ${l.verb} ${e}${n.maximum.toString()} ${l.unit ?? "élément(s)"}`;
          return `Trop grand : ${n.origin ?? "valeur"} doit être ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Trop petit : ${n.origin} doit ${l.verb} ${e}${n.minimum.toString()} ${l.unit}`;
          return `Trop petit : ${n.origin} doit être ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Chaîne invalide : doit commencer par "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Chaîne invalide : doit se terminer par "${e.suffix}"`;
          if (e.format === "includes")
          return `Chaîne invalide : doit inclure "${e.includes}"`;
          if (e.format === "regex")
          return `Chaîne invalide : doit correspondre au modèle ${e.pattern}`;
          return `${o[e.format] ?? n.format} invalide`;
        }
      case "not_multiple_of":
        return `Nombre invalide : doit être un multiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Clé${n.keys.length > 1 ? "s" : ""} non reconnue${n.keys.length > 1 ? "s" : ""} : ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Clé invalide dans ${n.origin}`;
      case "invalid_union":
        return "Entrée invalide";
      case "invalid_element":
        return `Valeur invalide dans ${n.origin}`;
      default:
        return "Entrée invalide";
    }
  };
};
function xb() {
  return { localeError: pO() };
}
var _O = () => {
  let r = {
    string: { unit: "caractères", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "éléments", verb: "avoir" },
    set: { unit: "éléments", verb: "avoir" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "entrée",
      email: "adresse courriel",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "date-heure ISO",
      date: "date ISO",
      time: "heure ISO",
      duration: "durée ISO",
      ipv4: "adresse IPv4",
      ipv6: "adresse IPv6",
      cidrv4: "plage IPv4",
      cidrv6: "plage IPv6",
      base64: "chaîne encodée en base64",
      base64url: "chaîne encodée en base64url",
      json_string: "chaîne JSON",
      e164: "numéro E.164",
      jwt: "JWT",
      template_literal: "entrée"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Entrée invalide : attendu ${n.expected}, reçu ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Entrée invalide : attendu ${z(n.values[0])}`;
        return `Option invalide : attendu l'une des valeurs suivantes ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "≤" : "<",
            l = t(n.origin);
          if (l)
          return `Trop grand : attendu que ${n.origin ?? "la valeur"} ait ${e}${n.maximum.toString()} ${l.unit}`;
          return `Trop grand : attendu que ${n.origin ?? "la valeur"} soit ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? "≥" : ">",
            l = t(n.origin);
          if (l)
          return `Trop petit : attendu que ${n.origin} ait ${e}${n.minimum.toString()} ${l.unit}`;
          return `Trop petit : attendu que ${n.origin} soit ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Chaîne invalide : doit commencer par "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Chaîne invalide : doit se terminer par "${e.suffix}"`;
          if (e.format === "includes")
          return `Chaîne invalide : doit inclure "${e.includes}"`;
          if (e.format === "regex")
          return `Chaîne invalide : doit correspondre au motif ${e.pattern}`;
          return `${o[e.format] ?? n.format} invalide`;
        }
      case "not_multiple_of":
        return `Nombre invalide : doit être un multiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Clé${n.keys.length > 1 ? "s" : ""} non reconnue${n.keys.length > 1 ? "s" : ""} : ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Clé invalide dans ${n.origin}`;
      case "invalid_union":
        return "Entrée invalide";
      case "invalid_element":
        return `Valeur invalide dans ${n.origin}`;
      default:
        return "Entrée invalide";
    }
  };
};
function fb() {
  return { localeError: _O() };
}
var DO = () => {
  let r = {
    string: { unit: "אותיות", verb: "לכלול" },
    file: { unit: "בייטים", verb: "לכלול" },
    array: { unit: "פריטים", verb: "לכלול" },
    set: { unit: "פריטים", verb: "לכלול" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "קלט",
      email: "כתובת אימייל",
      url: "כתובת רשת",
      emoji: "אימוג'י",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "תאריך וזמן ISO",
      date: "תאריך ISO",
      time: "זמן ISO",
      duration: "משך זמן ISO",
      ipv4: "כתובת IPv4",
      ipv6: "כתובת IPv6",
      cidrv4: "טווח IPv4",
      cidrv6: "טווח IPv6",
      base64: "מחרוזת בבסיס 64",
      base64url: "מחרוזת בבסיס 64 לכתובות רשת",
      json_string: "מחרוזת JSON",
      e164: "מספר E.164",
      jwt: "JWT",
      template_literal: "קלט"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `קלט לא תקין: צריך ${n.expected}, התקבל ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1) return `קלט לא תקין: צריך ${z(n.values[0])}`;
        return `קלט לא תקין: צריך אחת מהאפשרויות  ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `גדול מדי: ${n.origin ?? "value"} צריך להיות ${e}${n.maximum.toString()} ${l.unit ?? "elements"}`;
          return `גדול מדי: ${n.origin ?? "value"} צריך להיות ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `קטן מדי: ${n.origin} צריך להיות ${e}${n.minimum.toString()} ${l.unit}`;
          return `קטן מדי: ${n.origin} צריך להיות ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `מחרוזת לא תקינה: חייבת להתחיל ב"${e.prefix}"`;
          if (e.format === "ends_with")
          return `מחרוזת לא תקינה: חייבת להסתיים ב "${e.suffix}"`;
          if (e.format === "includes")
          return `מחרוזת לא תקינה: חייבת לכלול "${e.includes}"`;
          if (e.format === "regex")
          return `מחרוזת לא תקינה: חייבת להתאים לתבנית ${e.pattern}`;
          return `${o[e.format] ?? n.format} לא תקין`;
        }
      case "not_multiple_of":
        return `מספר לא תקין: חייב להיות מכפלה של ${n.divisor}`;
      case "unrecognized_keys":
        return `מפתח${n.keys.length > 1 ? "ות" : ""} לא מזוה${n.keys.length > 1 ? "ים" : "ה"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `מפתח לא תקין ב${n.origin}`;
      case "invalid_union":
        return "קלט לא תקין";
      case "invalid_element":
        return `ערך לא תקין ב${n.origin}`;
      default:
        return "קלט לא תקין";
    }
  };
};
function wb() {
  return { localeError: DO() };
}
var jO = () => {
  let r = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "szám";
        case "object":{
            if (Array.isArray(n)) return "tömb";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "bemenet",
      email: "email cím",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO időbélyeg",
      date: "ISO dátum",
      time: "ISO idő",
      duration: "ISO időintervallum",
      ipv4: "IPv4 cím",
      ipv6: "IPv6 cím",
      cidrv4: "IPv4 tartomány",
      cidrv6: "IPv6 tartomány",
      base64: "base64-kódolt string",
      base64url: "base64url-kódolt string",
      json_string: "JSON string",
      e164: "E.164 szám",
      jwt: "JWT",
      template_literal: "bemenet"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Érvénytelen bemenet: a várt érték ${n.expected}, a kapott érték ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Érvénytelen bemenet: a várt érték ${z(n.values[0])}`;
        return `Érvénytelen opció: valamelyik érték várt ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Túl nagy: ${n.origin ?? "érték"} mérete túl nagy ${e}${n.maximum.toString()} ${l.unit ?? "elem"}`;
          return `Túl nagy: a bemeneti érték ${n.origin ?? "érték"} túl nagy: ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Túl kicsi: a bemeneti érték ${n.origin} mérete túl kicsi ${e}${n.minimum.toString()} ${l.unit}`;
          return `Túl kicsi: a bemeneti érték ${n.origin} túl kicsi ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Érvénytelen string: "${e.prefix}" értékkel kell kezdődnie`;
          if (e.format === "ends_with")
          return `Érvénytelen string: "${e.suffix}" értékkel kell végződnie`;
          if (e.format === "includes")
          return `Érvénytelen string: "${e.includes}" értéket kell tartalmaznia`;
          if (e.format === "regex")
          return `Érvénytelen string: ${e.pattern} mintának kell megfelelnie`;
          return `Érvénytelen ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Érvénytelen szám: ${n.divisor} többszörösének kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Érvénytelen kulcs ${n.origin}`;
      case "invalid_union":
        return "Érvénytelen bemenet";
      case "invalid_element":
        return `Érvénytelen érték: ${n.origin}`;
      default:
        return "Érvénytelen bemenet";
    }
  };
};
function zb() {
  return { localeError: jO() };
}
var OO = () => {
  let r = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "input",
      email: "alamat email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "tanggal dan waktu format ISO",
      date: "tanggal format ISO",
      time: "jam format ISO",
      duration: "durasi format ISO",
      ipv4: "alamat IPv4",
      ipv6: "alamat IPv6",
      cidrv4: "rentang alamat IPv4",
      cidrv6: "rentang alamat IPv6",
      base64: "string dengan enkode base64",
      base64url: "string dengan enkode base64url",
      json_string: "string JSON",
      e164: "angka E.164",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Input tidak valid: diharapkan ${n.expected}, diterima ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Input tidak valid: diharapkan ${z(n.values[0])}`;
        return `Pilihan tidak valid: diharapkan salah satu dari ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Terlalu besar: diharapkan ${n.origin ?? "value"} memiliki ${e}${n.maximum.toString()} ${l.unit ?? "elemen"}`;
          return `Terlalu besar: diharapkan ${n.origin ?? "value"} menjadi ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Terlalu kecil: diharapkan ${n.origin} memiliki ${e}${n.minimum.toString()} ${l.unit}`;
          return `Terlalu kecil: diharapkan ${n.origin} menjadi ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `String tidak valid: harus dimulai dengan "${e.prefix}"`;
          if (e.format === "ends_with")
          return `String tidak valid: harus berakhir dengan "${e.suffix}"`;
          if (e.format === "includes")
          return `String tidak valid: harus menyertakan "${e.includes}"`;
          if (e.format === "regex")
          return `String tidak valid: harus sesuai pola ${e.pattern}`;
          return `${o[e.format] ?? n.format} tidak valid`;
        }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${n.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${n.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${n.origin}`;
      default:
        return "Input tidak valid";
    }
  };
};
function ab() {
  return { localeError: OO() };
}
var IO = (r) => {
    let t = typeof r;
    switch (t) {
      case "number":
        return Number.isNaN(r) ? "NaN" : "númer";
      case "object":{
          if (Array.isArray(r)) return "fylki";
          if (r === null) return "null";
          if (Object.getPrototypeOf(r) !== Object.prototype && r.constructor)
          return r.constructor.name;
        }
    }
    return t;
  },
  kO = () => {
    let r = {
      string: { unit: "stafi", verb: "að hafa" },
      file: { unit: "bæti", verb: "að hafa" },
      array: { unit: "hluti", verb: "að hafa" },
      set: { unit: "hluti", verb: "að hafa" }
    };
    function t(o) {
      return r[o] ?? null;
    }
    let i = {
      regex: "gildi",
      email: "netfang",
      url: "vefslóð",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dagsetning og tími",
      date: "ISO dagsetning",
      time: "ISO tími",
      duration: "ISO tímalengd",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded strengur",
      base64url: "base64url-encoded strengur",
      json_string: "JSON strengur",
      e164: "E.164 tölugildi",
      jwt: "JWT",
      template_literal: "gildi"
    };
    return (o) => {
      switch (o.code) {
        case "invalid_type":
          return `Rangt gildi: Þú slóst inn ${IO(o.input)} þar sem á að vera ${o.expected}`;
        case "invalid_value":
          if (o.values.length === 1)
          return `Rangt gildi: gert ráð fyrir ${z(o.values[0])}`;
          return `Ógilt val: má vera eitt af eftirfarandi ${x(o.values, "|")}`;
        case "too_big":{
            let n = o.inclusive ? "<=" : "<",
              e = t(o.origin);
            if (e)
            return `Of stórt: gert er ráð fyrir að ${o.origin ?? "gildi"} hafi ${n}${o.maximum.toString()} ${e.unit ?? "hluti"}`;
            return `Of stórt: gert er ráð fyrir að ${o.origin ?? "gildi"} sé ${n}${o.maximum.toString()}`;
          }
        case "too_small":{
            let n = o.inclusive ? ">=" : ">",
              e = t(o.origin);
            if (e)
            return `Of lítið: gert er ráð fyrir að ${o.origin} hafi ${n}${o.minimum.toString()} ${e.unit}`;
            return `Of lítið: gert er ráð fyrir að ${o.origin} sé ${n}${o.minimum.toString()}`;
          }
        case "invalid_format":{
            let n = o;
            if (n.format === "starts_with")
            return `Ógildur strengur: verður að byrja á "${n.prefix}"`;
            if (n.format === "ends_with")
            return `Ógildur strengur: verður að enda á "${n.suffix}"`;
            if (n.format === "includes")
            return `Ógildur strengur: verður að innihalda "${n.includes}"`;
            if (n.format === "regex")
            return `Ógildur strengur: verður að fylgja mynstri ${n.pattern}`;
            return `Rangt ${i[n.format] ?? o.format}`;
          }
        case "not_multiple_of":
          return `Röng tala: verður að vera margfeldi af ${o.divisor}`;
        case "unrecognized_keys":
          return `Óþekkt ${o.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${x(o.keys, ", ")}`;
        case "invalid_key":
          return `Rangur lykill í ${o.origin}`;
        case "invalid_union":
          return "Rangt gildi";
        case "invalid_element":
          return `Rangt gildi í ${o.origin}`;
        default:
          return "Rangt gildi";
      }
    };
  };
function pb() {
  return { localeError: kO() };
}
var UO = () => {
  let r = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "numero";
        case "object":{
            if (Array.isArray(n)) return "vettore";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "input",
      email: "indirizzo email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data e ora ISO",
      date: "data ISO",
      time: "ora ISO",
      duration: "durata ISO",
      ipv4: "indirizzo IPv4",
      ipv6: "indirizzo IPv6",
      cidrv4: "intervallo IPv4",
      cidrv6: "intervallo IPv6",
      base64: "stringa codificata in base64",
      base64url: "URL codificata in base64",
      json_string: "stringa JSON",
      e164: "numero E.164",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Input non valido: atteso ${n.expected}, ricevuto ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Input non valido: atteso ${z(n.values[0])}`;
        return `Opzione non valida: atteso uno tra ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Troppo grande: ${n.origin ?? "valore"} deve avere ${e}${n.maximum.toString()} ${l.unit ?? "elementi"}`;
          return `Troppo grande: ${n.origin ?? "valore"} deve essere ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Troppo piccolo: ${n.origin} deve avere ${e}${n.minimum.toString()} ${l.unit}`;
          return `Troppo piccolo: ${n.origin} deve essere ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Stringa non valida: deve iniziare con "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Stringa non valida: deve terminare con "${e.suffix}"`;
          if (e.format === "includes")
          return `Stringa non valida: deve includere "${e.includes}"`;
          if (e.format === "regex")
          return `Stringa non valida: deve corrispondere al pattern ${e.pattern}`;
          return `Invalid ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${n.divisor}`;
      case "unrecognized_keys":
        return `Chiav${n.keys.length > 1 ? "i" : "e"} non riconosciut${n.keys.length > 1 ? "e" : "a"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${n.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${n.origin}`;
      default:
        return "Input non valido";
    }
  };
};
function _b() {
  return { localeError: UO() };
}
var JO = () => {
  let r = {
    string: { unit: "文字", verb: "である" },
    file: { unit: "バイト", verb: "である" },
    array: { unit: "要素", verb: "である" },
    set: { unit: "要素", verb: "である" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "数値";
        case "object":{
            if (Array.isArray(n)) return "配列";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "入力値",
      email: "メールアドレス",
      url: "URL",
      emoji: "絵文字",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO日時",
      date: "ISO日付",
      time: "ISO時刻",
      duration: "ISO期間",
      ipv4: "IPv4アドレス",
      ipv6: "IPv6アドレス",
      cidrv4: "IPv4範囲",
      cidrv6: "IPv6範囲",
      base64: "base64エンコード文字列",
      base64url: "base64urlエンコード文字列",
      json_string: "JSON文字列",
      e164: "E.164番号",
      jwt: "JWT",
      template_literal: "入力値"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `無効な入力: ${n.expected}が期待されましたが、${i(n.input)}が入力されました`;
      case "invalid_value":
        if (n.values.length === 1)
        return `無効な入力: ${z(n.values[0])}が期待されました`;
        return `無効な選択: ${x(n.values, "、")}のいずれかである必要があります`;
      case "too_big":{
          let e = n.inclusive ? "以下である" : "より小さい",
            l = t(n.origin);
          if (l)
          return `大きすぎる値: ${n.origin ?? "値"}は${n.maximum.toString()}${l.unit ?? "要素"}${e}必要があります`;
          return `大きすぎる値: ${n.origin ?? "値"}は${n.maximum.toString()}${e}必要があります`;
        }
      case "too_small":{
          let e = n.inclusive ? "以上である" : "より大きい",
            l = t(n.origin);
          if (l)
          return `小さすぎる値: ${n.origin}は${n.minimum.toString()}${l.unit}${e}必要があります`;
          return `小さすぎる値: ${n.origin}は${n.minimum.toString()}${e}必要があります`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `無効な文字列: "${e.prefix}"で始まる必要があります`;
          if (e.format === "ends_with")
          return `無効な文字列: "${e.suffix}"で終わる必要があります`;
          if (e.format === "includes")
          return `無効な文字列: "${e.includes}"を含む必要があります`;
          if (e.format === "regex")
          return `無効な文字列: パターン${e.pattern}に一致する必要があります`;
          return `無効な${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `無効な数値: ${n.divisor}の倍数である必要があります`;
      case "unrecognized_keys":
        return `認識されていないキー${n.keys.length > 1 ? "群" : ""}: ${x(n.keys, "、")}`;
      case "invalid_key":
        return `${n.origin}内の無効なキー`;
      case "invalid_union":
        return "無効な入力";
      case "invalid_element":
        return `${n.origin}内の無効な値`;
      default:
        return "無効な入力";
    }
  };
};
function Db() {
  return { localeError: JO() };
}
var PO = (r) => {
    let t = typeof r;
    switch (t) {
      case "number":
        return Number.isNaN(r) ? "NaN" : "რიცხვი";
      case "object":{
          if (Array.isArray(r)) return "მასივი";
          if (r === null) return "null";
          if (Object.getPrototypeOf(r) !== Object.prototype && r.constructor)
          return r.constructor.name;
        }
    }
    return (
      {
        string: "სტრინგი",
        boolean: "ბულეანი",
        undefined: "undefined",
        bigint: "bigint",
        symbol: "symbol",
        function: "ფუნქცია"
      }[t] ?? t);

  },
  XO = () => {
    let r = {
      string: { unit: "სიმბოლო", verb: "უნდა შეიცავდეს" },
      file: { unit: "ბაიტი", verb: "უნდა შეიცავდეს" },
      array: { unit: "ელემენტი", verb: "უნდა შეიცავდეს" },
      set: { unit: "ელემენტი", verb: "უნდა შეიცავდეს" }
    };
    function t(o) {
      return r[o] ?? null;
    }
    let i = {
      regex: "შეყვანა",
      email: "ელ-ფოსტის მისამართი",
      url: "URL",
      emoji: "ემოჯი",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "თარიღი-დრო",
      date: "თარიღი",
      time: "დრო",
      duration: "ხანგრძლივობა",
      ipv4: "IPv4 მისამართი",
      ipv6: "IPv6 მისამართი",
      cidrv4: "IPv4 დიაპაზონი",
      cidrv6: "IPv6 დიაპაზონი",
      base64: "base64-კოდირებული სტრინგი",
      base64url: "base64url-კოდირებული სტრინგი",
      json_string: "JSON სტრინგი",
      e164: "E.164 ნომერი",
      jwt: "JWT",
      template_literal: "შეყვანა"
    };
    return (o) => {
      switch (o.code) {
        case "invalid_type":
          return `არასწორი შეყვანა: მოსალოდნელი ${o.expected}, მიღებული ${PO(o.input)}`;
        case "invalid_value":
          if (o.values.length === 1)
          return `არასწორი შეყვანა: მოსალოდნელი ${z(o.values[0])}`;
          return `არასწორი ვარიანტი: მოსალოდნელია ერთ-ერთი ${x(o.values, "|")}-დან`;
        case "too_big":{
            let n = o.inclusive ? "<=" : "<",
              e = t(o.origin);
            if (e)
            return `ზედმეტად დიდი: მოსალოდნელი ${o.origin ?? "მნიშვნელობა"} ${e.verb} ${n}${o.maximum.toString()} ${e.unit}`;
            return `ზედმეტად დიდი: მოსალოდნელი ${o.origin ?? "მნიშვნელობა"} იყოს ${n}${o.maximum.toString()}`;
          }
        case "too_small":{
            let n = o.inclusive ? ">=" : ">",
              e = t(o.origin);
            if (e)
            return `ზედმეტად პატარა: მოსალოდნელი ${o.origin} ${e.verb} ${n}${o.minimum.toString()} ${e.unit}`;
            return `ზედმეტად პატარა: მოსალოდნელი ${o.origin} იყოს ${n}${o.minimum.toString()}`;
          }
        case "invalid_format":{
            let n = o;
            if (n.format === "starts_with")
            return `არასწორი სტრინგი: უნდა იწყებოდეს "${n.prefix}"-ით`;
            if (n.format === "ends_with")
            return `არასწორი სტრინგი: უნდა მთავრდებოდეს "${n.suffix}"-ით`;
            if (n.format === "includes")
            return `არასწორი სტრინგი: უნდა შეიცავდეს "${n.includes}"-ს`;
            if (n.format === "regex")
            return `არასწორი სტრინგი: უნდა შეესაბამებოდეს შაბლონს ${n.pattern}`;
            return `არასწორი ${i[n.format] ?? o.format}`;
          }
        case "not_multiple_of":
          return `არასწორი რიცხვი: უნდა იყოს ${o.divisor}-ის ჯერადი`;
        case "unrecognized_keys":
          return `უცნობი გასაღებ${o.keys.length > 1 ? "ები" : "ი"}: ${x(o.keys, ", ")}`;
        case "invalid_key":
          return `არასწორი გასაღები ${o.origin}-ში`;
        case "invalid_union":
          return "არასწორი შეყვანა";
        case "invalid_element":
          return `არასწორი მნიშვნელობა ${o.origin}-ში`;
        default:
          return "არასწორი შეყვანა";
      }
    };
  };
function jb() {
  return { localeError: XO() };
}
var qO = () => {
  let r = {
    string: { unit: "តួអក្សរ", verb: "គួរមាន" },
    file: { unit: "បៃ", verb: "គួរមាន" },
    array: { unit: "ធាតុ", verb: "គួរមាន" },
    set: { unit: "ធាតុ", verb: "គួរមាន" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "មិនមែនជាលេខ (NaN)" : "លេខ";
        case "object":{
            if (Array.isArray(n)) return "អារេ (Array)";
            if (n === null) return "គ្មានតម្លៃ (null)";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ទិន្នន័យបញ្ចូល",
      email: "អាសយដ្ឋានអ៊ីមែល",
      url: "URL",
      emoji: "សញ្ញាអារម្មណ៍",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "កាលបរិច្ឆេទ និងម៉ោង ISO",
      date: "កាលបរិច្ឆេទ ISO",
      time: "ម៉ោង ISO",
      duration: "រយៈពេល ISO",
      ipv4: "អាសយដ្ឋាន IPv4",
      ipv6: "អាសយដ្ឋាន IPv6",
      cidrv4: "ដែនអាសយដ្ឋាន IPv4",
      cidrv6: "ដែនអាសយដ្ឋាន IPv6",
      base64: "ខ្សែអក្សរអ៊ិកូដ base64",
      base64url: "ខ្សែអក្សរអ៊ិកូដ base64url",
      json_string: "ខ្សែអក្សរ JSON",
      e164: "លេខ E.164",
      jwt: "JWT",
      template_literal: "ទិន្នន័យបញ្ចូល"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${n.expected} ប៉ុន្តែទទួលបាន ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${z(n.values[0])}`;
        return `ជម្រើសមិនត្រឹមត្រូវ៖ ត្រូវជាមួយក្នុងចំណោម ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `ធំពេក៖ ត្រូវការ ${n.origin ?? "តម្លៃ"} ${e} ${n.maximum.toString()} ${l.unit ?? "ធាតុ"}`;
          return `ធំពេក៖ ត្រូវការ ${n.origin ?? "តម្លៃ"} ${e} ${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `តូចពេក៖ ត្រូវការ ${n.origin} ${e} ${n.minimum.toString()} ${l.unit}`;
          return `តូចពេក៖ ត្រូវការ ${n.origin} ${e} ${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវចាប់ផ្តើមដោយ "${e.prefix}"`;
          if (e.format === "ends_with")
          return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវបញ្ចប់ដោយ "${e.suffix}"`;
          if (e.format === "includes")
          return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវមាន "${e.includes}"`;
          if (e.format === "regex")
          return `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវតែផ្គូផ្គងនឹងទម្រង់ដែលបានកំណត់ ${e.pattern}`;
          return `មិនត្រឹមត្រូវ៖ ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `លេខមិនត្រឹមត្រូវ៖ ត្រូវតែជាពហុគុណនៃ ${n.divisor}`;
      case "unrecognized_keys":
        return `រកឃើញសោមិនស្គាល់៖ ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `សោមិនត្រឹមត្រូវនៅក្នុង ${n.origin}`;
      case "invalid_union":
        return "ទិន្នន័យមិនត្រឹមត្រូវ";
      case "invalid_element":
        return `ទិន្នន័យមិនត្រឹមត្រូវនៅក្នុង ${n.origin}`;
      default:
        return "ទិន្នន័យមិនត្រឹមត្រូវ";
    }
  };
};
function ei() {
  return { localeError: qO() };
}
function Ob() {
  return ei();
}
var WO = () => {
  let r = {
    string: { unit: "문자", verb: "to have" },
    file: { unit: "바이트", verb: "to have" },
    array: { unit: "개", verb: "to have" },
    set: { unit: "개", verb: "to have" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "입력",
      email: "이메일 주소",
      url: "URL",
      emoji: "이모지",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO 날짜시간",
      date: "ISO 날짜",
      time: "ISO 시간",
      duration: "ISO 기간",
      ipv4: "IPv4 주소",
      ipv6: "IPv6 주소",
      cidrv4: "IPv4 범위",
      cidrv6: "IPv6 범위",
      base64: "base64 인코딩 문자열",
      base64url: "base64url 인코딩 문자열",
      json_string: "JSON 문자열",
      e164: "E.164 번호",
      jwt: "JWT",
      template_literal: "입력"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `잘못된 입력: 예상 타입은 ${n.expected}, 받은 타입은 ${i(n.input)}입니다`;
      case "invalid_value":
        if (n.values.length === 1)
        return `잘못된 입력: 값은 ${z(n.values[0])} 이어야 합니다`;
        return `잘못된 옵션: ${x(n.values, "또는 ")} 중 하나여야 합니다`;
      case "too_big":{
          let e = n.inclusive ? "이하" : "미만",
            l = e === "미만" ? "이어야 합니다" : "여야 합니다",
            u = t(n.origin),
            g = u?.unit ?? "요소";
          if (u)
          return `${n.origin ?? "값"}이 너무 큽니다: ${n.maximum.toString()}${g} ${e}${l}`;
          return `${n.origin ?? "값"}이 너무 큽니다: ${n.maximum.toString()} ${e}${l}`;
        }
      case "too_small":{
          let e = n.inclusive ? "이상" : "초과",
            l = e === "이상" ? "이어야 합니다" : "여야 합니다",
            u = t(n.origin),
            g = u?.unit ?? "요소";
          if (u)
          return `${n.origin ?? "값"}이 너무 작습니다: ${n.minimum.toString()}${g} ${e}${l}`;
          return `${n.origin ?? "값"}이 너무 작습니다: ${n.minimum.toString()} ${e}${l}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `잘못된 문자열: "${e.prefix}"(으)로 시작해야 합니다`;
          if (e.format === "ends_with")
          return `잘못된 문자열: "${e.suffix}"(으)로 끝나야 합니다`;
          if (e.format === "includes")
          return `잘못된 문자열: "${e.includes}"을(를) 포함해야 합니다`;
          if (e.format === "regex")
          return `잘못된 문자열: 정규식 ${e.pattern} 패턴과 일치해야 합니다`;
          return `잘못된 ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `잘못된 숫자: ${n.divisor}의 배수여야 합니다`;
      case "unrecognized_keys":
        return `인식할 수 없는 키: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `잘못된 키: ${n.origin}`;
      case "invalid_union":
        return "잘못된 입력";
      case "invalid_element":
        return `잘못된 값: ${n.origin}`;
      default:
        return "잘못된 입력";
    }
  };
};
function Ib() {
  return { localeError: WO() };
}
var KO = (r) => {
    return ci(typeof r, r);
  },
  ci = (r, t = void 0) => {
    switch (r) {
      case "number":
        return Number.isNaN(t) ? "NaN" : "skaičius";
      case "bigint":
        return "sveikasis skaičius";
      case "string":
        return "eilutė";
      case "boolean":
        return "loginė reikšmė";
      case "undefined":
      case "void":
        return "neapibrėžta reikšmė";
      case "function":
        return "funkcija";
      case "symbol":
        return "simbolis";
      case "object":{
          if (t === void 0) return "nežinomas objektas";
          if (t === null) return "nulinė reikšmė";
          if (Array.isArray(t)) return "masyvas";
          if (Object.getPrototypeOf(t) !== Object.prototype && t.constructor)
          return t.constructor.name;
          return "objektas";
        }
      case "null":
        return "nulinė reikšmė";
    }
    return r;
  },
  li = (r) => {
    return r.charAt(0).toUpperCase() + r.slice(1);
  };
function Iw(r) {
  let t = Math.abs(r),
    i = t % 10,
    o = t % 100;
  if (o >= 11 && o <= 19 || i === 0) return "many";
  if (i === 1) return "one";
  return "few";
}
var LO = () => {
  let r = {
    string: {
      unit: { one: "simbolis", few: "simboliai", many: "simbolių" },
      verb: {
        smaller: {
          inclusive: "turi būti ne ilgesnė kaip",
          notInclusive: "turi būti trumpesnė kaip"
        },
        bigger: {
          inclusive: "turi būti ne trumpesnė kaip",
          notInclusive: "turi būti ilgesnė kaip"
        }
      }
    },
    file: {
      unit: { one: "baitas", few: "baitai", many: "baitų" },
      verb: {
        smaller: {
          inclusive: "turi būti ne didesnis kaip",
          notInclusive: "turi būti mažesnis kaip"
        },
        bigger: {
          inclusive: "turi būti ne mažesnis kaip",
          notInclusive: "turi būti didesnis kaip"
        }
      }
    },
    array: {
      unit: { one: "elementą", few: "elementus", many: "elementų" },
      verb: {
        smaller: {
          inclusive: "turi turėti ne daugiau kaip",
          notInclusive: "turi turėti mažiau kaip"
        },
        bigger: {
          inclusive: "turi turėti ne mažiau kaip",
          notInclusive: "turi turėti daugiau kaip"
        }
      }
    },
    set: {
      unit: { one: "elementą", few: "elementus", many: "elementų" },
      verb: {
        smaller: {
          inclusive: "turi turėti ne daugiau kaip",
          notInclusive: "turi turėti mažiau kaip"
        },
        bigger: {
          inclusive: "turi turėti ne mažiau kaip",
          notInclusive: "turi turėti daugiau kaip"
        }
      }
    }
  };
  function t(o, n, e, l) {
    let u = r[o] ?? null;
    if (u === null) return u;
    return {
      unit: u.unit[n],
      verb: u.verb[l][e ? "inclusive" : "notInclusive"]
    };
  }
  let i = {
    regex: "įvestis",
    email: "el. pašto adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukmė",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 užkoduota eilutė",
    base64url: "base64url užkoduota eilutė",
    json_string: "JSON eilutė",
    e164: "E.164 numeris",
    jwt: "JWT",
    template_literal: "įvestis"
  };
  return (o) => {
    switch (o.code) {
      case "invalid_type":
        return `Gautas tipas ${KO(o.input)}, o tikėtasi - ${ci(o.expected)}`;
      case "invalid_value":
        if (o.values.length === 1) return `Privalo būti ${z(o.values[0])}`;
        return `Privalo būti vienas iš ${x(o.values, "|")} pasirinkimų`;
      case "too_big":{
          let n = ci(o.origin),
            e = t(o.origin, Iw(Number(o.maximum)), o.inclusive ?? !1, "smaller");
          if (e?.verb)
          return `${li(n ?? o.origin ?? "reikšmė")} ${e.verb} ${o.maximum.toString()} ${e.unit ?? "elementų"}`;
          let l = o.inclusive ? "ne didesnis kaip" : "mažesnis kaip";
          return `${li(n ?? o.origin ?? "reikšmė")} turi būti ${l} ${o.maximum.toString()} ${e?.unit}`;
        }
      case "too_small":{
          let n = ci(o.origin),
            e = t(o.origin, Iw(Number(o.minimum)), o.inclusive ?? !1, "bigger");
          if (e?.verb)
          return `${li(n ?? o.origin ?? "reikšmė")} ${e.verb} ${o.minimum.toString()} ${e.unit ?? "elementų"}`;
          let l = o.inclusive ? "ne mažesnis kaip" : "didesnis kaip";
          return `${li(n ?? o.origin ?? "reikšmė")} turi būti ${l} ${o.minimum.toString()} ${e?.unit}`;
        }
      case "invalid_format":{
          let n = o;
          if (n.format === "starts_with")
          return `Eilutė privalo prasidėti "${n.prefix}"`;
          if (n.format === "ends_with")
          return `Eilutė privalo pasibaigti "${n.suffix}"`;
          if (n.format === "includes")
          return `Eilutė privalo įtraukti "${n.includes}"`;
          if (n.format === "regex") return `Eilutė privalo atitikti ${n.pattern}`;
          return `Neteisingas ${i[n.format] ?? o.format}`;
        }
      case "not_multiple_of":
        return `Skaičius privalo būti ${o.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpažint${o.keys.length > 1 ? "i" : "as"} rakt${o.keys.length > 1 ? "ai" : "as"}: ${x(o.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga įvestis";
      case "invalid_element":{
          let n = ci(o.origin);
          return `${li(n ?? o.origin ?? "reikšmė")} turi klaidingą įvestį`;
        }
      default:
        return "Klaidinga įvestis";
    }
  };
};
function kb() {
  return { localeError: LO() };
}
var VO = () => {
  let r = {
    string: { unit: "знаци", verb: "да имаат" },
    file: { unit: "бајти", verb: "да имаат" },
    array: { unit: "ставки", verb: "да имаат" },
    set: { unit: "ставки", verb: "да имаат" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "број";
        case "object":{
            if (Array.isArray(n)) return "низа";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "внес",
      email: "адреса на е-пошта",
      url: "URL",
      emoji: "емоџи",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO датум и време",
      date: "ISO датум",
      time: "ISO време",
      duration: "ISO времетраење",
      ipv4: "IPv4 адреса",
      ipv6: "IPv6 адреса",
      cidrv4: "IPv4 опсег",
      cidrv6: "IPv6 опсег",
      base64: "base64-енкодирана низа",
      base64url: "base64url-енкодирана низа",
      json_string: "JSON низа",
      e164: "E.164 број",
      jwt: "JWT",
      template_literal: "внес"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Грешен внес: се очекува ${n.expected}, примено ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Invalid input: expected ${z(n.values[0])}`;
        return `Грешана опција: се очекува една ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Премногу голем: се очекува ${n.origin ?? "вредноста"} да има ${e}${n.maximum.toString()} ${l.unit ?? "елементи"}`;
          return `Премногу голем: се очекува ${n.origin ?? "вредноста"} да биде ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Премногу мал: се очекува ${n.origin} да има ${e}${n.minimum.toString()} ${l.unit}`;
          return `Премногу мал: се очекува ${n.origin} да биде ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Неважечка низа: мора да започнува со "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Неважечка низа: мора да завршува со "${e.suffix}"`;
          if (e.format === "includes")
          return `Неважечка низа: мора да вклучува "${e.includes}"`;
          if (e.format === "regex")
          return `Неважечка низа: мора да одгоара на патернот ${e.pattern}`;
          return `Invalid ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Грешен број: мора да биде делив со ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Непрепознаени клучеви" : "Непрепознаен клуч"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Грешен клуч во ${n.origin}`;
      case "invalid_union":
        return "Грешен внес";
      case "invalid_element":
        return `Грешна вредност во ${n.origin}`;
      default:
        return "Грешен внес";
    }
  };
};
function Ub() {
  return { localeError: VO() };
}
var YO = () => {
  let r = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "nombor";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "input",
      email: "alamat e-mel",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "tarikh masa ISO",
      date: "tarikh ISO",
      time: "masa ISO",
      duration: "tempoh ISO",
      ipv4: "alamat IPv4",
      ipv6: "alamat IPv6",
      cidrv4: "julat IPv4",
      cidrv6: "julat IPv6",
      base64: "string dikodkan base64",
      base64url: "string dikodkan base64url",
      json_string: "string JSON",
      e164: "nombor E.164",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Input tidak sah: dijangka ${n.expected}, diterima ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Input tidak sah: dijangka ${z(n.values[0])}`;
        return `Pilihan tidak sah: dijangka salah satu daripada ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Terlalu besar: dijangka ${n.origin ?? "nilai"} ${l.verb} ${e}${n.maximum.toString()} ${l.unit ?? "elemen"}`;
          return `Terlalu besar: dijangka ${n.origin ?? "nilai"} adalah ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Terlalu kecil: dijangka ${n.origin} ${l.verb} ${e}${n.minimum.toString()} ${l.unit}`;
          return `Terlalu kecil: dijangka ${n.origin} adalah ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `String tidak sah: mesti bermula dengan "${e.prefix}"`;
          if (e.format === "ends_with")
          return `String tidak sah: mesti berakhir dengan "${e.suffix}"`;
          if (e.format === "includes")
          return `String tidak sah: mesti mengandungi "${e.includes}"`;
          if (e.format === "regex")
          return `String tidak sah: mesti sepadan dengan corak ${e.pattern}`;
          return `${o[e.format] ?? n.format} tidak sah`;
        }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${n.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${n.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${n.origin}`;
      default:
        return "Input tidak sah";
    }
  };
};
function Jb() {
  return { localeError: YO() };
}
var EO = () => {
  let r = {
    string: { unit: "tekens" },
    file: { unit: "bytes" },
    array: { unit: "elementen" },
    set: { unit: "elementen" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "getal";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "invoer",
      email: "emailadres",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datum en tijd",
      date: "ISO datum",
      time: "ISO tijd",
      duration: "ISO duur",
      ipv4: "IPv4-adres",
      ipv6: "IPv6-adres",
      cidrv4: "IPv4-bereik",
      cidrv6: "IPv6-bereik",
      base64: "base64-gecodeerde tekst",
      base64url: "base64 URL-gecodeerde tekst",
      json_string: "JSON string",
      e164: "E.164-nummer",
      jwt: "JWT",
      template_literal: "invoer"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Ongeldige invoer: verwacht ${n.expected}, ontving ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Ongeldige invoer: verwacht ${z(n.values[0])}`;
        return `Ongeldige optie: verwacht één van ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Te lang: verwacht dat ${n.origin ?? "waarde"} ${e}${n.maximum.toString()} ${l.unit ?? "elementen"} bevat`;
          return `Te lang: verwacht dat ${n.origin ?? "waarde"} ${e}${n.maximum.toString()} is`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Te kort: verwacht dat ${n.origin} ${e}${n.minimum.toString()} ${l.unit} bevat`;
          return `Te kort: verwacht dat ${n.origin} ${e}${n.minimum.toString()} is`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Ongeldige tekst: moet met "${e.prefix}" beginnen`;
          if (e.format === "ends_with")
          return `Ongeldige tekst: moet op "${e.suffix}" eindigen`;
          if (e.format === "includes")
          return `Ongeldige tekst: moet "${e.includes}" bevatten`;
          if (e.format === "regex")
          return `Ongeldige tekst: moet overeenkomen met patroon ${e.pattern}`;
          return `Ongeldig: ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${n.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${n.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${n.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
};
function Pb() {
  return { localeError: EO() };
}
var QO = () => {
  let r = {
    string: { unit: "tegn", verb: "å ha" },
    file: { unit: "bytes", verb: "å ha" },
    array: { unit: "elementer", verb: "å inneholde" },
    set: { unit: "elementer", verb: "å inneholde" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "tall";
        case "object":{
            if (Array.isArray(n)) return "liste";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "input",
      email: "e-postadresse",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dato- og klokkeslett",
      date: "ISO-dato",
      time: "ISO-klokkeslett",
      duration: "ISO-varighet",
      ipv4: "IPv4-område",
      ipv6: "IPv6-område",
      cidrv4: "IPv4-spekter",
      cidrv6: "IPv6-spekter",
      base64: "base64-enkodet streng",
      base64url: "base64url-enkodet streng",
      json_string: "JSON-streng",
      e164: "E.164-nummer",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Ugyldig input: forventet ${n.expected}, fikk ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Ugyldig verdi: forventet ${z(n.values[0])}`;
        return `Ugyldig valg: forventet en av ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `For stor(t): forventet ${n.origin ?? "value"} til å ha ${e}${n.maximum.toString()} ${l.unit ?? "elementer"}`;
          return `For stor(t): forventet ${n.origin ?? "value"} til å ha ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `For lite(n): forventet ${n.origin} til å ha ${e}${n.minimum.toString()} ${l.unit}`;
          return `For lite(n): forventet ${n.origin} til å ha ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Ugyldig streng: må starte med "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Ugyldig streng: må ende med "${e.suffix}"`;
          if (e.format === "includes")
          return `Ugyldig streng: må inneholde "${e.includes}"`;
          if (e.format === "regex")
          return `Ugyldig streng: må matche mønsteret ${e.pattern}`;
          return `Ugyldig ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Ugyldig tall: må være et multiplum av ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Ukjente nøkler" : "Ukjent nøkkel"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig nøkkel i ${n.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${n.origin}`;
      default:
        return "Ugyldig input";
    }
  };
};
function Xb() {
  return { localeError: QO() };
}
var FO = () => {
  let r = {
    string: { unit: "harf", verb: "olmalıdır" },
    file: { unit: "bayt", verb: "olmalıdır" },
    array: { unit: "unsur", verb: "olmalıdır" },
    set: { unit: "unsur", verb: "olmalıdır" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "numara";
        case "object":{
            if (Array.isArray(n)) return "saf";
            if (n === null) return "gayb";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "giren",
      email: "epostagâh",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO hengâmı",
      date: "ISO tarihi",
      time: "ISO zamanı",
      duration: "ISO müddeti",
      ipv4: "IPv4 nişânı",
      ipv6: "IPv6 nişânı",
      cidrv4: "IPv4 menzili",
      cidrv6: "IPv6 menzili",
      base64: "base64-şifreli metin",
      base64url: "base64url-şifreli metin",
      json_string: "JSON metin",
      e164: "E.164 sayısı",
      jwt: "JWT",
      template_literal: "giren"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Fâsit giren: umulan ${n.expected}, alınan ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Fâsit giren: umulan ${z(n.values[0])}`;
        return `Fâsit tercih: mûteberler ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Fazla büyük: ${n.origin ?? "value"}, ${e}${n.maximum.toString()} ${l.unit ?? "elements"} sahip olmalıydı.`;
          return `Fazla büyük: ${n.origin ?? "value"}, ${e}${n.maximum.toString()} olmalıydı.`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Fazla küçük: ${n.origin}, ${e}${n.minimum.toString()} ${l.unit} sahip olmalıydı.`;
          return `Fazla küçük: ${n.origin}, ${e}${n.minimum.toString()} olmalıydı.`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Fâsit metin: "${e.prefix}" ile başlamalı.`;
          if (e.format === "ends_with")
          return `Fâsit metin: "${e.suffix}" ile bitmeli.`;
          if (e.format === "includes")
          return `Fâsit metin: "${e.includes}" ihtivâ etmeli.`;
          if (e.format === "regex")
          return `Fâsit metin: ${e.pattern} nakşına uymalı.`;
          return `Fâsit ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Fâsit sayı: ${n.divisor} katı olmalıydı.`;
      case "unrecognized_keys":
        return `Tanınmayan anahtar ${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} için tanınmayan anahtar var.`;
      case "invalid_union":
        return "Giren tanınamadı.";
      case "invalid_element":
        return `${n.origin} için tanınmayan kıymet var.`;
      default:
        return "Kıymet tanınamadı.";
    }
  };
};
function qb() {
  return { localeError: FO() };
}
var SO = () => {
  let r = {
    string: { unit: "توکي", verb: "ولري" },
    file: { unit: "بایټس", verb: "ولري" },
    array: { unit: "توکي", verb: "ولري" },
    set: { unit: "توکي", verb: "ولري" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "عدد";
        case "object":{
            if (Array.isArray(n)) return "ارې";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ورودي",
      email: "بریښنالیک",
      url: "یو آر ال",
      emoji: "ایموجي",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "نیټه او وخت",
      date: "نېټه",
      time: "وخت",
      duration: "موده",
      ipv4: "د IPv4 پته",
      ipv6: "د IPv6 پته",
      cidrv4: "د IPv4 ساحه",
      cidrv6: "د IPv6 ساحه",
      base64: "base64-encoded متن",
      base64url: "base64url-encoded متن",
      json_string: "JSON متن",
      e164: "د E.164 شمېره",
      jwt: "JWT",
      template_literal: "ورودي"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `ناسم ورودي: باید ${n.expected} وای, مګر ${i(n.input)} ترلاسه شو`;
      case "invalid_value":
        if (n.values.length === 1)
        return `ناسم ورودي: باید ${z(n.values[0])} وای`;
        return `ناسم انتخاب: باید یو له ${x(n.values, "|")} څخه وای`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `ډیر لوی: ${n.origin ?? "ارزښت"} باید ${e}${n.maximum.toString()} ${l.unit ?? "عنصرونه"} ولري`;
          return `ډیر لوی: ${n.origin ?? "ارزښت"} باید ${e}${n.maximum.toString()} وي`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `ډیر کوچنی: ${n.origin} باید ${e}${n.minimum.toString()} ${l.unit} ولري`;
          return `ډیر کوچنی: ${n.origin} باید ${e}${n.minimum.toString()} وي`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `ناسم متن: باید د "${e.prefix}" سره پیل شي`;
          if (e.format === "ends_with")
          return `ناسم متن: باید د "${e.suffix}" سره پای ته ورسيږي`;
          if (e.format === "includes")
          return `ناسم متن: باید "${e.includes}" ولري`;
          if (e.format === "regex")
          return `ناسم متن: باید د ${e.pattern} سره مطابقت ولري`;
          return `${o[e.format] ?? n.format} ناسم دی`;
        }
      case "not_multiple_of":
        return `ناسم عدد: باید د ${n.divisor} مضرب وي`;
      case "unrecognized_keys":
        return `ناسم ${n.keys.length > 1 ? "کلیډونه" : "کلیډ"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `ناسم کلیډ په ${n.origin} کې`;
      case "invalid_union":
        return "ناسمه ورودي";
      case "invalid_element":
        return `ناسم عنصر په ${n.origin} کې`;
      default:
        return "ناسمه ورودي";
    }
  };
};
function Wb() {
  return { localeError: SO() };
}
var GO = () => {
  let r = {
    string: { unit: "znaków", verb: "mieć" },
    file: { unit: "bajtów", verb: "mieć" },
    array: { unit: "elementów", verb: "mieć" },
    set: { unit: "elementów", verb: "mieć" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "liczba";
        case "object":{
            if (Array.isArray(n)) return "tablica";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "wyrażenie",
      email: "adres email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data i godzina w formacie ISO",
      date: "data w formacie ISO",
      time: "godzina w formacie ISO",
      duration: "czas trwania ISO",
      ipv4: "adres IPv4",
      ipv6: "adres IPv6",
      cidrv4: "zakres IPv4",
      cidrv6: "zakres IPv6",
      base64: "ciąg znaków zakodowany w formacie base64",
      base64url: "ciąg znaków zakodowany w formacie base64url",
      json_string: "ciąg znaków w formacie JSON",
      e164: "liczba E.164",
      jwt: "JWT",
      template_literal: "wejście"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Nieprawidłowe dane wejściowe: oczekiwano ${n.expected}, otrzymano ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Nieprawidłowe dane wejściowe: oczekiwano ${z(n.values[0])}`;
        return `Nieprawidłowa opcja: oczekiwano jednej z wartości ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Za duża wartość: oczekiwano, że ${n.origin ?? "wartość"} będzie mieć ${e}${n.maximum.toString()} ${l.unit ?? "elementów"}`;
          return `Zbyt duż(y/a/e): oczekiwano, że ${n.origin ?? "wartość"} będzie wynosić ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Za mała wartość: oczekiwano, że ${n.origin ?? "wartość"} będzie mieć ${e}${n.minimum.toString()} ${l.unit ?? "elementów"}`;
          return `Zbyt mał(y/a/e): oczekiwano, że ${n.origin ?? "wartość"} będzie wynosić ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Nieprawidłowy ciąg znaków: musi zaczynać się od "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Nieprawidłowy ciąg znaków: musi kończyć się na "${e.suffix}"`;
          if (e.format === "includes")
          return `Nieprawidłowy ciąg znaków: musi zawierać "${e.includes}"`;
          if (e.format === "regex")
          return `Nieprawidłowy ciąg znaków: musi odpowiadać wzorcowi ${e.pattern}`;
          return `Nieprawidłow(y/a/e) ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Nieprawidłowa liczba: musi być wielokrotnością ${n.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawidłowy klucz w ${n.origin}`;
      case "invalid_union":
        return "Nieprawidłowe dane wejściowe";
      case "invalid_element":
        return `Nieprawidłowa wartość w ${n.origin}`;
      default:
        return "Nieprawidłowe dane wejściowe";
    }
  };
};
function Kb() {
  return { localeError: GO() };
}
var NO = () => {
  let r = {
    string: { unit: "caracteres", verb: "ter" },
    file: { unit: "bytes", verb: "ter" },
    array: { unit: "itens", verb: "ter" },
    set: { unit: "itens", verb: "ter" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "número";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "nulo";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "padrão",
      email: "endereço de e-mail",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data e hora ISO",
      date: "data ISO",
      time: "hora ISO",
      duration: "duração ISO",
      ipv4: "endereço IPv4",
      ipv6: "endereço IPv6",
      cidrv4: "faixa de IPv4",
      cidrv6: "faixa de IPv6",
      base64: "texto codificado em base64",
      base64url: "URL codificada em base64",
      json_string: "texto JSON",
      e164: "número E.164",
      jwt: "JWT",
      template_literal: "entrada"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Tipo inválido: esperado ${n.expected}, recebido ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Entrada inválida: esperado ${z(n.values[0])}`;
        return `Opção inválida: esperada uma das ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Muito grande: esperado que ${n.origin ?? "valor"} tivesse ${e}${n.maximum.toString()} ${l.unit ?? "elementos"}`;
          return `Muito grande: esperado que ${n.origin ?? "valor"} fosse ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Muito pequeno: esperado que ${n.origin} tivesse ${e}${n.minimum.toString()} ${l.unit}`;
          return `Muito pequeno: esperado que ${n.origin} fosse ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Texto inválido: deve começar com "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Texto inválido: deve terminar com "${e.suffix}"`;
          if (e.format === "includes")
          return `Texto inválido: deve incluir "${e.includes}"`;
          if (e.format === "regex")
          return `Texto inválido: deve corresponder ao padrão ${e.pattern}`;
          return `${o[e.format] ?? n.format} inválido`;
        }
      case "not_multiple_of":
        return `Número inválido: deve ser múltiplo de ${n.divisor}`;
      case "unrecognized_keys":
        return `Chave${n.keys.length > 1 ? "s" : ""} desconhecida${n.keys.length > 1 ? "s" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Chave inválida em ${n.origin}`;
      case "invalid_union":
        return "Entrada inválida";
      case "invalid_element":
        return `Valor inválido em ${n.origin}`;
      default:
        return "Campo inválido";
    }
  };
};
function Lb() {
  return { localeError: NO() };
}
function kw(r, t, i, o) {
  let n = Math.abs(r),
    e = n % 10,
    l = n % 100;
  if (l >= 11 && l <= 19) return o;
  if (e === 1) return t;
  if (e >= 2 && e <= 4) return i;
  return o;
}
var BO = () => {
  let r = {
    string: {
      unit: { one: "символ", few: "символа", many: "символов" },
      verb: "иметь"
    },
    file: { unit: { one: "байт", few: "байта", many: "байт" }, verb: "иметь" },
    array: {
      unit: { one: "элемент", few: "элемента", many: "элементов" },
      verb: "иметь"
    },
    set: {
      unit: { one: "элемент", few: "элемента", many: "элементов" },
      verb: "иметь"
    }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "число";
        case "object":{
            if (Array.isArray(n)) return "массив";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ввод",
      email: "email адрес",
      url: "URL",
      emoji: "эмодзи",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO дата и время",
      date: "ISO дата",
      time: "ISO время",
      duration: "ISO длительность",
      ipv4: "IPv4 адрес",
      ipv6: "IPv6 адрес",
      cidrv4: "IPv4 диапазон",
      cidrv6: "IPv6 диапазон",
      base64: "строка в формате base64",
      base64url: "строка в формате base64url",
      json_string: "JSON строка",
      e164: "номер E.164",
      jwt: "JWT",
      template_literal: "ввод"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Неверный ввод: ожидалось ${n.expected}, получено ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Неверный ввод: ожидалось ${z(n.values[0])}`;
        return `Неверный вариант: ожидалось одно из ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l) {
            let u = Number(n.maximum),
              g = kw(u, l.unit.one, l.unit.few, l.unit.many);
            return `Слишком большое значение: ожидалось, что ${n.origin ?? "значение"} будет иметь ${e}${n.maximum.toString()} ${g}`;
          }
          return `Слишком большое значение: ожидалось, что ${n.origin ?? "значение"} будет ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l) {
            let u = Number(n.minimum),
              g = kw(u, l.unit.one, l.unit.few, l.unit.many);
            return `Слишком маленькое значение: ожидалось, что ${n.origin} будет иметь ${e}${n.minimum.toString()} ${g}`;
          }
          return `Слишком маленькое значение: ожидалось, что ${n.origin} будет ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Неверная строка: должна начинаться с "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Неверная строка: должна заканчиваться на "${e.suffix}"`;
          if (e.format === "includes")
          return `Неверная строка: должна содержать "${e.includes}"`;
          if (e.format === "regex")
          return `Неверная строка: должна соответствовать шаблону ${e.pattern}`;
          return `Неверный ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Неверное число: должно быть кратным ${n.divisor}`;
      case "unrecognized_keys":
        return `Нераспознанн${n.keys.length > 1 ? "ые" : "ый"} ключ${n.keys.length > 1 ? "и" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Неверный ключ в ${n.origin}`;
      case "invalid_union":
        return "Неверные входные данные";
      case "invalid_element":
        return `Неверное значение в ${n.origin}`;
      default:
        return "Неверные входные данные";
    }
  };
};
function Vb() {
  return { localeError: BO() };
}
var yO = () => {
  let r = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "število";
        case "object":{
            if (Array.isArray(n)) return "tabela";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "vnos",
      email: "e-poštni naslov",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datum in čas",
      date: "ISO datum",
      time: "ISO čas",
      duration: "ISO trajanje",
      ipv4: "IPv4 naslov",
      ipv6: "IPv6 naslov",
      cidrv4: "obseg IPv4",
      cidrv6: "obseg IPv6",
      base64: "base64 kodiran niz",
      base64url: "base64url kodiran niz",
      json_string: "JSON niz",
      e164: "E.164 številka",
      jwt: "JWT",
      template_literal: "vnos"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Neveljaven vnos: pričakovano ${n.expected}, prejeto ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Neveljaven vnos: pričakovano ${z(n.values[0])}`;
        return `Neveljavna možnost: pričakovano eno izmed ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Preveliko: pričakovano, da bo ${n.origin ?? "vrednost"} imelo ${e}${n.maximum.toString()} ${l.unit ?? "elementov"}`;
          return `Preveliko: pričakovano, da bo ${n.origin ?? "vrednost"} ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Premajhno: pričakovano, da bo ${n.origin} imelo ${e}${n.minimum.toString()} ${l.unit}`;
          return `Premajhno: pričakovano, da bo ${n.origin} ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Neveljaven niz: mora se začeti z "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Neveljaven niz: mora se končati z "${e.suffix}"`;
          if (e.format === "includes")
          return `Neveljaven niz: mora vsebovati "${e.includes}"`;
          if (e.format === "regex")
          return `Neveljaven niz: mora ustrezati vzorcu ${e.pattern}`;
          return `Neveljaven ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Neveljavno število: mora biti večkratnik ${n.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${n.keys.length > 1 ? "i ključi" : " ključ"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven ključ v ${n.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${n.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
};
function Yb() {
  return { localeError: yO() };
}
var AO = () => {
  let r = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att innehålla" },
    set: { unit: "objekt", verb: "att innehålla" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "antal";
        case "object":{
            if (Array.isArray(n)) return "lista";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "reguljärt uttryck",
      email: "e-postadress",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-datum och tid",
      date: "ISO-datum",
      time: "ISO-tid",
      duration: "ISO-varaktighet",
      ipv4: "IPv4-intervall",
      ipv6: "IPv6-intervall",
      cidrv4: "IPv4-spektrum",
      cidrv6: "IPv6-spektrum",
      base64: "base64-kodad sträng",
      base64url: "base64url-kodad sträng",
      json_string: "JSON-sträng",
      e164: "E.164-nummer",
      jwt: "JWT",
      template_literal: "mall-literal"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Ogiltig inmatning: förväntat ${n.expected}, fick ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Ogiltig inmatning: förväntat ${z(n.values[0])}`;
        return `Ogiltigt val: förväntade en av ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `För stor(t): förväntade ${n.origin ?? "värdet"} att ha ${e}${n.maximum.toString()} ${l.unit ?? "element"}`;
          return `För stor(t): förväntat ${n.origin ?? "värdet"} att ha ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `För lite(t): förväntade ${n.origin ?? "värdet"} att ha ${e}${n.minimum.toString()} ${l.unit}`;
          return `För lite(t): förväntade ${n.origin ?? "värdet"} att ha ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Ogiltig sträng: måste börja med "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Ogiltig sträng: måste sluta med "${e.suffix}"`;
          if (e.format === "includes")
          return `Ogiltig sträng: måste innehålla "${e.includes}"`;
          if (e.format === "regex")
          return `Ogiltig sträng: måste matcha mönstret "${e.pattern}"`;
          return `Ogiltig(t) ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Ogiltigt tal: måste vara en multipel av ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Okända nycklar" : "Okänd nyckel"}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${n.origin ?? "värdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt värde i ${n.origin ?? "värdet"}`;
      default:
        return "Ogiltig input";
    }
  };
};
function Eb() {
  return { localeError: AO() };
}
var HO = () => {
  let r = {
    string: { unit: "எழுத்துக்கள்", verb: "கொண்டிருக்க வேண்டும்" },
    file: { unit: "பைட்டுகள்", verb: "கொண்டிருக்க வேண்டும்" },
    array: { unit: "உறுப்புகள்", verb: "கொண்டிருக்க வேண்டும்" },
    set: { unit: "உறுப்புகள்", verb: "கொண்டிருக்க வேண்டும்" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "எண் அல்லாதது" : "எண்";
        case "object":{
            if (Array.isArray(n)) return "அணி";
            if (n === null) return "வெறுமை";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "உள்ளீடு",
      email: "மின்னஞ்சல் முகவரி",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO தேதி நேரம்",
      date: "ISO தேதி",
      time: "ISO நேரம்",
      duration: "ISO கால அளவு",
      ipv4: "IPv4 முகவரி",
      ipv6: "IPv6 முகவரி",
      cidrv4: "IPv4 வரம்பு",
      cidrv6: "IPv6 வரம்பு",
      base64: "base64-encoded சரம்",
      base64url: "base64url-encoded சரம்",
      json_string: "JSON சரம்",
      e164: "E.164 எண்",
      jwt: "JWT",
      template_literal: "input"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${n.expected}, பெறப்பட்டது ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${z(n.values[0])}`;
        return `தவறான விருப்பம்: எதிர்பார்க்கப்பட்டது ${x(n.values, "|")} இல் ஒன்று`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${n.origin ?? "மதிப்பு"} ${e}${n.maximum.toString()} ${l.unit ?? "உறுப்புகள்"} ஆக இருக்க வேண்டும்`;
          return `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${n.origin ?? "மதிப்பு"} ${e}${n.maximum.toString()} ஆக இருக்க வேண்டும்`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${n.origin} ${e}${n.minimum.toString()} ${l.unit} ஆக இருக்க வேண்டும்`;
          return `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${n.origin} ${e}${n.minimum.toString()} ஆக இருக்க வேண்டும்`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `தவறான சரம்: "${e.prefix}" இல் தொடங்க வேண்டும்`;
          if (e.format === "ends_with")
          return `தவறான சரம்: "${e.suffix}" இல் முடிவடைய வேண்டும்`;
          if (e.format === "includes")
          return `தவறான சரம்: "${e.includes}" ஐ உள்ளடக்க வேண்டும்`;
          if (e.format === "regex")
          return `தவறான சரம்: ${e.pattern} முறைபாட்டுடன் பொருந்த வேண்டும்`;
          return `தவறான ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `தவறான எண்: ${n.divisor} இன் பலமாக இருக்க வேண்டும்`;
      case "unrecognized_keys":
        return `அடையாளம் தெரியாத விசை${n.keys.length > 1 ? "கள்" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} இல் தவறான விசை`;
      case "invalid_union":
        return "தவறான உள்ளீடு";
      case "invalid_element":
        return `${n.origin} இல் தவறான மதிப்பு`;
      default:
        return "தவறான உள்ளீடு";
    }
  };
};
function Qb() {
  return { localeError: HO() };
}
var RO = () => {
  let r = {
    string: { unit: "ตัวอักษร", verb: "ควรมี" },
    file: { unit: "ไบต์", verb: "ควรมี" },
    array: { unit: "รายการ", verb: "ควรมี" },
    set: { unit: "รายการ", verb: "ควรมี" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "ไม่ใช่ตัวเลข (NaN)" : "ตัวเลข";
        case "object":{
            if (Array.isArray(n)) return "อาร์เรย์ (Array)";
            if (n === null) return "ไม่มีค่า (null)";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ข้อมูลที่ป้อน",
      email: "ที่อยู่อีเมล",
      url: "URL",
      emoji: "อิโมจิ",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "วันที่เวลาแบบ ISO",
      date: "วันที่แบบ ISO",
      time: "เวลาแบบ ISO",
      duration: "ช่วงเวลาแบบ ISO",
      ipv4: "ที่อยู่ IPv4",
      ipv6: "ที่อยู่ IPv6",
      cidrv4: "ช่วง IP แบบ IPv4",
      cidrv6: "ช่วง IP แบบ IPv6",
      base64: "ข้อความแบบ Base64",
      base64url: "ข้อความแบบ Base64 สำหรับ URL",
      json_string: "ข้อความแบบ JSON",
      e164: "เบอร์โทรศัพท์ระหว่างประเทศ (E.164)",
      jwt: "โทเคน JWT",
      template_literal: "ข้อมูลที่ป้อน"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น ${n.expected} แต่ได้รับ ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `ค่าไม่ถูกต้อง: ควรเป็น ${z(n.values[0])}`;
        return `ตัวเลือกไม่ถูกต้อง: ควรเป็นหนึ่งใน ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "ไม่เกิน" : "น้อยกว่า",
            l = t(n.origin);
          if (l)
          return `เกินกำหนด: ${n.origin ?? "ค่า"} ควรมี${e} ${n.maximum.toString()} ${l.unit ?? "รายการ"}`;
          return `เกินกำหนด: ${n.origin ?? "ค่า"} ควรมี${e} ${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? "อย่างน้อย" : "มากกว่า",
            l = t(n.origin);
          if (l)
          return `น้อยกว่ากำหนด: ${n.origin} ควรมี${e} ${n.minimum.toString()} ${l.unit}`;
          return `น้อยกว่ากำหนด: ${n.origin} ควรมี${e} ${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `รูปแบบไม่ถูกต้อง: ข้อความต้องขึ้นต้นด้วย "${e.prefix}"`;
          if (e.format === "ends_with")
          return `รูปแบบไม่ถูกต้อง: ข้อความต้องลงท้ายด้วย "${e.suffix}"`;
          if (e.format === "includes")
          return `รูปแบบไม่ถูกต้อง: ข้อความต้องมี "${e.includes}" อยู่ในข้อความ`;
          if (e.format === "regex")
          return `รูปแบบไม่ถูกต้อง: ต้องตรงกับรูปแบบที่กำหนด ${e.pattern}`;
          return `รูปแบบไม่ถูกต้อง: ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `ตัวเลขไม่ถูกต้อง: ต้องเป็นจำนวนที่หารด้วย ${n.divisor} ได้ลงตัว`;
      case "unrecognized_keys":
        return `พบคีย์ที่ไม่รู้จัก: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `คีย์ไม่ถูกต้องใน ${n.origin}`;
      case "invalid_union":
        return "ข้อมูลไม่ถูกต้อง: ไม่ตรงกับรูปแบบยูเนียนที่กำหนดไว้";
      case "invalid_element":
        return `ข้อมูลไม่ถูกต้องใน ${n.origin}`;
      default:
        return "ข้อมูลไม่ถูกต้อง";
    }
  };
};
function Fb() {
  return { localeError: RO() };
}
var MO = (r) => {
    let t = typeof r;
    switch (t) {
      case "number":
        return Number.isNaN(r) ? "NaN" : "number";
      case "object":{
          if (Array.isArray(r)) return "array";
          if (r === null) return "null";
          if (Object.getPrototypeOf(r) !== Object.prototype && r.constructor)
          return r.constructor.name;
        }
    }
    return t;
  },
  ZO = () => {
    let r = {
      string: { unit: "karakter", verb: "olmalı" },
      file: { unit: "bayt", verb: "olmalı" },
      array: { unit: "öğe", verb: "olmalı" },
      set: { unit: "öğe", verb: "olmalı" }
    };
    function t(o) {
      return r[o] ?? null;
    }
    let i = {
      regex: "girdi",
      email: "e-posta adresi",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO tarih ve saat",
      date: "ISO tarih",
      time: "ISO saat",
      duration: "ISO süre",
      ipv4: "IPv4 adresi",
      ipv6: "IPv6 adresi",
      cidrv4: "IPv4 aralığı",
      cidrv6: "IPv6 aralığı",
      base64: "base64 ile şifrelenmiş metin",
      base64url: "base64url ile şifrelenmiş metin",
      json_string: "JSON dizesi",
      e164: "E.164 sayısı",
      jwt: "JWT",
      template_literal: "Şablon dizesi"
    };
    return (o) => {
      switch (o.code) {
        case "invalid_type":
          return `Geçersiz değer: beklenen ${o.expected}, alınan ${MO(o.input)}`;
        case "invalid_value":
          if (o.values.length === 1)
          return `Geçersiz değer: beklenen ${z(o.values[0])}`;
          return `Geçersiz seçenek: aşağıdakilerden biri olmalı: ${x(o.values, "|")}`;
        case "too_big":{
            let n = o.inclusive ? "<=" : "<",
              e = t(o.origin);
            if (e)
            return `Çok büyük: beklenen ${o.origin ?? "değer"} ${n}${o.maximum.toString()} ${e.unit ?? "öğe"}`;
            return `Çok büyük: beklenen ${o.origin ?? "değer"} ${n}${o.maximum.toString()}`;
          }
        case "too_small":{
            let n = o.inclusive ? ">=" : ">",
              e = t(o.origin);
            if (e)
            return `Çok küçük: beklenen ${o.origin} ${n}${o.minimum.toString()} ${e.unit}`;
            return `Çok küçük: beklenen ${o.origin} ${n}${o.minimum.toString()}`;
          }
        case "invalid_format":{
            let n = o;
            if (n.format === "starts_with")
            return `Geçersiz metin: "${n.prefix}" ile başlamalı`;
            if (n.format === "ends_with")
            return `Geçersiz metin: "${n.suffix}" ile bitmeli`;
            if (n.format === "includes")
            return `Geçersiz metin: "${n.includes}" içermeli`;
            if (n.format === "regex")
            return `Geçersiz metin: ${n.pattern} desenine uymalı`;
            return `Geçersiz ${i[n.format] ?? o.format}`;
          }
        case "not_multiple_of":
          return `Geçersiz sayı: ${o.divisor} ile tam bölünebilmeli`;
        case "unrecognized_keys":
          return `Tanınmayan anahtar${o.keys.length > 1 ? "lar" : ""}: ${x(o.keys, ", ")}`;
        case "invalid_key":
          return `${o.origin} içinde geçersiz anahtar`;
        case "invalid_union":
          return "Geçersiz değer";
        case "invalid_element":
          return `${o.origin} içinde geçersiz değer`;
        default:
          return "Geçersiz değer";
      }
    };
  };
function Sb() {
  return { localeError: ZO() };
}
var CO = () => {
  let r = {
    string: { unit: "символів", verb: "матиме" },
    file: { unit: "байтів", verb: "матиме" },
    array: { unit: "елементів", verb: "матиме" },
    set: { unit: "елементів", verb: "матиме" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "число";
        case "object":{
            if (Array.isArray(n)) return "масив";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "вхідні дані",
      email: "адреса електронної пошти",
      url: "URL",
      emoji: "емодзі",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "дата та час ISO",
      date: "дата ISO",
      time: "час ISO",
      duration: "тривалість ISO",
      ipv4: "адреса IPv4",
      ipv6: "адреса IPv6",
      cidrv4: "діапазон IPv4",
      cidrv6: "діапазон IPv6",
      base64: "рядок у кодуванні base64",
      base64url: "рядок у кодуванні base64url",
      json_string: "рядок JSON",
      e164: "номер E.164",
      jwt: "JWT",
      template_literal: "вхідні дані"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Неправильні вхідні дані: очікується ${n.expected}, отримано ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Неправильні вхідні дані: очікується ${z(n.values[0])}`;
        return `Неправильна опція: очікується одне з ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Занадто велике: очікується, що ${n.origin ?? "значення"} ${l.verb} ${e}${n.maximum.toString()} ${l.unit ?? "елементів"}`;
          return `Занадто велике: очікується, що ${n.origin ?? "значення"} буде ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Занадто мале: очікується, що ${n.origin} ${l.verb} ${e}${n.minimum.toString()} ${l.unit}`;
          return `Занадто мале: очікується, що ${n.origin} буде ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Неправильний рядок: повинен починатися з "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Неправильний рядок: повинен закінчуватися на "${e.suffix}"`;
          if (e.format === "includes")
          return `Неправильний рядок: повинен містити "${e.includes}"`;
          if (e.format === "regex")
          return `Неправильний рядок: повинен відповідати шаблону ${e.pattern}`;
          return `Неправильний ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Неправильне число: повинно бути кратним ${n.divisor}`;
      case "unrecognized_keys":
        return `Нерозпізнаний ключ${n.keys.length > 1 ? "і" : ""}: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Неправильний ключ у ${n.origin}`;
      case "invalid_union":
        return "Неправильні вхідні дані";
      case "invalid_element":
        return `Неправильне значення у ${n.origin}`;
      default:
        return "Неправильні вхідні дані";
    }
  };
};
function ui() {
  return { localeError: CO() };
}
function Gb() {
  return ui();
}
var TO = () => {
  let r = {
    string: { unit: "حروف", verb: "ہونا" },
    file: { unit: "بائٹس", verb: "ہونا" },
    array: { unit: "آئٹمز", verb: "ہونا" },
    set: { unit: "آئٹمز", verb: "ہونا" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "نمبر";
        case "object":{
            if (Array.isArray(n)) return "آرے";
            if (n === null) return "نل";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ان پٹ",
      email: "ای میل ایڈریس",
      url: "یو آر ایل",
      emoji: "ایموجی",
      uuid: "یو یو آئی ڈی",
      uuidv4: "یو یو آئی ڈی وی 4",
      uuidv6: "یو یو آئی ڈی وی 6",
      nanoid: "نینو آئی ڈی",
      guid: "جی یو آئی ڈی",
      cuid: "سی یو آئی ڈی",
      cuid2: "سی یو آئی ڈی 2",
      ulid: "یو ایل آئی ڈی",
      xid: "ایکس آئی ڈی",
      ksuid: "کے ایس یو آئی ڈی",
      datetime: "آئی ایس او ڈیٹ ٹائم",
      date: "آئی ایس او تاریخ",
      time: "آئی ایس او وقت",
      duration: "آئی ایس او مدت",
      ipv4: "آئی پی وی 4 ایڈریس",
      ipv6: "آئی پی وی 6 ایڈریس",
      cidrv4: "آئی پی وی 4 رینج",
      cidrv6: "آئی پی وی 6 رینج",
      base64: "بیس 64 ان کوڈڈ سٹرنگ",
      base64url: "بیس 64 یو آر ایل ان کوڈڈ سٹرنگ",
      json_string: "جے ایس او این سٹرنگ",
      e164: "ای 164 نمبر",
      jwt: "جے ڈبلیو ٹی",
      template_literal: "ان پٹ"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `غلط ان پٹ: ${n.expected} متوقع تھا، ${i(n.input)} موصول ہوا`;
      case "invalid_value":
        if (n.values.length === 1)
        return `غلط ان پٹ: ${z(n.values[0])} متوقع تھا`;
        return `غلط آپشن: ${x(n.values, "|")} میں سے ایک متوقع تھا`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `بہت بڑا: ${n.origin ?? "ویلیو"} کے ${e}${n.maximum.toString()} ${l.unit ?? "عناصر"} ہونے متوقع تھے`;
          return `بہت بڑا: ${n.origin ?? "ویلیو"} کا ${e}${n.maximum.toString()} ہونا متوقع تھا`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `بہت چھوٹا: ${n.origin} کے ${e}${n.minimum.toString()} ${l.unit} ہونے متوقع تھے`;
          return `بہت چھوٹا: ${n.origin} کا ${e}${n.minimum.toString()} ہونا متوقع تھا`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `غلط سٹرنگ: "${e.prefix}" سے شروع ہونا چاہیے`;
          if (e.format === "ends_with")
          return `غلط سٹرنگ: "${e.suffix}" پر ختم ہونا چاہیے`;
          if (e.format === "includes")
          return `غلط سٹرنگ: "${e.includes}" شامل ہونا چاہیے`;
          if (e.format === "regex")
          return `غلط سٹرنگ: پیٹرن ${e.pattern} سے میچ ہونا چاہیے`;
          return `غلط ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `غلط نمبر: ${n.divisor} کا مضاعف ہونا چاہیے`;
      case "unrecognized_keys":
        return `غیر تسلیم شدہ کی${n.keys.length > 1 ? "ز" : ""}: ${x(n.keys, "، ")}`;
      case "invalid_key":
        return `${n.origin} میں غلط کی`;
      case "invalid_union":
        return "غلط ان پٹ";
      case "invalid_element":
        return `${n.origin} میں غلط ویلیو`;
      default:
        return "غلط ان پٹ";
    }
  };
};
function Nb() {
  return { localeError: TO() };
}
var dO = () => {
  let r = {
    string: { unit: "ký tự", verb: "có" },
    file: { unit: "byte", verb: "có" },
    array: { unit: "phần tử", verb: "có" },
    set: { unit: "phần tử", verb: "có" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "số";
        case "object":{
            if (Array.isArray(n)) return "mảng";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "đầu vào",
      email: "địa chỉ email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ngày giờ ISO",
      date: "ngày ISO",
      time: "giờ ISO",
      duration: "khoảng thời gian ISO",
      ipv4: "địa chỉ IPv4",
      ipv6: "địa chỉ IPv6",
      cidrv4: "dải IPv4",
      cidrv6: "dải IPv6",
      base64: "chuỗi mã hóa base64",
      base64url: "chuỗi mã hóa base64url",
      json_string: "chuỗi JSON",
      e164: "số E.164",
      jwt: "JWT",
      template_literal: "đầu vào"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Đầu vào không hợp lệ: mong đợi ${n.expected}, nhận được ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Đầu vào không hợp lệ: mong đợi ${z(n.values[0])}`;
        return `Tùy chọn không hợp lệ: mong đợi một trong các giá trị ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Quá lớn: mong đợi ${n.origin ?? "giá trị"} ${l.verb} ${e}${n.maximum.toString()} ${l.unit ?? "phần tử"}`;
          return `Quá lớn: mong đợi ${n.origin ?? "giá trị"} ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Quá nhỏ: mong đợi ${n.origin} ${l.verb} ${e}${n.minimum.toString()} ${l.unit}`;
          return `Quá nhỏ: mong đợi ${n.origin} ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Chuỗi không hợp lệ: phải bắt đầu bằng "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Chuỗi không hợp lệ: phải kết thúc bằng "${e.suffix}"`;
          if (e.format === "includes")
          return `Chuỗi không hợp lệ: phải bao gồm "${e.includes}"`;
          if (e.format === "regex")
          return `Chuỗi không hợp lệ: phải khớp với mẫu ${e.pattern}`;
          return `${o[e.format] ?? n.format} không hợp lệ`;
        }
      case "not_multiple_of":
        return `Số không hợp lệ: phải là bội số của ${n.divisor}`;
      case "unrecognized_keys":
        return `Khóa không được nhận dạng: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Khóa không hợp lệ trong ${n.origin}`;
      case "invalid_union":
        return "Đầu vào không hợp lệ";
      case "invalid_element":
        return `Giá trị không hợp lệ trong ${n.origin}`;
      default:
        return "Đầu vào không hợp lệ";
    }
  };
};
function Bb() {
  return { localeError: dO() };
}
var sO = () => {
  let r = {
    string: { unit: "字符", verb: "包含" },
    file: { unit: "字节", verb: "包含" },
    array: { unit: "项", verb: "包含" },
    set: { unit: "项", verb: "包含" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "非数字(NaN)" : "数字";
        case "object":{
            if (Array.isArray(n)) return "数组";
            if (n === null) return "空值(null)";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "输入",
      email: "电子邮件",
      url: "URL",
      emoji: "表情符号",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO日期时间",
      date: "ISO日期",
      time: "ISO时间",
      duration: "ISO时长",
      ipv4: "IPv4地址",
      ipv6: "IPv6地址",
      cidrv4: "IPv4网段",
      cidrv6: "IPv6网段",
      base64: "base64编码字符串",
      base64url: "base64url编码字符串",
      json_string: "JSON字符串",
      e164: "E.164号码",
      jwt: "JWT",
      template_literal: "输入"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `无效输入：期望 ${n.expected}，实际接收 ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1) return `无效输入：期望 ${z(n.values[0])}`;
        return `无效选项：期望以下之一 ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `数值过大：期望 ${n.origin ?? "值"} ${e}${n.maximum.toString()} ${l.unit ?? "个元素"}`;
          return `数值过大：期望 ${n.origin ?? "值"} ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `数值过小：期望 ${n.origin} ${e}${n.minimum.toString()} ${l.unit}`;
          return `数值过小：期望 ${n.origin} ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `无效字符串：必须以 "${e.prefix}" 开头`;
          if (e.format === "ends_with")
          return `无效字符串：必须以 "${e.suffix}" 结尾`;
          if (e.format === "includes")
          return `无效字符串：必须包含 "${e.includes}"`;
          if (e.format === "regex")
          return `无效字符串：必须满足正则表达式 ${e.pattern}`;
          return `无效${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `无效数字：必须是 ${n.divisor} 的倍数`;
      case "unrecognized_keys":
        return `出现未知的键(key): ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} 中的键(key)无效`;
      case "invalid_union":
        return "无效输入";
      case "invalid_element":
        return `${n.origin} 中包含无效值(value)`;
      default:
        return "无效输入";
    }
  };
};
function yb() {
  return { localeError: sO() };
}
var rI = () => {
  let r = {
    string: { unit: "字元", verb: "擁有" },
    file: { unit: "位元組", verb: "擁有" },
    array: { unit: "項目", verb: "擁有" },
    set: { unit: "項目", verb: "擁有" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "number";
        case "object":{
            if (Array.isArray(n)) return "array";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "輸入",
      email: "郵件地址",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO 日期時間",
      date: "ISO 日期",
      time: "ISO 時間",
      duration: "ISO 期間",
      ipv4: "IPv4 位址",
      ipv6: "IPv6 位址",
      cidrv4: "IPv4 範圍",
      cidrv6: "IPv6 範圍",
      base64: "base64 編碼字串",
      base64url: "base64url 編碼字串",
      json_string: "JSON 字串",
      e164: "E.164 數值",
      jwt: "JWT",
      template_literal: "輸入"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `無效的輸入值：預期為 ${n.expected}，但收到 ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `無效的輸入值：預期為 ${z(n.values[0])}`;
        return `無效的選項：預期為以下其中之一 ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `數值過大：預期 ${n.origin ?? "值"} 應為 ${e}${n.maximum.toString()} ${l.unit ?? "個元素"}`;
          return `數值過大：預期 ${n.origin ?? "值"} 應為 ${e}${n.maximum.toString()}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `數值過小：預期 ${n.origin} 應為 ${e}${n.minimum.toString()} ${l.unit}`;
          return `數值過小：預期 ${n.origin} 應為 ${e}${n.minimum.toString()}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `無效的字串：必須以 "${e.prefix}" 開頭`;
          if (e.format === "ends_with")
          return `無效的字串：必須以 "${e.suffix}" 結尾`;
          if (e.format === "includes")
          return `無效的字串：必須包含 "${e.includes}"`;
          if (e.format === "regex")
          return `無效的字串：必須符合格式 ${e.pattern}`;
          return `無效的 ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `無效的數字：必須為 ${n.divisor} 的倍數`;
      case "unrecognized_keys":
        return `無法識別的鍵值${n.keys.length > 1 ? "們" : ""}：${x(n.keys, "、")}`;
      case "invalid_key":
        return `${n.origin} 中有無效的鍵值`;
      case "invalid_union":
        return "無效的輸入值";
      case "invalid_element":
        return `${n.origin} 中有無效的值`;
      default:
        return "無效的輸入值";
    }
  };
};
function Ab() {
  return { localeError: rI() };
}
var tI = () => {
  let r = {
    string: { unit: "àmi", verb: "ní" },
    file: { unit: "bytes", verb: "ní" },
    array: { unit: "nkan", verb: "ní" },
    set: { unit: "nkan", verb: "ní" }
  };
  function t(n) {
    return r[n] ?? null;
  }
  let i = (n) => {
      let e = typeof n;
      switch (e) {
        case "number":
          return Number.isNaN(n) ? "NaN" : "nọ́mbà";
        case "object":{
            if (Array.isArray(n)) return "akopọ";
            if (n === null) return "null";
            if (Object.getPrototypeOf(n) !== Object.prototype && n.constructor)
            return n.constructor.name;
          }
      }
      return e;
    },
    o = {
      regex: "ẹ̀rọ ìbáwọlé",
      email: "àdírẹ́sì ìmẹ́lì",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "àkókò ISO",
      date: "ọjọ́ ISO",
      time: "àkókò ISO",
      duration: "àkókò tó pé ISO",
      ipv4: "àdírẹ́sì IPv4",
      ipv6: "àdírẹ́sì IPv6",
      cidrv4: "àgbègbè IPv4",
      cidrv6: "àgbègbè IPv6",
      base64: "ọ̀rọ̀ tí a kọ́ ní base64",
      base64url: "ọ̀rọ̀ base64url",
      json_string: "ọ̀rọ̀ JSON",
      e164: "nọ́mbà E.164",
      jwt: "JWT",
      template_literal: "ẹ̀rọ ìbáwọlé"
    };
  return (n) => {
    switch (n.code) {
      case "invalid_type":
        return `Ìbáwọlé aṣìṣe: a ní láti fi ${n.expected}, àmọ̀ a rí ${i(n.input)}`;
      case "invalid_value":
        if (n.values.length === 1)
        return `Ìbáwọlé aṣìṣe: a ní láti fi ${z(n.values[0])}`;
        return `Àṣàyàn aṣìṣe: yan ọ̀kan lára ${x(n.values, "|")}`;
      case "too_big":{
          let e = n.inclusive ? "<=" : "<",
            l = t(n.origin);
          if (l)
          return `Tó pọ̀ jù: a ní láti jẹ́ pé ${n.origin ?? "iye"} ${l.verb} ${e}${n.maximum} ${l.unit}`;
          return `Tó pọ̀ jù: a ní láti jẹ́ ${e}${n.maximum}`;
        }
      case "too_small":{
          let e = n.inclusive ? ">=" : ">",
            l = t(n.origin);
          if (l)
          return `Kéré ju: a ní láti jẹ́ pé ${n.origin} ${l.verb} ${e}${n.minimum} ${l.unit}`;
          return `Kéré ju: a ní láti jẹ́ ${e}${n.minimum}`;
        }
      case "invalid_format":{
          let e = n;
          if (e.format === "starts_with")
          return `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bẹ̀rẹ̀ pẹ̀lú "${e.prefix}"`;
          if (e.format === "ends_with")
          return `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ parí pẹ̀lú "${e.suffix}"`;
          if (e.format === "includes")
          return `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ ní "${e.includes}"`;
          if (e.format === "regex")
          return `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bá àpẹẹrẹ mu ${e.pattern}`;
          return `Aṣìṣe: ${o[e.format] ?? n.format}`;
        }
      case "not_multiple_of":
        return `Nọ́mbà aṣìṣe: gbọ́dọ̀ jẹ́ èyà pípín ti ${n.divisor}`;
      case "unrecognized_keys":
        return `Bọtìnì àìmọ̀: ${x(n.keys, ", ")}`;
      case "invalid_key":
        return `Bọtìnì aṣìṣe nínú ${n.origin}`;
      case "invalid_union":
        return "Ìbáwọlé aṣìṣe";
      case "invalid_element":
        return `Iye aṣìṣe nínú ${n.origin}`;
      default:
        return "Ìbáwọlé aṣìṣe";
    }
  };
};
function Hb() {
  return { localeError: tI() };
}
var Rb = Symbol("ZodOutput"),
  Mb = Symbol("ZodInput");
class mi {
  constructor() {
    this._map = new WeakMap(), this._idmap = new Map();
  }
  add(r, ...t) {
    let i = t[0];
    if (this._map.set(r, i), i && typeof i === "object" && "id" in i) {
      if (this._idmap.has(i.id))
      throw new Error(`ID ${i.id} already exists in the registry`);
      this._idmap.set(i.id, r);
    }
    return this;
  }
  clear() {
    return this._map = new WeakMap(), this._idmap = new Map(), this;
  }
  remove(r) {
    let t = this._map.get(r);
    if (t && typeof t === "object" && "id" in t) this._idmap.delete(t.id);
    return this._map.delete(r), this;
  }
  get(r) {
    let t = r._zod.parent;
    if (t) {
      let i = { ...(this.get(t) ?? {}) };
      delete i.id;
      let o = { ...i, ...this._map.get(r) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(r);
  }
  has(r) {
    return this._map.has(r);
  }
}
function No() {
  return new mi();
}
var Tr = No();
function Zb(r, t) {
  return new r({ type: "string", ...a(t) });
}
function Cb(r, t) {
  return new r({ type: "string", coerce: !0, ...a(t) });
}
function Bo(r, t) {
  return new r({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function bi(r, t) {
  return new r({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function yo(r, t) {
  return new r({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function Ao(r, t) {
  return new r({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...a(t)
  });
}
function Ho(r, t) {
  return new r({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...a(t)
  });
}
function Ro(r, t) {
  return new r({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...a(t)
  });
}
function vi(r, t) {
  return new r({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function Mo(r, t) {
  return new r({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function Zo(r, t) {
  return new r({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function Co(r, t) {
  return new r({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function To(r, t) {
  return new r({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function so(r, t) {
  return new r({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function re(r, t) {
  return new r({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function te(r, t) {
  return new r({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ne(r, t) {
  return new r({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ie(r, t) {
  return new r({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function oe(r, t) {
  return new r({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ee(r, t) {
  return new r({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function le(r, t) {
  return new r({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ce(r, t) {
  return new r({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ue(r, t) {
  return new r({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
function ge(r, t) {
  return new r({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...a(t)
  });
}
var Tb = { Any: null, Minute: -1, Second: 0, Millisecond: 3, Microsecond: 6 };
function db(r, t) {
  return new r({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...a(t)
  });
}
function sb(r, t) {
  return new r({
    type: "string",
    format: "date",
    check: "string_format",
    ...a(t)
  });
}
function rv(r, t) {
  return new r({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...a(t)
  });
}
function tv(r, t) {
  return new r({
    type: "string",
    format: "duration",
    check: "string_format",
    ...a(t)
  });
}
function nv(r, t) {
  return new r({ type: "number", checks: [], ...a(t) });
}
function iv(r, t) {
  return new r({ type: "number", coerce: !0, checks: [], ...a(t) });
}
function ov(r, t) {
  return new r({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...a(t)
  });
}
function ev(r, t) {
  return new r({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...a(t)
  });
}
function lv(r, t) {
  return new r({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...a(t)
  });
}
function cv(r, t) {
  return new r({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...a(t)
  });
}
function uv(r, t) {
  return new r({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...a(t)
  });
}
function gv(r, t) {
  return new r({ type: "boolean", ...a(t) });
}
function mv(r, t) {
  return new r({ type: "boolean", coerce: !0, ...a(t) });
}
function bv(r, t) {
  return new r({ type: "bigint", ...a(t) });
}
function vv(r, t) {
  return new r({ type: "bigint", coerce: !0, ...a(t) });
}
function hv(r, t) {
  return new r({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...a(t)
  });
}
function $v(r, t) {
  return new r({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...a(t)
  });
}
function xv(r, t) {
  return new r({ type: "symbol", ...a(t) });
}
function fv(r, t) {
  return new r({ type: "undefined", ...a(t) });
}
function wv(r, t) {
  return new r({ type: "null", ...a(t) });
}
function zv(r) {
  return new r({ type: "any" });
}
function av(r) {
  return new r({ type: "unknown" });
}
function pv(r, t) {
  return new r({ type: "never", ...a(t) });
}
function _v(r, t) {
  return new r({ type: "void", ...a(t) });
}
function Dv(r, t) {
  return new r({ type: "date", ...a(t) });
}
function jv(r, t) {
  return new r({ type: "date", coerce: !0, ...a(t) });
}
function Ov(r, t) {
  return new r({ type: "nan", ...a(t) });
}
function et(r, t) {
  return new Xo({ check: "less_than", ...a(t), value: r, inclusive: !1 });
}
function Er(r, t) {
  return new Xo({ check: "less_than", ...a(t), value: r, inclusive: !0 });
}
function lt(r, t) {
  return new qo({ check: "greater_than", ...a(t), value: r, inclusive: !1 });
}
function kr(r, t) {
  return new qo({ check: "greater_than", ...a(t), value: r, inclusive: !0 });
}
function Iv(r) {
  return lt(0, r);
}
function kv(r) {
  return et(0, r);
}
function Uv(r) {
  return Er(0, r);
}
function Jv(r) {
  return kr(0, r);
}
function Kt(r, t) {
  return new qg({ check: "multiple_of", ...a(t), value: r });
}
function bn(r, t) {
  return new Lg({ check: "max_size", ...a(t), maximum: r });
}
function Lt(r, t) {
  return new Vg({ check: "min_size", ...a(t), minimum: r });
}
function hi(r, t) {
  return new Yg({ check: "size_equals", ...a(t), size: r });
}
function vn(r, t) {
  return new Eg({ check: "max_length", ...a(t), maximum: r });
}
function _t(r, t) {
  return new Qg({ check: "min_length", ...a(t), minimum: r });
}
function hn(r, t) {
  return new Fg({ check: "length_equals", ...a(t), length: r });
}
function $i(r, t) {
  return new Sg({
    check: "string_format",
    format: "regex",
    ...a(t),
    pattern: r
  });
}
function xi(r) {
  return new Gg({ check: "string_format", format: "lowercase", ...a(r) });
}
function fi(r) {
  return new Ng({ check: "string_format", format: "uppercase", ...a(r) });
}
function wi(r, t) {
  return new Bg({
    check: "string_format",
    format: "includes",
    ...a(t),
    includes: r
  });
}
function zi(r, t) {
  return new yg({
    check: "string_format",
    format: "starts_with",
    ...a(t),
    prefix: r
  });
}
function ai(r, t) {
  return new Ag({
    check: "string_format",
    format: "ends_with",
    ...a(t),
    suffix: r
  });
}
function Pv(r, t, i) {
  return new Hg({ check: "property", property: r, schema: t, ...a(i) });
}
function pi(r, t) {
  return new Rg({ check: "mime_type", mime: r, ...a(t) });
}
function ct(r) {
  return new Mg({ check: "overwrite", tx: r });
}
function _i(r) {
  return ct((t) => t.normalize(r));
}
function Di() {
  return ct((r) => r.trim());
}
function ji() {
  return ct((r) => r.toLowerCase());
}
function Oi() {
  return ct((r) => r.toUpperCase());
}
function Xv(r, t, i) {
  return new r({ type: "array", element: t, ...a(i) });
}
function nI(r, t, i) {
  return new r({ type: "union", options: t, ...a(i) });
}
function iI(r, t, i, o) {
  return new r({ type: "union", options: i, discriminator: t, ...a(o) });
}
function oI(r, t, i) {
  return new r({ type: "intersection", left: t, right: i });
}
function eI(r, t, i, o) {
  let n = i instanceof L;
  return new r({
    type: "tuple",
    items: t,
    rest: n ? i : null,
    ...a(n ? o : i)
  });
}
function lI(r, t, i, o) {
  return new r({ type: "record", keyType: t, valueType: i, ...a(o) });
}
function cI(r, t, i, o) {
  return new r({ type: "map", keyType: t, valueType: i, ...a(o) });
}
function uI(r, t, i) {
  return new r({ type: "set", valueType: t, ...a(i) });
}
function gI(r, t, i) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((n) => [n, n])) : t;
  return new r({ type: "enum", entries: o, ...a(i) });
}
function mI(r, t, i) {
  return new r({ type: "enum", entries: t, ...a(i) });
}
function bI(r, t, i) {
  return new r({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...a(i)
  });
}
function qv(r, t) {
  return new r({ type: "file", ...a(t) });
}
function vI(r, t) {
  return new r({ type: "transform", transform: t });
}
function hI(r, t) {
  return new r({ type: "optional", innerType: t });
}
function $I(r, t) {
  return new r({ type: "nullable", innerType: t });
}
function xI(r, t, i) {
  return new r({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof i === "function" ? i() : Ru(i);
    }
  });
}
function fI(r, t, i) {
  return new r({ type: "nonoptional", innerType: t, ...a(i) });
}
function wI(r, t) {
  return new r({ type: "success", innerType: t });
}
function zI(r, t, i) {
  return new r({
    type: "catch",
    innerType: t,
    catchValue: typeof i === "function" ? i : () => i
  });
}
function aI(r, t, i) {
  return new r({ type: "pipe", in: t, out: i });
}
function pI(r, t) {
  return new r({ type: "readonly", innerType: t });
}
function _I(r, t, i) {
  return new r({ type: "template_literal", parts: t, ...a(i) });
}
function DI(r, t) {
  return new r({ type: "lazy", getter: t });
}
function jI(r, t) {
  return new r({ type: "promise", innerType: t });
}
function Wv(r, t, i) {
  let o = a(i);
  return (
    o.abort ?? (o.abort = !0),
    new r({ type: "custom", check: "custom", fn: t, ...o }));

}
function Kv(r, t, i) {
  return new r({ type: "custom", check: "custom", fn: t, ...a(i) });
}
function Lv(r) {
  let t = Uw((i) => {
    return (
      i.addIssue = (o) => {
        if (typeof o === "string") i.issues.push(en(o, i.value, t._zod.def));else
        {
          let n = o;
          if (n.fatal) n.continue = !1;
          n.code ?? (n.code = "custom"),
          n.input ?? (n.input = i.value),
          n.inst ?? (n.inst = t),
          n.continue ?? (n.continue = !t._zod.def.abort),
          i.issues.push(en(n));
        }
      },
      r(i.value, i));

  });
  return t;
}
function Uw(r, t) {
  let i = new s({ check: "custom", ...a(t) });
  return i._zod.check = r, i;
}
function Vv(r, t) {
  let i = a(t),
    o = i.truthy ?? ["true", "1", "yes", "on", "y", "enabled"],
    n = i.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  if (i.case !== "sensitive")
  o = o.map((b) => typeof b === "string" ? b.toLowerCase() : b),
  n = n.map((b) => typeof b === "string" ? b.toLowerCase() : b);
  let e = new Set(o),
    l = new Set(n),
    u = r.Codec ?? ii,
    g = r.Boolean ?? ni,
    m = new (r.String ?? Wt)({ type: "string", error: i.error }),
    v = new g({ type: "boolean", error: i.error }),
    h = new u({
      type: "pipe",
      in: m,
      out: v,
      transform: (b, f) => {
        let D = b;
        if (i.case !== "sensitive") D = D.toLowerCase();
        if (e.has(D)) return !0;else
        if (l.has(D)) return !1;else

        return (
          f.issues.push({
            code: "invalid_value",
            expected: "stringbool",
            values: [...e, ...l],
            input: f.value,
            inst: h,
            continue: !1
          }),
          {});

      },
      reverseTransform: (b, f) => {
        if (b === !0) return o[0] || "true";else
        return n[0] || "false";
      },
      error: i.error
    });
  return h;
}
function $n(r, t, i, o = {}) {
  let n = a(o),
    e = {
      ...a(o),
      check: "string_format",
      type: "string",
      format: t,
      fn: typeof i === "function" ? i : (u) => i.test(u),
      ...n
    };
  if (i instanceof RegExp) e.pattern = i;
  return new r(e);
}
class me {
  constructor(r) {
    this.counter = 0,
    this.metadataRegistry = r?.metadata ?? Tr,
    this.target = r?.target ?? "draft-2020-12",
    this.unrepresentable = r?.unrepresentable ?? "throw",
    this.override = r?.override ?? (() => {}),
    this.io = r?.io ?? "output",
    this.seen = new Map();
  }
  process(r, t = { path: [], schemaPath: [] }) {
    var i;
    let o = r._zod.def,
      n = {
        guid: "uuid",
        url: "uri",
        datetime: "date-time",
        json_string: "json-string",
        regex: ""
      },
      e = this.seen.get(r);
    if (e) {
      if (e.count++, t.schemaPath.includes(r)) e.cycle = t.path;
      return e.schema;
    }
    let l = { schema: {}, count: 1, cycle: void 0, path: t.path };
    this.seen.set(r, l);
    let u = r._zod.toJSONSchema?.();
    if (u) l.schema = u;else
    {
      let m = { ...t, schemaPath: [...t.schemaPath, r], path: t.path },
        v = r._zod.parent;
      if (v)
      l.ref = v, this.process(v, m), this.seen.get(v).isParent = !0;else
      {
        let h = l.schema;
        switch (o.type) {
          case "string":{
              let b = h;
              b.type = "string";
              let {
                minimum: f,
                maximum: D,
                format: O,
                patterns: _,
                contentEncoding: J
              } = r._zod.bag;
              if (typeof f === "number") b.minLength = f;
              if (typeof D === "number") b.maxLength = D;
              if (O) {
                if (b.format = n[O] ?? O, b.format === "") delete b.format;
              }
              if (J) b.contentEncoding = J;
              if (_ && _.size > 0) {
                let V = [..._];
                if (V.length === 1) b.pattern = V[0].source;else
                if (V.length > 1)
                l.schema.allOf = [
                ...V.map((X) => ({
                  ...(this.target === "draft-7" ||
                  this.target === "draft-4" ||
                  this.target === "openapi-3.0" ?
                  { type: "string" } :
                  {}),
                  pattern: X.source
                }))];

              }
              break;
            }
          case "number":{
              let b = h,
                {
                  minimum: f,
                  maximum: D,
                  format: O,
                  multipleOf: _,
                  exclusiveMaximum: J,
                  exclusiveMinimum: V
                } = r._zod.bag;
              if (typeof O === "string" && O.includes("int")) b.type = "integer";else
              b.type = "number";
              if (typeof V === "number")
              if (this.target === "draft-4" || this.target === "openapi-3.0")
              b.minimum = V, b.exclusiveMinimum = !0;else
              b.exclusiveMinimum = V;
              if (typeof f === "number") {
                if (
                b.minimum = f,
                typeof V === "number" && this.target !== "draft-4")

                if (V >= f) delete b.minimum;else
                delete b.exclusiveMinimum;
              }
              if (typeof J === "number")
              if (this.target === "draft-4" || this.target === "openapi-3.0")
              b.maximum = J, b.exclusiveMaximum = !0;else
              b.exclusiveMaximum = J;
              if (typeof D === "number") {
                if (
                b.maximum = D,
                typeof J === "number" && this.target !== "draft-4")

                if (J <= D) delete b.maximum;else
                delete b.exclusiveMaximum;
              }
              if (typeof _ === "number") b.multipleOf = _;
              break;
            }
          case "boolean":{
              let b = h;
              b.type = "boolean";
              break;
            }
          case "bigint":{
              if (this.unrepresentable === "throw")
              throw new Error("BigInt cannot be represented in JSON Schema");
              break;
            }
          case "symbol":{
              if (this.unrepresentable === "throw")
              throw new Error("Symbols cannot be represented in JSON Schema");
              break;
            }
          case "null":{
              if (this.target === "openapi-3.0")
              h.type = "string", h.nullable = !0, h.enum = [null];else
              h.type = "null";
              break;
            }
          case "any":
            break;
          case "unknown":
            break;
          case "undefined":{
              if (this.unrepresentable === "throw")
              throw new Error("Undefined cannot be represented in JSON Schema");
              break;
            }
          case "void":{
              if (this.unrepresentable === "throw")
              throw new Error("Void cannot be represented in JSON Schema");
              break;
            }
          case "never":{
              h.not = {};
              break;
            }
          case "date":{
              if (this.unrepresentable === "throw")
              throw new Error("Date cannot be represented in JSON Schema");
              break;
            }
          case "array":{
              let b = h,
                { minimum: f, maximum: D } = r._zod.bag;
              if (typeof f === "number") b.minItems = f;
              if (typeof D === "number") b.maxItems = D;
              b.type = "array",
              b.items = this.process(o.element, {
                ...m,
                path: [...m.path, "items"]
              });
              break;
            }
          case "object":{
              let b = h;
              b.type = "object", b.properties = {};
              let f = o.shape;
              for (let _ in f)
              b.properties[_] = this.process(f[_], {
                ...m,
                path: [...m.path, "properties", _]
              });
              let D = new Set(Object.keys(f)),
                O = new Set(
                  [...D].filter((_) => {
                    let J = o.shape[_]._zod;
                    if (this.io === "input") return J.optin === void 0;else
                    return J.optout === void 0;
                  })
                );
              if (O.size > 0) b.required = Array.from(O);
              if (o.catchall?._zod.def.type === "never")
              b.additionalProperties = !1;else
              if (!o.catchall) {
                if (this.io === "output") b.additionalProperties = !1;
              } else if (o.catchall)
              b.additionalProperties = this.process(o.catchall, {
                ...m,
                path: [...m.path, "additionalProperties"]
              });
              break;
            }
          case "union":{
              let b = h,
                f = o.options.map((D, O) =>
                this.process(D, { ...m, path: [...m.path, "anyOf", O] })
                );
              b.anyOf = f;
              break;
            }
          case "intersection":{
              let b = h,
                f = this.process(o.left, { ...m, path: [...m.path, "allOf", 0] }),
                D = this.process(o.right, {
                  ...m,
                  path: [...m.path, "allOf", 1]
                }),
                O = (J) => "allOf" in J && Object.keys(J).length === 1,
                _ = [...(O(f) ? f.allOf : [f]), ...(O(D) ? D.allOf : [D])];
              b.allOf = _;
              break;
            }
          case "tuple":{
              let b = h;
              b.type = "array";
              let f = this.target === "draft-2020-12" ? "prefixItems" : "items",
                D =
                this.target === "draft-2020-12" ?
                "items" :
                this.target === "openapi-3.0" ?
                "items" :
                "additionalItems",
                O = o.items.map((X, W) =>
                this.process(X, { ...m, path: [...m.path, f, W] })
                ),
                _ = o.rest ?
                this.process(o.rest, {
                  ...m,
                  path: [
                  ...m.path,
                  D,
                  ...(this.target === "openapi-3.0" ?
                  [o.items.length] :
                  [])]

                }) :
                null;
              if (this.target === "draft-2020-12") {
                if (b.prefixItems = O, _) b.items = _;
              } else if (this.target === "openapi-3.0") {
                if (b.items = { anyOf: O }, _) b.items.anyOf.push(_);
                if (b.minItems = O.length, !_) b.maxItems = O.length;
              } else if (b.items = O, _) b.additionalItems = _;
              let { minimum: J, maximum: V } = r._zod.bag;
              if (typeof J === "number") b.minItems = J;
              if (typeof V === "number") b.maxItems = V;
              break;
            }
          case "record":{
              let b = h;
              if (
              b.type = "object",
              this.target === "draft-7" || this.target === "draft-2020-12")

              b.propertyNames = this.process(o.keyType, {
                ...m,
                path: [...m.path, "propertyNames"]
              });
              b.additionalProperties = this.process(o.valueType, {
                ...m,
                path: [...m.path, "additionalProperties"]
              });
              break;
            }
          case "map":{
              if (this.unrepresentable === "throw")
              throw new Error("Map cannot be represented in JSON Schema");
              break;
            }
          case "set":{
              if (this.unrepresentable === "throw")
              throw new Error("Set cannot be represented in JSON Schema");
              break;
            }
          case "enum":{
              let b = h,
                f = Hn(o.entries);
              if (f.every((D) => typeof D === "number")) b.type = "number";
              if (f.every((D) => typeof D === "string")) b.type = "string";
              b.enum = f;
              break;
            }
          case "literal":{
              let b = h,
                f = [];
              for (let D of o.values)
              if (D === void 0) {
                if (this.unrepresentable === "throw")
                throw new Error(
                  "Literal `undefined` cannot be represented in JSON Schema"
                );
              } else if (typeof D === "bigint") {
                if (this.unrepresentable === "throw")
                throw new Error(
                  "BigInt literals cannot be represented in JSON Schema"
                );else
                f.push(Number(D));
              } else f.push(D);
              if (f.length === 0) ;else
              if (f.length === 1) {
                let D = f[0];
                if (
                b.type = D === null ? "null" : typeof D,
                this.target === "draft-4" || this.target === "openapi-3.0")

                b.enum = [D];else
                b.const = D;
              } else {
                if (f.every((D) => typeof D === "number")) b.type = "number";
                if (f.every((D) => typeof D === "string")) b.type = "string";
                if (f.every((D) => typeof D === "boolean")) b.type = "string";
                if (f.every((D) => D === null)) b.type = "null";
                b.enum = f;
              }
              break;
            }
          case "file":{
              let b = h,
                f = {
                  type: "string",
                  format: "binary",
                  contentEncoding: "binary"
                },
                { minimum: D, maximum: O, mime: _ } = r._zod.bag;
              if (D !== void 0) f.minLength = D;
              if (O !== void 0) f.maxLength = O;
              if (_) {
                if (_.length === 1)
                f.contentMediaType = _[0], Object.assign(b, f);else

                b.anyOf = _.map((J) => {
                  return { ...f, contentMediaType: J };
                });
              } else Object.assign(b, f);
              break;
            }
          case "transform":{
              if (this.unrepresentable === "throw")
              throw new Error(
                "Transforms cannot be represented in JSON Schema"
              );
              break;
            }
          case "nullable":{
              let b = this.process(o.innerType, m);
              if (this.target === "openapi-3.0")
              l.ref = o.innerType, h.nullable = !0;else
              h.anyOf = [b, { type: "null" }];
              break;
            }
          case "nonoptional":{
              this.process(o.innerType, m), l.ref = o.innerType;
              break;
            }
          case "success":{
              let b = h;
              b.type = "boolean";
              break;
            }
          case "default":{
              this.process(o.innerType, m),
              l.ref = o.innerType,
              h.default = JSON.parse(JSON.stringify(o.defaultValue));
              break;
            }
          case "prefault":{
              if (
              this.process(o.innerType, m),
              l.ref = o.innerType,
              this.io === "input")

              h._prefault = JSON.parse(JSON.stringify(o.defaultValue));
              break;
            }
          case "catch":{
              this.process(o.innerType, m), l.ref = o.innerType;
              let b;
              try {
                b = o.catchValue(void 0);
              } catch {
                throw new Error(
                  "Dynamic catch values are not supported in JSON Schema"
                );
              }
              h.default = b;
              break;
            }
          case "nan":{
              if (this.unrepresentable === "throw")
              throw new Error("NaN cannot be represented in JSON Schema");
              break;
            }
          case "template_literal":{
              let b = h,
                f = r._zod.pattern;
              if (!f) throw new Error("Pattern not found in template literal");
              b.type = "string", b.pattern = f.source;
              break;
            }
          case "pipe":{
              let b =
              this.io === "input" ?
              o.in._zod.def.type === "transform" ?
              o.out :
              o.in :
              o.out;
              this.process(b, m), l.ref = b;
              break;
            }
          case "readonly":{
              this.process(o.innerType, m),
              l.ref = o.innerType,
              h.readOnly = !0;
              break;
            }
          case "promise":{
              this.process(o.innerType, m), l.ref = o.innerType;
              break;
            }
          case "optional":{
              this.process(o.innerType, m), l.ref = o.innerType;
              break;
            }
          case "lazy":{
              let b = r._zod.innerType;
              this.process(b, m), l.ref = b;
              break;
            }
          case "custom":{
              if (this.unrepresentable === "throw")
              throw new Error(
                "Custom types cannot be represented in JSON Schema"
              );
              break;
            }
          case "function":{
              if (this.unrepresentable === "throw")
              throw new Error(
                "Function types cannot be represented in JSON Schema"
              );
              break;
            }
          default:
        }
      }
    }
    let g = this.metadataRegistry.get(r);
    if (g) Object.assign(l.schema, g);
    if (this.io === "input" && $r(r))
    delete l.schema.examples, delete l.schema.default;
    if (this.io === "input" && l.schema._prefault)
    (i = l.schema).default ?? (i.default = l.schema._prefault);
    return delete l.schema._prefault, this.seen.get(r).schema;
  }
  emit(r, t) {
    let i = {
        cycles: t?.cycles ?? "ref",
        reused: t?.reused ?? "inline",
        external: t?.external ?? void 0
      },
      o = this.seen.get(r);
    if (!o) throw new Error("Unprocessed schema. This is a bug in Zod.");
    let n = (c) => {
        let m = this.target === "draft-2020-12" ? "$defs" : "definitions";
        if (i.external) {
          let f = i.external.registry.get(c[0])?.id,
            D = i.external.uri ?? ((_) => _);
          if (f) return { ref: D(f) };
          let O = c[1].defId ?? c[1].schema.id ?? `schema${this.counter++}`;
          return (
            c[1].defId = O,
            { defId: O, ref: `${D("__shared")}#/${m}/${O}` });

        }
        if (c[1] === o) return { ref: "#" };
        let h = `${"#"}/${m}/`,
          b = c[1].schema.id ?? `__schema${this.counter++}`;
        return { defId: b, ref: h + b };
      },
      e = (c) => {
        if (c[1].schema.$ref) return;
        let m = c[1],
          { ref: v, defId: h } = n(c);
        if (m.def = { ...m.schema }, h) m.defId = h;
        let b = m.schema;
        for (let f in b) delete b[f];
        b.$ref = v;
      };
    if (i.cycles === "throw")
    for (let c of this.seen.entries()) {
      let m = c[1];
      if (m.cycle)
      throw new Error(`Cycle detected: #/${m.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
    for (let c of this.seen.entries()) {
      let m = c[1];
      if (r === c[0]) {
        e(c);
        continue;
      }
      if (i.external) {
        let h = i.external.registry.get(c[0])?.id;
        if (r !== c[0] && h) {
          e(c);
          continue;
        }
      }
      if (this.metadataRegistry.get(c[0])?.id) {
        e(c);
        continue;
      }
      if (m.cycle) {
        e(c);
        continue;
      }
      if (m.count > 1) {
        if (i.reused === "ref") {
          e(c);
          continue;
        }
      }
    }
    let l = (c, m) => {
      let v = this.seen.get(c),
        h = v.def ?? v.schema,
        b = { ...h };
      if (v.ref === null) return;
      let f = v.ref;
      if (v.ref = null, f) {
        l(f, m);
        let D = this.seen.get(f).schema;
        if (
        D.$ref && (
        m.target === "draft-7" ||
        m.target === "draft-4" ||
        m.target === "openapi-3.0"))

        h.allOf = h.allOf ?? [], h.allOf.push(D);else
        Object.assign(h, D), Object.assign(h, b);
      }
      if (!v.isParent)
      this.override({ zodSchema: c, jsonSchema: h, path: v.path ?? [] });
    };
    for (let c of [...this.seen.entries()].reverse())
    l(c[0], { target: this.target });
    let u = {};
    if (this.target === "draft-2020-12")
    u.$schema = "https://json-schema.org/draft/2020-12/schema";else
    if (this.target === "draft-7")
    u.$schema = "http://json-schema.org/draft-07/schema#";else
    if (this.target === "draft-4")
    u.$schema = "http://json-schema.org/draft-04/schema#";else
    if (this.target === "openapi-3.0") ;else
    console.warn(`Invalid target: ${this.target}`);
    if (i.external?.uri) {
      let c = i.external.registry.get(r)?.id;
      if (!c) throw new Error("Schema is missing an `id` property");
      u.$id = i.external.uri(c);
    }
    Object.assign(u, o.def);
    let g = i.external?.defs ?? {};
    for (let c of this.seen.entries()) {
      let m = c[1];
      if (m.def && m.defId) g[m.defId] = m.def;
    }
    if (i.external) ;else
    if (Object.keys(g).length > 0)
    if (this.target === "draft-2020-12") u.$defs = g;else
    u.definitions = g;
    try {
      return JSON.parse(JSON.stringify(u));
    } catch (c) {
      throw new Error("Error converting schema to JSON.");
    }
  }
}
function Yv(r, t) {
  if (r instanceof mi) {
    let o = new me(t),
      n = {};
    for (let u of r._idmap.entries()) {
      let [g, c] = u;
      o.process(c);
    }
    let e = {},
      l = { registry: r, uri: t?.uri, defs: n };
    for (let u of r._idmap.entries()) {
      let [g, c] = u;
      e[g] = o.emit(c, { ...t, external: l });
    }
    if (Object.keys(n).length > 0) {
      let u = o.target === "draft-2020-12" ? "$defs" : "definitions";
      e.__shared = { [u]: n };
    }
    return { schemas: e };
  }
  let i = new me(t);
  return i.process(r), i.emit(r, t);
}
function $r(r, t) {
  let i = t ?? { seen: new Set() };
  if (i.seen.has(r)) return !1;
  i.seen.add(r);
  let n = r._zod.def;
  switch (n.type) {
    case "string":
    case "number":
    case "bigint":
    case "boolean":
    case "date":
    case "symbol":
    case "undefined":
    case "null":
    case "any":
    case "unknown":
    case "never":
    case "void":
    case "literal":
    case "enum":
    case "nan":
    case "file":
    case "template_literal":
      return !1;
    case "array":
      return $r(n.element, i);
    case "object":{
        for (let e in n.shape) if ($r(n.shape[e], i)) return !0;
        return !1;
      }
    case "union":{
        for (let e of n.options) if ($r(e, i)) return !0;
        return !1;
      }
    case "intersection":
      return $r(n.left, i) || $r(n.right, i);
    case "tuple":{
        for (let e of n.items) if ($r(e, i)) return !0;
        if (n.rest && $r(n.rest, i)) return !0;
        return !1;
      }
    case "record":
      return $r(n.keyType, i) || $r(n.valueType, i);
    case "map":
      return $r(n.keyType, i) || $r(n.valueType, i);
    case "set":
      return $r(n.valueType, i);
    case "promise":
    case "optional":
    case "nonoptional":
    case "nullable":
    case "readonly":
      return $r(n.innerType, i);
    case "lazy":
      return $r(n.getter(), i);
    case "default":
      return $r(n.innerType, i);
    case "prefault":
      return $r(n.innerType, i);
    case "custom":
      return !1;
    case "transform":
      return !0;
    case "pipe":
      return $r(n.in, i) || $r(n.out, i);
    case "success":
      return !1;
    case "catch":
      return !1;
    case "function":
      return !1;
    default:
  }
  throw new Error(`Unknown schema type: ${n.type}`);
}
var Jw = {};
var xe = {};
I(xe, {
  time: () => Fv,
  duration: () => Sv,
  datetime: () => Ev,
  date: () => Qv,
  ZodISOTime: () => he,
  ZodISODuration: () => $e,
  ZodISODateTime: () => be,
  ZodISODate: () => ve
});
var be = $("ZodISODateTime", (r, t) => {
  um.init(r, t), T.init(r, t);
});
function Ev(r) {
  return db(be, r);
}
var ve = $("ZodISODate", (r, t) => {
  gm.init(r, t), T.init(r, t);
});
function Qv(r) {
  return sb(ve, r);
}
var he = $("ZodISOTime", (r, t) => {
  mm.init(r, t), T.init(r, t);
});
function Fv(r) {
  return rv(he, r);
}
var $e = $("ZodISODuration", (r, t) => {
  bm.init(r, t), T.init(r, t);
});
function Sv(r) {
  return tv($e, r);
}
var Xw = (r, t) => {
    Tn.init(r, t),
    r.name = "ZodError",
    Object.defineProperties(r, {
      format: { value: (i) => sn(r, i) },
      flatten: { value: (i) => dn(r, i) },
      addIssue: {
        value: (i) => {
          r.issues.push(i), r.message = JSON.stringify(r.issues, nn, 2);
        }
      },
      addIssues: {
        value: (i) => {
          r.issues.push(...i),
          r.message = JSON.stringify(r.issues, nn, 2);
        }
      },
      isEmpty: {
        get() {
          return r.issues.length === 0;
        }
      }
    });
  },
  II = $("ZodError", Xw),
  Ur = $("ZodError", Xw, { Parent: Error });
var Gv = ln(Ur),
  Nv = cn(Ur),
  Bv = un(Ur),
  yv = gn(Ur),
  Av = _o(Ur),
  Hv = Do(Ur),
  Rv = jo(Ur),
  Mv = Oo(Ur),
  Zv = Io(Ur),
  Cv = ko(Ur),
  Tv = Uo(Ur),
  dv = Jo(Ur);
var E = $("ZodType", (r, t) => {
    return (
      L.init(r, t),
      r.def = t,
      r.type = t.type,
      Object.defineProperty(r, "_def", { value: t }),
      r.check = (...i) => {
        return r.clone(
          p.mergeDefs(t, {
            checks: [
            ...(t.checks ?? []),
            ...i.map((o) =>
            typeof o === "function" ?
            {
              _zod: {
                check: o,
                def: { check: "custom" },
                onattach: []
              }
            } :
            o
            )]

          })
        );
      },
      r.clone = (i, o) => jr(r, i, o),
      r.brand = () => r,
      r.register = (i, o) => {
        return i.add(r, o), r;
      },
      r.parse = (i, o) => Gv(r, i, o, { callee: r.parse }),
      r.safeParse = (i, o) => Bv(r, i, o),
      r.parseAsync = async (i, o) => Nv(r, i, o, { callee: r.parseAsync }),
      r.safeParseAsync = async (i, o) => yv(r, i, o),
      r.spa = r.safeParseAsync,
      r.encode = (i, o) => Av(r, i, o),
      r.decode = (i, o) => Hv(r, i, o),
      r.encodeAsync = async (i, o) => Rv(r, i, o),
      r.decodeAsync = async (i, o) => Mv(r, i, o),
      r.safeEncode = (i, o) => Zv(r, i, o),
      r.safeDecode = (i, o) => Cv(r, i, o),
      r.safeEncodeAsync = async (i, o) => Tv(r, i, o),
      r.safeDecodeAsync = async (i, o) => dv(r, i, o),
      r.refine = (i, o) => r.check(f4(i, o)),
      r.superRefine = (i) => r.check(w4(i)),
      r.overwrite = (i) => r.check(ct(i)),
      r.optional = () => we(r),
      r.nullable = () => ze(r),
      r.nullish = () => we(ze(r)),
      r.nonoptional = (i) => o4(r, i),
      r.array = () => De(r),
      r.or = (i) => _h([r, i]),
      r.and = (i) => yw(r, i),
      r.transform = (i) => ae(r, Oh(i)),
      r.default = (i) => t4(r, i),
      r.prefault = (i) => i4(r, i),
      r.catch = (i) => c4(r, i),
      r.pipe = (i) => ae(r, i),
      r.readonly = () => m4(r),
      r.describe = (i) => {
        let o = r.clone();
        return Tr.add(o, { description: i }), o;
      },
      Object.defineProperty(r, "description", {
        get() {
          return Tr.get(r)?.description;
        },
        configurable: !0
      }),
      r.meta = (...i) => {
        if (i.length === 0) return Tr.get(r);
        let o = r.clone();
        return Tr.add(o, i[0]), o;
      },
      r.isOptional = () => r.safeParse(void 0).success,
      r.isNullable = () => r.safeParse(null).success,
      r);

  }),
  th = $("_ZodString", (r, t) => {
    Wt.init(r, t), E.init(r, t);
    let i = r._zod.bag;
    r.format = i.format ?? null,
    r.minLength = i.minimum ?? null,
    r.maxLength = i.maximum ?? null,
    r.regex = (...o) => r.check($i(...o)),
    r.includes = (...o) => r.check(wi(...o)),
    r.startsWith = (...o) => r.check(zi(...o)),
    r.endsWith = (...o) => r.check(ai(...o)),
    r.min = (...o) => r.check(_t(...o)),
    r.max = (...o) => r.check(vn(...o)),
    r.length = (...o) => r.check(hn(...o)),
    r.nonempty = (...o) => r.check(_t(1, ...o)),
    r.lowercase = (o) => r.check(xi(o)),
    r.uppercase = (o) => r.check(fi(o)),
    r.trim = () => r.check(Di()),
    r.normalize = (...o) => r.check(_i(...o)),
    r.toLowerCase = () => r.check(ji()),
    r.toUpperCase = () => r.check(Oi());
  }),
  ki = $("ZodString", (r, t) => {
    Wt.init(r, t),
    th.init(r, t),
    r.email = (i) => r.check(Bo(nh, i)),
    r.url = (i) => r.check(vi(pe, i)),
    r.jwt = (i) => r.check(ge(wh, i)),
    r.emoji = (i) => r.check(Mo(ih, i)),
    r.guid = (i) => r.check(bi(fe, i)),
    r.uuid = (i) => r.check(yo(gt, i)),
    r.uuidv4 = (i) => r.check(Ao(gt, i)),
    r.uuidv6 = (i) => r.check(Ho(gt, i)),
    r.uuidv7 = (i) => r.check(Ro(gt, i)),
    r.nanoid = (i) => r.check(Zo(oh, i)),
    r.guid = (i) => r.check(bi(fe, i)),
    r.cuid = (i) => r.check(Co(eh, i)),
    r.cuid2 = (i) => r.check(To(lh, i)),
    r.ulid = (i) => r.check(so(ch, i)),
    r.base64 = (i) => r.check(le($h, i)),
    r.base64url = (i) => r.check(ce(xh, i)),
    r.xid = (i) => r.check(re(uh, i)),
    r.ksuid = (i) => r.check(te(gh, i)),
    r.ipv4 = (i) => r.check(ne(mh, i)),
    r.ipv6 = (i) => r.check(ie(bh, i)),
    r.cidrv4 = (i) => r.check(oe(vh, i)),
    r.cidrv6 = (i) => r.check(ee(hh, i)),
    r.e164 = (i) => r.check(ue(fh, i)),
    r.datetime = (i) => r.check(Ev(i)),
    r.date = (i) => r.check(Qv(i)),
    r.time = (i) => r.check(Fv(i)),
    r.duration = (i) => r.check(Sv(i));
  });
function sv(r) {
  return Zb(ki, r);
}
var T = $("ZodStringFormat", (r, t) => {
    M.init(r, t), th.init(r, t);
  }),
  nh = $("ZodEmail", (r, t) => {
    sg.init(r, t), T.init(r, t);
  });
function UI(r) {
  return Bo(nh, r);
}
var fe = $("ZodGUID", (r, t) => {
  Tg.init(r, t), T.init(r, t);
});
function JI(r) {
  return bi(fe, r);
}
var gt = $("ZodUUID", (r, t) => {
  dg.init(r, t), T.init(r, t);
});
function PI(r) {
  return yo(gt, r);
}
function XI(r) {
  return Ao(gt, r);
}
function qI(r) {
  return Ho(gt, r);
}
function WI(r) {
  return Ro(gt, r);
}
var pe = $("ZodURL", (r, t) => {
  rm.init(r, t), T.init(r, t);
});
function KI(r) {
  return vi(pe, r);
}
function LI(r) {
  return vi(pe, {
    protocol: /^https?$/,
    hostname: Yr.domain,
    ...p.normalizeParams(r)
  });
}
var ih = $("ZodEmoji", (r, t) => {
  tm.init(r, t), T.init(r, t);
});
function VI(r) {
  return Mo(ih, r);
}
var oh = $("ZodNanoID", (r, t) => {
  nm.init(r, t), T.init(r, t);
});
function YI(r) {
  return Zo(oh, r);
}
var eh = $("ZodCUID", (r, t) => {
  im.init(r, t), T.init(r, t);
});
function EI(r) {
  return Co(eh, r);
}
var lh = $("ZodCUID2", (r, t) => {
  om.init(r, t), T.init(r, t);
});
function QI(r) {
  return To(lh, r);
}
var ch = $("ZodULID", (r, t) => {
  em.init(r, t), T.init(r, t);
});
function FI(r) {
  return so(ch, r);
}
var uh = $("ZodXID", (r, t) => {
  lm.init(r, t), T.init(r, t);
});
function SI(r) {
  return re(uh, r);
}
var gh = $("ZodKSUID", (r, t) => {
  cm.init(r, t), T.init(r, t);
});
function GI(r) {
  return te(gh, r);
}
var mh = $("ZodIPv4", (r, t) => {
  vm.init(r, t), T.init(r, t);
});
function NI(r) {
  return ne(mh, r);
}
var bh = $("ZodIPv6", (r, t) => {
  hm.init(r, t), T.init(r, t);
});
function BI(r) {
  return ie(bh, r);
}
var vh = $("ZodCIDRv4", (r, t) => {
  $m.init(r, t), T.init(r, t);
});
function yI(r) {
  return oe(vh, r);
}
var hh = $("ZodCIDRv6", (r, t) => {
  xm.init(r, t), T.init(r, t);
});
function AI(r) {
  return ee(hh, r);
}
var $h = $("ZodBase64", (r, t) => {
  wm.init(r, t), T.init(r, t);
});
function HI(r) {
  return le($h, r);
}
var xh = $("ZodBase64URL", (r, t) => {
  zm.init(r, t), T.init(r, t);
});
function RI(r) {
  return ce(xh, r);
}
var fh = $("ZodE164", (r, t) => {
  am.init(r, t), T.init(r, t);
});
function MI(r) {
  return ue(fh, r);
}
var wh = $("ZodJWT", (r, t) => {
  pm.init(r, t), T.init(r, t);
});
function ZI(r) {
  return ge(wh, r);
}
var Ui = $("ZodCustomStringFormat", (r, t) => {
  _m.init(r, t), T.init(r, t);
});
function CI(r, t, i = {}) {
  return $n(Ui, r, t, i);
}
function TI(r) {
  return $n(Ui, "hostname", Yr.hostname, r);
}
function dI(r) {
  return $n(Ui, "hex", Yr.hex, r);
}
function sI(r, t) {
  let i = t?.enc ?? "hex",
    o = `${r}_${i}`,
    n = Yr[o];
  if (!n) throw new Error(`Unrecognized hash format: ${o}`);
  return $n(Ui, o, n, t);
}
var Ji = $("ZodNumber", (r, t) => {
  Qo.init(r, t),
  E.init(r, t),
  r.gt = (o, n) => r.check(lt(o, n)),
  r.gte = (o, n) => r.check(kr(o, n)),
  r.min = (o, n) => r.check(kr(o, n)),
  r.lt = (o, n) => r.check(et(o, n)),
  r.lte = (o, n) => r.check(Er(o, n)),
  r.max = (o, n) => r.check(Er(o, n)),
  r.int = (o) => r.check(rh(o)),
  r.safe = (o) => r.check(rh(o)),
  r.positive = (o) => r.check(lt(0, o)),
  r.nonnegative = (o) => r.check(kr(0, o)),
  r.negative = (o) => r.check(et(0, o)),
  r.nonpositive = (o) => r.check(Er(0, o)),
  r.multipleOf = (o, n) => r.check(Kt(o, n)),
  r.step = (o, n) => r.check(Kt(o, n)),
  r.finite = () => r;
  let i = r._zod.bag;
  r.minValue =
  Math.max(
    i.minimum ?? Number.NEGATIVE_INFINITY,
    i.exclusiveMinimum ?? Number.NEGATIVE_INFINITY
  ) ?? null,
  r.maxValue =
  Math.min(
    i.maximum ?? Number.POSITIVE_INFINITY,
    i.exclusiveMaximum ?? Number.POSITIVE_INFINITY
  ) ?? null,
  r.isInt =
  (i.format ?? "").includes("int") ||
  Number.isSafeInteger(i.multipleOf ?? 0.5),
  r.isFinite = !0,
  r.format = i.format ?? null;
});
function qw(r) {
  return nv(Ji, r);
}
var fn = $("ZodNumberFormat", (r, t) => {
  Dm.init(r, t), Ji.init(r, t);
});
function rh(r) {
  return ov(fn, r);
}
function rk(r) {
  return ev(fn, r);
}
function tk(r) {
  return lv(fn, r);
}
function nk(r) {
  return cv(fn, r);
}
function ik(r) {
  return uv(fn, r);
}
var Pi = $("ZodBoolean", (r, t) => {
  ni.init(r, t), E.init(r, t);
});
function Ww(r) {
  return gv(Pi, r);
}
var Xi = $("ZodBigInt", (r, t) => {
  Fo.init(r, t),
  E.init(r, t),
  r.gte = (o, n) => r.check(kr(o, n)),
  r.min = (o, n) => r.check(kr(o, n)),
  r.gt = (o, n) => r.check(lt(o, n)),
  r.gte = (o, n) => r.check(kr(o, n)),
  r.min = (o, n) => r.check(kr(o, n)),
  r.lt = (o, n) => r.check(et(o, n)),
  r.lte = (o, n) => r.check(Er(o, n)),
  r.max = (o, n) => r.check(Er(o, n)),
  r.positive = (o) => r.check(lt(BigInt(0), o)),
  r.negative = (o) => r.check(et(BigInt(0), o)),
  r.nonpositive = (o) => r.check(Er(BigInt(0), o)),
  r.nonnegative = (o) => r.check(kr(BigInt(0), o)),
  r.multipleOf = (o, n) => r.check(Kt(o, n));
  let i = r._zod.bag;
  r.minValue = i.minimum ?? null,
  r.maxValue = i.maximum ?? null,
  r.format = i.format ?? null;
});
function ok(r) {
  return bv(Xi, r);
}
var zh = $("ZodBigIntFormat", (r, t) => {
  jm.init(r, t), Xi.init(r, t);
});
function ek(r) {
  return hv(zh, r);
}
function lk(r) {
  return $v(zh, r);
}
var Kw = $("ZodSymbol", (r, t) => {
  Om.init(r, t), E.init(r, t);
});
function ck(r) {
  return xv(Kw, r);
}
var Lw = $("ZodUndefined", (r, t) => {
  Im.init(r, t), E.init(r, t);
});
function uk(r) {
  return fv(Lw, r);
}
var Vw = $("ZodNull", (r, t) => {
  km.init(r, t), E.init(r, t);
});
function Yw(r) {
  return wv(Vw, r);
}
var Ew = $("ZodAny", (r, t) => {
  Um.init(r, t), E.init(r, t);
});
function gk() {
  return zv(Ew);
}
var Qw = $("ZodUnknown", (r, t) => {
  Jm.init(r, t), E.init(r, t);
});
function xn() {
  return av(Qw);
}
var Fw = $("ZodNever", (r, t) => {
  Pm.init(r, t), E.init(r, t);
});
function ah(r) {
  return pv(Fw, r);
}
var Sw = $("ZodVoid", (r, t) => {
  Xm.init(r, t), E.init(r, t);
});
function mk(r) {
  return _v(Sw, r);
}
var _e = $("ZodDate", (r, t) => {
  qm.init(r, t),
  E.init(r, t),
  r.min = (o, n) => r.check(kr(o, n)),
  r.max = (o, n) => r.check(Er(o, n));
  let i = r._zod.bag;
  r.minDate = i.minimum ? new Date(i.minimum) : null,
  r.maxDate = i.maximum ? new Date(i.maximum) : null;
});
function bk(r) {
  return Dv(_e, r);
}
var Gw = $("ZodArray", (r, t) => {
  Wm.init(r, t),
  E.init(r, t),
  r.element = t.element,
  r.min = (i, o) => r.check(_t(i, o)),
  r.nonempty = (i) => r.check(_t(1, i)),
  r.max = (i, o) => r.check(vn(i, o)),
  r.length = (i, o) => r.check(hn(i, o)),
  r.unwrap = () => r.element;
});
function De(r, t) {
  return Xv(Gw, r, t);
}
function vk(r) {
  let t = r._zod.def.shape;
  return jh(Object.keys(t));
}
var je = $("ZodObject", (r, t) => {
  Km.init(r, t),
  E.init(r, t),
  p.defineLazy(r, "shape", () => {
    return t.shape;
  }),
  r.keyof = () => jh(Object.keys(r._zod.def.shape)),
  r.catchall = (i) => r.clone({ ...r._zod.def, catchall: i }),
  r.passthrough = () => r.clone({ ...r._zod.def, catchall: xn() }),
  r.loose = () => r.clone({ ...r._zod.def, catchall: xn() }),
  r.strict = () => r.clone({ ...r._zod.def, catchall: ah() }),
  r.strip = () => r.clone({ ...r._zod.def, catchall: void 0 }),
  r.extend = (i) => {
    return p.extend(r, i);
  },
  r.safeExtend = (i) => {
    return p.safeExtend(r, i);
  },
  r.merge = (i) => p.merge(r, i),
  r.pick = (i) => p.pick(r, i),
  r.omit = (i) => p.omit(r, i),
  r.partial = (...i) => p.partial(Ih, r, i[0]),
  r.required = (...i) => p.required(kh, r, i[0]);
});
function hk(r, t) {
  let i = { type: "object", shape: r ?? {}, ...p.normalizeParams(t) };
  return new je(i);
}
function $k(r, t) {
  return new je({
    type: "object",
    shape: r,
    catchall: ah(),
    ...p.normalizeParams(t)
  });
}
function xk(r, t) {
  return new je({
    type: "object",
    shape: r,
    catchall: xn(),
    ...p.normalizeParams(t)
  });
}
var ph = $("ZodUnion", (r, t) => {
  So.init(r, t), E.init(r, t), r.options = t.options;
});
function _h(r, t) {
  return new ph({ type: "union", options: r, ...p.normalizeParams(t) });
}
var Nw = $("ZodDiscriminatedUnion", (r, t) => {
  ph.init(r, t), Lm.init(r, t);
});
function fk(r, t, i) {
  return new Nw({
    type: "union",
    options: t,
    discriminator: r,
    ...p.normalizeParams(i)
  });
}
var Bw = $("ZodIntersection", (r, t) => {
  Vm.init(r, t), E.init(r, t);
});
function yw(r, t) {
  return new Bw({ type: "intersection", left: r, right: t });
}
var Aw = $("ZodTuple", (r, t) => {
  Go.init(r, t),
  E.init(r, t),
  r.rest = (i) => r.clone({ ...r._zod.def, rest: i });
});
function Hw(r, t, i) {
  let o = t instanceof L,
    n = o ? i : t;
  return new Aw({
    type: "tuple",
    items: r,
    rest: o ? t : null,
    ...p.normalizeParams(n)
  });
}
var Dh = $("ZodRecord", (r, t) => {
  Ym.init(r, t),
  E.init(r, t),
  r.keyType = t.keyType,
  r.valueType = t.valueType;
});
function Rw(r, t, i) {
  return new Dh({
    type: "record",
    keyType: r,
    valueType: t,
    ...p.normalizeParams(i)
  });
}
function wk(r, t, i) {
  let o = jr(r);
  return (
    o._zod.values = void 0,
    new Dh({
      type: "record",
      keyType: o,
      valueType: t,
      ...p.normalizeParams(i)
    }));

}
var Mw = $("ZodMap", (r, t) => {
  Em.init(r, t),
  E.init(r, t),
  r.keyType = t.keyType,
  r.valueType = t.valueType;
});
function zk(r, t, i) {
  return new Mw({
    type: "map",
    keyType: r,
    valueType: t,
    ...p.normalizeParams(i)
  });
}
var Zw = $("ZodSet", (r, t) => {
  Qm.init(r, t),
  E.init(r, t),
  r.min = (...i) => r.check(Lt(...i)),
  r.nonempty = (i) => r.check(Lt(1, i)),
  r.max = (...i) => r.check(bn(...i)),
  r.size = (...i) => r.check(hi(...i));
});
function ak(r, t) {
  return new Zw({ type: "set", valueType: r, ...p.normalizeParams(t) });
}
var Ii = $("ZodEnum", (r, t) => {
  Fm.init(r, t),
  E.init(r, t),
  r.enum = t.entries,
  r.options = Object.values(t.entries);
  let i = new Set(Object.keys(t.entries));
  r.extract = (o, n) => {
    let e = {};
    for (let l of o)
    if (i.has(l)) e[l] = t.entries[l];else
    throw new Error(`Key ${l} not found in enum`);
    return new Ii({ ...t, checks: [], ...p.normalizeParams(n), entries: e });
  },
  r.exclude = (o, n) => {
    let e = { ...t.entries };
    for (let l of o)
    if (i.has(l)) delete e[l];else
    throw new Error(`Key ${l} not found in enum`);
    return new Ii({ ...t, checks: [], ...p.normalizeParams(n), entries: e });
  };
});
function jh(r, t) {
  let i = Array.isArray(r) ? Object.fromEntries(r.map((o) => [o, o])) : r;
  return new Ii({ type: "enum", entries: i, ...p.normalizeParams(t) });
}
function pk(r, t) {
  return new Ii({ type: "enum", entries: r, ...p.normalizeParams(t) });
}
var Cw = $("ZodLiteral", (r, t) => {
  Sm.init(r, t),
  E.init(r, t),
  r.values = new Set(t.values),
  Object.defineProperty(r, "value", {
    get() {
      if (t.values.length > 1)
      throw new Error(
        "This schema contains multiple valid literal values. Use `.values` instead."
      );
      return t.values[0];
    }
  });
});
function _k(r, t) {
  return new Cw({
    type: "literal",
    values: Array.isArray(r) ? r : [r],
    ...p.normalizeParams(t)
  });
}
var Tw = $("ZodFile", (r, t) => {
  Gm.init(r, t),
  E.init(r, t),
  r.min = (i, o) => r.check(Lt(i, o)),
  r.max = (i, o) => r.check(bn(i, o)),
  r.mime = (i, o) => r.check(pi(Array.isArray(i) ? i : [i], o));
});
function Dk(r) {
  return qv(Tw, r);
}
var dw = $("ZodTransform", (r, t) => {
  Nm.init(r, t),
  E.init(r, t),
  r._zod.parse = (i, o) => {
    if (o.direction === "backward") throw new Pt(r.constructor.name);
    i.addIssue = (e) => {
      if (typeof e === "string") i.issues.push(p.issue(e, i.value, t));else
      {
        let l = e;
        if (l.fatal) l.continue = !1;
        l.code ?? (l.code = "custom"),
        l.input ?? (l.input = i.value),
        l.inst ?? (l.inst = r),
        i.issues.push(p.issue(l));
      }
    };
    let n = t.transform(i.value, i);
    if (n instanceof Promise)
    return n.then((e) => {
      return i.value = e, i;
    });
    return i.value = n, i;
  };
});
function Oh(r) {
  return new dw({ type: "transform", transform: r });
}
var Ih = $("ZodOptional", (r, t) => {
  Bm.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function we(r) {
  return new Ih({ type: "optional", innerType: r });
}
var sw = $("ZodNullable", (r, t) => {
  ym.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function ze(r) {
  return new sw({ type: "nullable", innerType: r });
}
function jk(r) {
  return we(ze(r));
}
var r4 = $("ZodDefault", (r, t) => {
  Am.init(r, t),
  E.init(r, t),
  r.unwrap = () => r._zod.def.innerType,
  r.removeDefault = r.unwrap;
});
function t4(r, t) {
  return new r4({
    type: "default",
    innerType: r,
    get defaultValue() {
      return typeof t === "function" ? t() : p.shallowClone(t);
    }
  });
}
var n4 = $("ZodPrefault", (r, t) => {
  Hm.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function i4(r, t) {
  return new n4({
    type: "prefault",
    innerType: r,
    get defaultValue() {
      return typeof t === "function" ? t() : p.shallowClone(t);
    }
  });
}
var kh = $("ZodNonOptional", (r, t) => {
  Rm.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function o4(r, t) {
  return new kh({ type: "nonoptional", innerType: r, ...p.normalizeParams(t) });
}
var e4 = $("ZodSuccess", (r, t) => {
  Mm.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function Ok(r) {
  return new e4({ type: "success", innerType: r });
}
var l4 = $("ZodCatch", (r, t) => {
  Zm.init(r, t),
  E.init(r, t),
  r.unwrap = () => r._zod.def.innerType,
  r.removeCatch = r.unwrap;
});
function c4(r, t) {
  return new l4({
    type: "catch",
    innerType: r,
    catchValue: typeof t === "function" ? t : () => t
  });
}
var u4 = $("ZodNaN", (r, t) => {
  Cm.init(r, t), E.init(r, t);
});
function Ik(r) {
  return Ov(u4, r);
}
var Uh = $("ZodPipe", (r, t) => {
  Tm.init(r, t), E.init(r, t), r.in = t.in, r.out = t.out;
});
function ae(r, t) {
  return new Uh({ type: "pipe", in: r, out: t });
}
var Jh = $("ZodCodec", (r, t) => {
  Uh.init(r, t), ii.init(r, t);
});
function kk(r, t, i) {
  return new Jh({
    type: "pipe",
    in: r,
    out: t,
    transform: i.decode,
    reverseTransform: i.encode
  });
}
var g4 = $("ZodReadonly", (r, t) => {
  dm.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function m4(r) {
  return new g4({ type: "readonly", innerType: r });
}
var b4 = $("ZodTemplateLiteral", (r, t) => {
  sm.init(r, t), E.init(r, t);
});
function Uk(r, t) {
  return new b4({
    type: "template_literal",
    parts: r,
    ...p.normalizeParams(t)
  });
}
var v4 = $("ZodLazy", (r, t) => {
  nb.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.getter();
});
function h4(r) {
  return new v4({ type: "lazy", getter: r });
}
var $4 = $("ZodPromise", (r, t) => {
  tb.init(r, t), E.init(r, t), r.unwrap = () => r._zod.def.innerType;
});
function Jk(r) {
  return new $4({ type: "promise", innerType: r });
}
var x4 = $("ZodFunction", (r, t) => {
  rb.init(r, t), E.init(r, t);
});
function Pk(r) {
  return new x4({
    type: "function",
    input: Array.isArray(r?.input) ? Hw(r?.input) : r?.input ?? De(xn()),
    output: r?.output ?? xn()
  });
}
var Oe = $("ZodCustom", (r, t) => {
  ib.init(r, t), E.init(r, t);
});
function Xk(r) {
  let t = new s({ check: "custom" });
  return t._zod.check = r, t;
}
function qk(r, t) {
  return Wv(Oe, r ?? (() => !0), t);
}
function f4(r, t = {}) {
  return Kv(Oe, r, t);
}
function w4(r) {
  return Lv(r);
}
function Wk(r, t = { error: `Input not instance of ${r.name}` }) {
  let i = new Oe({
    type: "custom",
    check: "custom",
    fn: (o) => o instanceof r,
    abort: !0,
    ...p.normalizeParams(t)
  });
  return i._zod.bag.Class = r, i;
}
var Kk = (...r) => Vv({ Codec: Jh, Boolean: Pi, String: ki }, ...r);
function Lk(r) {
  let t = h4(() => {
    return _h([sv(r), qw(), Ww(), Yw(), De(t), Rw(sv(), t)]);
  });
  return t;
}
function Vk(r, t) {
  return ae(Oh(r), t);
}
var Yk = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function Ek(r) {
  br({ customError: r });
}
function Qk() {
  return br().customError;
}
var Ph;
(function (r) {})(Ph || (Ph = {}));
var Xh = {};
I(Xh, {
  string: () => Fk,
  number: () => Sk,
  date: () => Bk,
  boolean: () => Gk,
  bigint: () => Nk
});
function Fk(r) {
  return Cb(ki, r);
}
function Sk(r) {
  return iv(Ji, r);
}
function Gk(r) {
  return mv(Pi, r);
}
function Nk(r) {
  return vv(Xi, r);
}
function Bk(r) {
  return jv(_e, r);
}
br(oi());
var z4 = rr.object({
    type: rr.enum(["prepend", "append"]),
    targetDomId: rr.string(),
    targetOid: rr.string().nullable()
  }),
  yk = z4.extend({
    type: rr.literal("index"),
    index: rr.number(),
    originalIndex: rr.number()
  }),
  QW = rr.discriminatedUnion("type", [yk, z4]);
var eK = rr.object({
  suggestions: rr.
  array(
    rr.object({
      title: rr.
      string().
      describe(
        "The display title of the suggestion. This will be shown to the user. Keep it concise but descriptive."
      ),
      prompt: rr.
      string().
      describe(
        "The prompt for the suggestion. This will be used to generate the suggestion. Make this as detailed and specific as possible."
      )
    })
  ).
  length(3)
});
var uK = rr.object({
  filesDiscussed: rr.
  array(rr.string()).
  describe("List of file paths mentioned in the conversation"),
  projectContext: rr.
  string().
  describe("Summary of what the user is building and their overall goals"),
  implementationDetails: rr.
  string().
  describe(
    "Summary of key code decisions, patterns, and important implementation details"
  ),
  userPreferences: rr.
  string().
  describe(
    "Specific preferences the user has expressed about implementation, design, etc."
  ),
  currentStatus: rr.
  string().
  describe("Current state of the project and any pending work")
});
var WK = {
  ["anthropic/claude-sonnet-4.5"]: 200000,
  ["anthropic/claude-sonnet-4"]: 200000,
  ["anthropic/claude-3.5-haiku"]: 200000,
  ["openai/gpt-5-nano"]: 400000,
  ["openai/gpt-5-mini"]: 400000,
  ["openai/gpt-5"]: 400000,
  ["claude-sonnet-4-20250514"]: 200000,
  ["claude-3-5-haiku-20241022"]: 200000
};
function a4() {
  try {
    return window?.localStorage.getItem("theme") || "light";
  } catch (r) {
    return console.warn("Failed to get theme", r), "light";
  }
}
function p4(r) {
  try {
    if (r === "dark")
    document.documentElement.classList.add("dark"),
    window?.localStorage.setItem("theme", "dark");else
    if (r === "light")
    document.documentElement.classList.remove("dark"),
    window?.localStorage.setItem("theme", "light");else
    if (r === "system") {
      if (window.matchMedia("(prefers-color-scheme: dark)").matches)
      document.documentElement.classList.add("dark");else
      document.documentElement.classList.remove("dark");
      window?.localStorage.setItem("theme", "system");
    }
    return !0;
  } catch (t) {
    return console.warn("Failed to set theme", t), !1;
  }
}
function Ak(r) {
  return (...t) => {
    try {
      return r(...t);
    } catch (i) {
      return console.error(`Error in ${r.name}:`, i), null;
    }
  };
}
var Hk = {
    processDom: Ki,
    setFrameId: Ee,
    getComputedStyleByDomId: X$,
    updateElementInstance: E$,
    getFirstOnlookElement: M$,
    captureScreenshot: Cf,
    buildLayerTree: zr,
    getElementAtLoc: Y$,
    getElementByDomId: Vi,
    getElementIndex: Uf,
    setElementType: R$,
    getElementType: H$,
    getParentElement: Q$,
    getChildrenCount: F$,
    getOffsetParent: S$,
    getActionLocation: A$,
    getActionElement: Yi,
    getInsertLocation: _f,
    getRemoveAction: If,
    getTheme: a4,
    setTheme: p4,
    startDrag: Kf,
    drag: Vf,
    dragAbsolute: Lf,
    endDrag: Ef,
    endDragAbsolute: Yf,
    endAllDrag: Su,
    startEditingText: Ff,
    editText: Sf,
    stopEditingText: Gf,
    isChildTextEditable: yf,
    updateStyle: zf,
    insertElement: Df,
    removeElement: Of,
    moveElement: kf,
    groupElements: G$,
    ungroupElements: N$,
    insertImage: af,
    removeImage: pf,
    handleBodyReady: Gu
  },
  _4 = Object.fromEntries(Object.entries(Hk).map(([r, t]) => [r, Ak(t)]));
var _r = null,
  Ie = !1,
  O4 = async () => {
    if (Ie || _r) return _r;
    Ie = !0, console.log(`${Vt} - Creating penpal connection`);
    let r = new _$({ remoteWindow: window.parent, allowedOrigins: ["*"] }),
      t = p$({ messenger: r, methods: _4 });
    return (
      t.promise.
      then((i) => {
        if (!i) {
          console.error(
            `${Vt} - Failed to setup penpal connection: child is null`
          ),
          D4();
          return;
        }
        _r = i, console.log(`${Vt} - Penpal connection set`);
      }).
      finally(() => {
        Ie = !1;
      }),
      t.promise.catch((i) => {
        console.error(`${Vt} - Failed to setup penpal connection:`, i), D4();
      }),
      _r);

  },
  D4 = j4.default(() => {
    if (Ie) return;
    console.log(`${Vt} - Reconnecting to penpal parent`), _r = null, O4();
  }, 1000);
O4();
export { _r as penpalParent };